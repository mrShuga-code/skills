// =====================================================================
//  Контроллер ректификационной колонны
//  ESP32-S3 DevKitC-1 N16R8 + 3× MAX31865 + ILI9341 2,8" с тачем FT6336
//
//  Логика — по документу «Логика контроллера колонны», экраны — по макету.
//
//  ГДЕ ЧТО МЕНЯТЬ:
//    config.h      — пины, ЭКРАН (инверсия цветов, поворот, частота),
//                    ТАЧ (нажимается не там), ДАТЧИКИ (PT100/PT1000, Rref),
//                    зуммер, реле клапана, RGB-светодиод, Wi-Fi-точка, часовой пояс
//    secrets.h     — ваши сети Wi-Fi и пароль веб-настроек (в git не кладём!)
//    lgfx_config.h — полное описание дисплея для LovyanGFX (обычно не трогать)
//    Пороги, зоны, окно стабилизации, подсветку меняйте в меню на экране,
//    тип датчика, Rref, поправки и Wi-Fi — в вебе (Настройки).
//
//  НАСТРОЙКИ Arduino IDE (Tools), см. README.md:
//    Board: ESP32S3 Dev Module, Flash Size: 16MB, PSRAM: OPI PSRAM,
//    Partition Scheme: 8M with spiffs (3MB APP/1.5MB SPIFFS)
//    Библиотека: LovyanGFX (Library Manager)
//
//  Монитор порта 115200: там видно, что найдено, куда подключился Wi-Fi
//  и какой адрес открывать в браузере.
// =====================================================================
#include "app.h"
#include <esp_task_wdt.h>

// Сторожевой таймер (config.h → WDT_TIMEOUT_S): главный цикл и задача датчиков
// отмечаются каждый проход; зависли дольше — ESP32 перезагружается сама
// (реле после перезагрузки выключено, клапан закрыт).
static void wdtBegin() {
#if WDT_TIMEOUT_S > 0
  esp_task_wdt_config_t c = {};
  c.timeout_ms = WDT_TIMEOUT_S * 1000UL;
  c.idle_core_mask = 0;              // простой ядер не проверяем: следим за своими задачами
  c.trigger_panic = true;            // зависли — перезагрузка
  if (esp_task_wdt_reconfigure(&c) != ESP_OK) esp_task_wdt_init(&c);
  esp_task_wdt_add(nullptr);         // главный цикл (loop)
  Serial.printf("[wdt] сторожевой таймер %u с\n", (unsigned)WDT_TIMEOUT_S);
#endif
}

void setup() {
  Serial.begin(115200);
  relayBegin();       // реле клапана: выключено с первых миллисекунд
  delay(300);
  Serial.println(F("\n=== Контроллер колонны ==="));
  Serial.printf("Причина запуска: %s\n", resetReasonText());

  settingsLoad();     // настройки из NVS (в первый раз — заводские из config.h/secrets.h)
  buzzerBegin();      // зуммер сразу молчит
  ledBegin();         // RGB-светодиод на плате: пока гаснет, дальше цвет по состоянию
  uiBegin();          // экран, тач, шрифты, заставка
  historyBegin();     // память под графики, LittleFS для лога
  logicBegin();       // перегон: сначала экран выбора
  sensorsBegin();     // задача опроса трёх MAX31865 (ядро 0)
  netBegin();         // Wi-Fi в фоне: экран и датчики его не ждут
  webBegin();
  wdtBegin();         // сторожевой таймер: с этого момента loop() должен отмечаться
  Serial.println(F("Готово. Выберите перегон на экране или в браузере."));
}

void loop() {
  static uint32_t seq = 0;
  Probe p[NCH];
  uint32_t s = sensorsGet(p);
  if (s != seq) {     // раз в секунду: свежее среднее за 5 с
    seq = s;
    historyPush(p);
    logicTick(p);
  }
  logicLoop();        // данные датчиков не устарели? (иначе Тфикс на паузе)
  uiLoop();           // тач и перерисовка экрана
  netLoop();          // Wi-Fi, переподключение, прошивка по сети
  webLoop();          // веб-страница
  settingsTick();     // отложенное сохранение настроек
  ledLoop();          // RGB-светодиод: Wi-Fi и аварии
#if WDT_TIMEOUT_S > 0
  esp_task_wdt_reset();   // цикл жив
#endif
  delay(2);
}
