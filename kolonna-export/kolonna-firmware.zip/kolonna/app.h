// =====================================================================
//  app.h — общие типы и функции всех частей прошивки.
//
//  Как устроена прошивка (по документу «Логика контроллера колонны»):
//    sensors.cpp  — задача FreeRTOS: опрос трёх MAX31865, усреднение 5 с
//    logic.cpp    — перегоны, цвета, Тфикс, хвосты, стабилизация, охлаждение
//    buzzer.cpp   — задача FreeRTOS: сигналы зуммера по приоритету
//    led.cpp      — RGB-светодиод на плате: Wi-Fi и аварии одним цветом
//    history.cpp  — история: 30 мин в RAM, 24 ч в PSRAM, поминутный лог с событиями на flash
//    ui.cpp       — экран и тач (всё рисуется в спрайт и выводится целиком)
//    web.cpp      — веб-страница и API, net.cpp — Wi-Fi, время, OTA
//    settings.cpp — настройки в NVS
//  Задачи не вызывают друг друга напрямую: датчики только кладут данные,
//  остальные их забирают. Клапан во второй версии добавится новой задачей.
// =====================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

// ---------------------------------------------------------------------
//  Каналы
// ---------------------------------------------------------------------
static const uint8_t NCH = 3;
enum : uint8_t { CH_CUBE = 0, CH_COLUMN = 1, CH_THIRD = 2 };  // датчик 1, 2, 3

// ---------------------------------------------------------------------
//  Настройки (лежат в NVS, меняются в меню и в вебе)
// ---------------------------------------------------------------------
struct ChannelCfg {
  bool    enabled;   // отключённый канал не опрашивается
  bool    pt1000;    // false = PT100, true = PT1000
  float   rref;      // Ом
  uint8_t wires;     // 2, 3 или 4
  float   offset;    // поправка калибровки, °C (по тающему льду)
};

struct Settings {
  ChannelCfg ch[NCH];
  // второй перегон, царга
  uint16_t stabWindow;   // окно стабилизации, с (120..900)
  float    green;        // зелёный до +0,05
  float    red;          // тревога выше +0,10
  uint8_t  alarmDelay;   // задержка тревоги, с
  bool     buzzer;       // зуммер вкл/выкл
  // зоны куба: зелёный, жёлтый, оранжевый, красный от
  float    z2[4];        // второй перегон: 55 / 88,3 / 91,5 / 93,2
  float    z1[4];        // первый перегон: 55 / 90 / 94 / 98
  float    col1;         // первый перегон: царга зелёная от 65
  uint8_t  chartMin;     // окно графика куба на экране, мин (1..30)
  uint8_t  bright;       // подсветка, % (10..100)
  // сеть
  char ssid[2][33];      // [0] основная, [1] запасная
  char pass[2][65];
  char webPass[33];      // пароль страницы настроек и OTA
  // Поля ниже добавлены 14.10.2026: блок настроек прошивки до этого (332 байта)
  // читается как есть, новые поля берут заводские значения (settings.cpp).
  float    steamC;       // второй перегон: «пар в узле отбора» — датчик 3 выше, °C (30..90, заводское 50)
};
extern Settings cfg;

void settingsDefaults(Settings &s);
void settingsLoad();
void settingsSave();               // сохраняет не чаще раза в 2 с (бережём flash)
void settingsSaveNow();
void settingsTick();               // дописывает отложенное сохранение
void settingsFactoryReset();
bool touchCalLoad(uint16_t p[8]);
void touchCalSave(const uint16_t p[8]);
// Дата калибровки датчика по льду (unix-время, 0 — неизвестна). Лежит отдельным
// ключом NVS «calat», чтобы не менять блок Settings. Ставится при «Сохранить»
// в калибровке по льду и при загрузке файла калибровки, «Сбросить» стирает.
uint32_t calDate(uint8_t i);
void calDateSet(uint8_t i, uint32_t unixTime);

// Состояние перегона, переживающее перезагрузку (пишется раз в минуту и
// сразу при фиксации, сбросе и подтверждении Тфикс). Версия 2: с флагом
// «Тфикс задана», временем и источником фиксации и контрольной суммой.
// Запись версии 1 (прошивки до 13.10.2026) тоже читается.
static const uint8_t SAVED_RUN_VERSION = 2;
struct SavedRun {
  uint8_t  ver;        // SAVED_RUN_VERSION
  uint8_t  run;
  uint8_t  cool;
  uint8_t  hasFix;     // 1 — Тфикс задана
  uint32_t elapsed;    // таймер перегона, с
  float    fix;        // Тфикс, °C
  uint32_t fixTime;    // когда зафиксирована: unix-время или секунда перегона (см. fixClock)
  uint8_t  fixSrc;     // FixSrc
  uint8_t  fixClock;   // 1 — fixTime это unix-время, 0 — секунда перегона, 2 — неизвестно
  uint8_t  pad[2];
  uint32_t crc;        // CRC32 всего, что выше
};
enum SavedLoad : uint8_t { SAVED_NONE = 0, SAVED_OK, SAVED_BAD };
SavedLoad savedRunLoad(SavedRun &r);   // SAVED_BAD — запись есть, но испорчена
void savedRunStore(const SavedRun &r);

// ---------------------------------------------------------------------
//  Датчики
// ---------------------------------------------------------------------
// PROBE_FAULT — обрыв или КЗ датчика (или PT1000 на модуле с Rref 430 Ом);
// PROBE_RANGE — модуль меряет, но температура вне -50..250 °C: в настройках
//               не совпадают тип датчика и Rref (см. config.h, раздел ДАТЧИКИ).
enum ProbeState : uint8_t { PROBE_OK = 0, PROBE_OFF, PROBE_FAULT, PROBE_NOCHIP, PROBE_WAIT, PROBE_RANGE };

struct Probe {
  float      t;       // усреднённая температура, °C (NAN если нет)
  float      ohm;     // сопротивление последнего чтения
  ProbeState state;
  uint8_t    fault;   // регистр неисправностей MAX31865 (для веба)
  uint32_t   age;     // мс от последнего годного чтения канала до выдачи среднего
};

void sensorsBegin();
uint32_t sensorsGet(Probe out[NCH]);   // копия последних значений, возвращает номер выборки
void sensorsReconfigure();              // после смены типа/Rref/проводов
const char *probeStateText(const Probe &p);

// Калибровка по льду: CAL_SECONDS секунд копим сопротивление канала,
// потом веб показывает новый Rref и ждёт «Сохранить».
enum CalState : uint8_t { CAL_IDLE = 0, CAL_RUN, CAL_DONE };
struct CalInfo {
  CalState state;
  uint32_t leftMs;          // сколько осталось мерить
  float    ohm;             // среднее сопротивление (CAL_DONE)
  float    ohmMin, ohmMax;  // самое малое и большое из чтений
  uint16_t n, bad, wild;    // хороших чтений, с обрывом или КЗ, вне −50…250 °C
};
bool    sensorsCalStart(uint8_t i);     // false — канал выключен или модуль не найден
CalInfo sensorsCalInfo(uint8_t i);
void    sensorsCalClear(uint8_t i);

// PT100/PT1000: сопротивление <-> температура (Каллендар–Ван Дюзен), util.cpp
float rtdToC(float r, float r0);
float rtdOhm(float t, float r0);

// ---------------------------------------------------------------------
//  Перегон
// ---------------------------------------------------------------------
enum Run : uint8_t { RUN_NONE = 0, RUN_1 = 1, RUN_2 = 2 };
enum ColMode : uint8_t { MODE_DRAW = 0, MODE_TAILS = 1, MODE_STAB = 2 };
enum CoolState : uint8_t { COOL_IDLE = 0, COOL_ALERT = 1, COOL_DONE = 2 };
enum Tone : uint8_t { TONE_COLD, TONE_OK, TONE_WARN, TONE_HOT, TONE_BAD, TONE_WHITE, TONE_STAB, TONE_GREY };

struct FixMark { uint32_t t; float v; };   // история Тфикс для графика в вебе
static const uint8_t MAX_FIXES = 24;

// Тфикс: откуда пришла команда и что могло помешать (одинаково для экрана и веба)
enum FixSrc : uint8_t { SRC_SCREEN = 0, SRC_WEB, SRC_STAB, SRC_BOOT };
enum FixErr : uint8_t { FIX_OK = 0, FIX_ERR_RUN, FIX_ERR_SENSOR, FIX_ERR_STALE, FIX_ERR_NOFIX, FIX_ERR_NOTPENDING };
// Состояние Тфикс для экрана и веба (НЕТ ДАННЫХ — когда датчик царги неисправен
// или данные устарели; сама Тфикс при этом не стирается)
enum FixState : uint8_t { FS_NONE = 0, FS_ACTIVE, FS_NODATA, FS_CONFIRM };

// Отметка отбора на плитке «УЗЕЛ ОТБОРА» (второй перегон): ставит оператор
// нажатием на плитку, «Хвосты» сами закрывают, фиксация Тфикс сама открывает.
// Только в памяти: после перезагрузки и в новом перегоне — снова «нет отметки».
enum UoState : uint8_t { UO_NONE = 0, UO_HEADS, UO_BODY, UO_CLOSED };

struct RunState {
  Run       run;          // текущий перегон (RUN_NONE = экран выбора)
  Run       lastRun;      // что шло до этого (для «Продолжить»)
  uint32_t  runStart;     // секунда аптайма, от которой считается таймер
  ColMode   mode;
  float     fix;          // Тфикс, NAN если не задана
  uint32_t  redSince;     // с какой секунды царга выше порога тревоги (0 = нет)
  uint32_t  stabStart;    // начало стабилизации
  uint32_t  stableFor;    // сколько секунд царга в коридоре 0,05
  float     spread;       // размах царги за окно
  bool      spreadReady;  // данных набралось на целое окно
  uint32_t  newUntil;     // до какой секунды показывать «Новая Тфикс»
  bool      fixConfirm;   // Тфикс восстановлена после перезагрузки и ждёт подтверждения
  bool      ask;          // стабилизация прошла: просим оператора зафиксировать Тфикс
  uint32_t  askBeepAt;    // когда последний раз напоминали сигналом
  bool      stale;        // датчики давно не присылали данные (FIX_STALE_MS)
  uint32_t  fixTime;      // когда зафиксирована Тфикс (как SavedRun.fixTime)
  uint8_t   fixSrc;       // FixSrc
  uint8_t   fixClock;
  CoolState cool;
  uint8_t   faultMask;    // какие каналы сейчас неисправны
  uint8_t   faultAck;     // какие неисправности уже сброшены кнопкой
  UoState   uo;           // отметка отбора на плитке УО
  uint32_t  uoAt;         // с какой секунды отбор закрыт (таймер «ЗАКРЫТ 3:12»)
  bool      steamFired;   // сигнал «пар в узле отбора» в этом перегоне уже был (или разгон позади)
  bool      steamMsg;     // надпись «Пар в узле отбора…» ждёт «Понятно»
  FixMark   fixes[MAX_FIXES];
  uint8_t   nFixes;
  Probe     p[NCH];       // последние значения датчиков
  uint32_t  now;          // текущая секунда аптайма
};
extern RunState st;

void logicBegin();
void logicTick(const Probe p[NCH]);     // раз в секунду, после свежего усреднения
void logicLoop();                       // из loop(): следит, что данные датчиков свежие
uint32_t nowSec();

// Команды — одинаковые для экрана и веба
void cmdChooseRun(Run r);
void cmdToSelect();
void cmdRemember();                     // = cmdFix(SRC_SCREEN), оставлено для совместимости
FixErr cmdFix(FixSrc src);              // Тфикс = текущая температура царги
FixErr cmdFixConfirm(FixSrc src);       // подтвердить Тфикс, восстановленную после перезагрузки
FixErr cmdFixClear(FixSrc src);         // сбросить Тфикс
FixErr fixCheck();                      // можно ли сейчас фиксировать (данные достоверны)
bool columnValid();                     // датчик царги в норме и данные свежие
FixState fixState();
const char *fixStateText(FixState s);   // «Не зафиксирована», «Активна», …
const char *fixErrText(FixErr e, int probeState = -1);   // -1 — по датчику сейчас
const char *fixSrcText(uint8_t src);    // «с экрана», «из браузера», …
String fixTimeText();                   // «14:05» или «+1:02:03» от начала перегона
String evTimeText(uint32_t at, uint8_t clock, bool date);   // то же для события журнала
void cmdResetAlarm(uint8_t src = SRC_SCREEN);    // src — для лога: с экрана или из веба
void cmdConfirmCool(uint8_t src = SRC_SCREEN);
void cmdResetTimer();
bool hasSavedRun(Run &r, uint32_t &elapsed);
// «было 75,30, сейчас 75,31 (+0,01)» для окна «Зафиксировать?» (пусто без Тфикс или данных)
String fixDiffText();
// Плитка УО: нажатие переключает отметку (нет → ГОЛОВЫ → ТЕЛО → ГОЛОВЫ …, ЗАКРЫТ → ТЕЛО)
void cmdUoTap(uint8_t src = SRC_SCREEN);
String uoLabel();                       // «ГОЛОВЫ», «ТЕЛО», «ЗАКРЫТ 3:12» (пусто — отметки нет)
// Сигнал «пар в узле отбора» (второй перегон, на разгоне, датчик 3 выше cfg.steamC, раз за перегон)
bool steamAlert();                      // надпись сейчас на экране и в вебе («Включите охлаждение» важнее)
void cmdSteamAck(uint8_t src = SRC_SCREEN);   // «Понятно»

// Цвета/зоны
Tone cubeTone(float t);
const char *cubeZoneText(float t, char *buf, size_t n);
Tone columnTone();                  // второй перегон
Tone col1Tone(float t);             // первый перегон
float cubeGreenFrom();              // порог «зелёный от» текущего перегона = порог охлаждения
bool alarmTails();
bool alarmFaultSound();

// ---------------------------------------------------------------------
//  Зуммер
// ---------------------------------------------------------------------
void buzzerBegin();
void buzzerClick();
void buzzerTwoShort();
void buzzerShort();                      // один короткий: Тфикс зафиксирована
void buzzerSeries();                     // серия из 4 коротких: «пар в узле отбора»

// relay.cpp — реле электроклапана отбора на GPIO18 (вручную из веба)
void relayBegin();                       // первым делом в setup(): реле выключено
void relaySet(bool on, uint8_t src = SRC_WEB);   // пишет событие в лог перегона
bool relayOn();

// ---------------------------------------------------------------------
//  RGB-светодиод на плате (led.cpp)
// ---------------------------------------------------------------------
void ledBegin();
void ledLoop();                          // из loop(): цвет по сети и авариям

// ---------------------------------------------------------------------
//  История
// ---------------------------------------------------------------------
struct Sample { float c, k, u; };   // царга, куб, третий датчик
void historyBegin();
void historyPush(const Probe p[NCH]);   // раз в секунду
void historyRunStarted(bool fresh);      // новый файл лога при новом перегоне
// последние 30 минут с шагом 1 с (для графика на экране и стабилизации)
uint16_t recentCount();
Sample recentAt(uint16_t back);          // back = 0 — последняя секунда
// для веба: ряды графиков в JSON; minutes = 30, 120 или 0 (вся перегонка)
void historyJson(uint32_t minutes, Print &out);
bool historyCsvPath(String &path);       // файл лога текущего перегона на LittleFS

// Лог перегона: /log/N.csv, строка раз в минуту «минута;время;куб;царга;датчик 3;Тфикс;событие».
// В лог пишется второй перегон (и первый, если LOG_RUN1 = 1 в config.h).
bool historyLogging();                   // перегон сейчас пишется в файл
// Событие хода перегона в колонку «событие» текущей минуты (и в монитор порта).
// Время («12:41:07» или «таймер 0:41:07») ставится само; «;» и перевод строки
// заменяются; в строке минуты не больше 400 байт, дальше «…».
// Числа — с запятой, как в CSV: fmtNum(t, 1).
void historyEvent(const char *text);
void historyEventf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
const char *evSrcText(uint8_t src);      // источник в тексте события: «с экрана», «из веба»
// Прошлые перегоны для веба: список, файл для скачивания, удаление
void logsJson(Print &out);               // {"fs":…,"run1":…,"logs":[{"n":18,"start":"14.10.2026 12:37:00",…}]}, новые сверху
bool historyLogFile(uint32_t n, String &path, String &name);   // n = 0 — текущий; name — kolonna-18_2026-10-14_12-37.csv
enum LogDel : uint8_t { LOGDEL_OK = 0, LOGDEL_NONE, LOGDEL_CURRENT, LOGDEL_LAST };
LogDel historyLogDelete(uint32_t n);     // удаляет N.csv и N.ev; текущий и последний — нельзя

// Журнал событий Тфикс: последние FIX_EVENTS_RAM в памяти и файл /log/N.ev
// рядом с CSV перегона (удаляется вместе с ним). Те же события идут и в
// колонку «событие» CSV.
enum FixEvKind : uint8_t { EV_FIX = 0, EV_CLEAR, EV_CONFIRM, EV_REFUSE, EV_RESTORE, EV_CORRUPT, EV_ASK };
struct FixEvent {
  uint32_t at;        // unix-время (clock = 1) или секунда перегона (clock = 0)
  uint8_t  clock;
  uint8_t  kind;      // FixEvKind
  uint8_t  src;       // FixSrc
  uint8_t  err;       // FixErr для EV_REFUSE
  uint8_t  pstate;    // ProbeState царги в этот момент (для текста причины)
  float    oldV, newV, cur;   // старая и новая Тфикс, царга в этот момент (NAN — нет)
};
void historyEvent(const FixEvent &e);
void eventsJson(Print &out);             // для /api/events, новые сверху

// ---------------------------------------------------------------------
//  Экран, сеть, веб
// ---------------------------------------------------------------------
void uiBegin();
void uiLoop();
void uiMarkDirty();
void uiCloseMenu();                      // закрывает меню, график и окна подтверждения
void uiToast(const char *msg, bool bad); // всплывающая строка на 2 с («Тфикс зафиксирована: …»)

enum NetState : uint8_t { NET_CONNECTING = 0, NET_ONLINE, NET_AP };
void netBegin();
void netLoop();
void netReconnect();                    // после смены сетей в вебе
NetState netState();
String netAddress();
String netSsid();                       // имя сети Wi-Fi (или своей точки доступа)
bool timeValid();
void timeFromBrowser(uint32_t epoch);

void webBegin();
void webLoop();

// ---------------------------------------------------------------------
//  Мелочи
// ---------------------------------------------------------------------
String fmtNum(float v, uint8_t dec);     // 75,25 (запятая, как в документе)
String fmtSigned(float v, uint8_t dec);  // +0,03 / -0,02
String fmtHMS(uint32_t s);               // 3:42:10
String fmtMS(uint32_t s);                // 3:12
String fmtClock(int32_t unixTime);       // 14:22 или --:--
