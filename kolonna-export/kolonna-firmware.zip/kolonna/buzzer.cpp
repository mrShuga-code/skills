// buzzer.cpp — активный зуммер 5 В через полевой транзистор P3055LD на GPIO47.
//
//  Активный зуммер пищит сам, когда на него подано питание, поэтому
//  здесь только включаем и выключаем пин (никакого tone()).
//  Своя задача FreeRTOS, шаг 10 мс. Звуки по приоритету (как в документе):
//    1. Хвосты в царге        — частые сигналы до «Сброс тревоги»
//    2. разовые: 2 коротких (стабильно — зафиксируйте Тфикс), 1 короткий
//       (Тфикс зафиксирована, отметка на плитке УО), 4 коротких (пар в узле
//       отбора), щелчок кнопки
//    3. Неисправность датчика — длинный сигнал раз в 10 с до «Сброс тревоги»
//    4. Включите охлаждение   — 3 коротких каждые 5 с до «Охлаждение включено»
//  Пункт меню «Зуммер: выкл» глушит всё.
//
//  ЕСЛИ ЗУММЕР ПИЩИТ ПОСТОЯННО, а при тревоге молчит — у вас другая схема
//  ключа, поменяйте BUZZER_ON_LEVEL в config.h на LOW.
//  ЕСЛИ МОЛЧИТ ВСЕГДА — проверьте, что зуммер активный (с генератором):
//  если на 5 В от блока питания он только щёлкает, он пассивный.
#include "app.h"

static volatile uint8_t  oneShot = 0;       // 1 — щелчок, 2 — два коротких, 3 — один короткий, 4 — серия из 4
static volatile uint32_t oneShotAt = 0;
// оба поля меняются вместе: просьба с ядра 1 не должна затереться сбросом задачи на ядре 0
static portMUX_TYPE shotMux = portMUX_INITIALIZER_UNLOCKED;

static void setShot(uint8_t kind, bool onlyIfIdle) {
  portENTER_CRITICAL(&shotMux);
  if (!onlyIfIdle || oneShot == 0) { oneShotAt = millis(); oneShot = kind; }
  portEXIT_CRITICAL(&shotMux);
}

void buzzerClick() {
  if (TOUCH_CLICK_MS == 0) return;
  setShot(1, true);
}

void buzzerTwoShort() { setShot(2, false); }

void buzzerShort() { setShot(3, false); }

void buzzerSeries() { setShot(4, false); }

static inline void pin(bool on) { digitalWrite(PIN_BUZZER, on ? BUZZER_ON_LEVEL : !BUZZER_ON_LEVEL); }

// «пи-пи-пи» с длительностью сигнала onMs и паузой offMs, n раз, от начала периода
static bool pattern(uint32_t phase, uint16_t onMs, uint16_t offMs, uint8_t n) {
  uint32_t k = phase / (onMs + offMs);
  return k < n && (phase % (onMs + offMs)) < onMs;
}

static void buzzerTask(void *) {
  uint32_t tailsAt = 0, faultAt = 0, coolAt = 0;   // когда началось событие
  bool wasTails = false, wasFault = false, wasCool = false;
  for (;;) {
    uint32_t t = millis();
    bool tails = alarmTails();
    bool fault = alarmFaultSound();
    bool cool  = cfg.buzzer && st.run != RUN_NONE && st.cool == COOL_ALERT;
    if (tails && !wasTails) tailsAt = t;
    if (fault && !wasFault) faultAt = t;
    if (cool && !wasCool) coolAt = t;
    wasTails = tails; wasFault = fault; wasCool = cool;

    bool on = false;
    portENTER_CRITICAL(&shotMux);
    uint8_t shot = oneShot;
    int32_t d = (int32_t)(t - oneShotAt);        // просьба могла прийти после чтения millis()
    uint32_t shotPhase = d < 0 ? 0 : (uint32_t)d;
    if (shot == 1 && shotPhase >= TOUCH_CLICK_MS) oneShot = shot = 0;
    if (shot == 2 && shotPhase >= 500) oneShot = shot = 0;
    if (shot == 3 && shotPhase >= 150) oneShot = shot = 0;
    if (shot == 4 && shotPhase >= 1000) oneShot = shot = 0;
    portEXIT_CRITICAL(&shotMux);

    if (!cfg.buzzer) {
      on = false;
    } else if (tails) {
      on = pattern((t - tailsAt) % 400, 200, 200, 1);          // частые сигналы
    } else if (shot == 1) {
      on = true;                                               // щелчок
    } else if (shot == 2) {
      on = pattern(shotPhase, 120, 130, 2);                    // 2 коротких
    } else if (shot == 3) {
      on = true;                                               // 1 короткий, 150 мс
    } else if (shot == 4) {
      on = pattern(shotPhase, 120, 130, 4);                    // 4 коротких, раз
    } else if (fault) {
      on = ((t - faultAt) % 10000) < 1000;                     // 1 с раз в 10 с
    } else if (cool) {
      on = pattern((t - coolAt) % 5000, 120, 130, 3);          // 3 коротких раз в 5 с
    }
    pin(on);
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void buzzerBegin() {
  pinMode(PIN_BUZZER, OUTPUT);
  pin(false);
  xTaskCreatePinnedToCore(buzzerTask, "buzzer", 2048, nullptr, 2, nullptr, 0);
}
