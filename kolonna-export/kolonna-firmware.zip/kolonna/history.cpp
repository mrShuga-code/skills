// history.cpp — история температур в трёх слоях:
//
//   1. 30 минут с шагом 1 с (PSRAM, ~21 КБ) — график куба на экране,
//      графики 30 мин в вебе и расчёт стабилизации царги.
//      В документе для графика указано «точка раз в 2 с»: здесь хранится
//      каждая секунда, а экран и веб берут из неё нужный шаг.
//   2. 24 часа с шагом 5 с (PSRAM, ~100 КБ) — веб: «2 часа» и «вся перегонка».
//   3. LittleFS: на каждый перегон свой файл /log/N.csv, строка раз
//      в минуту. Хранятся последние KEEP_LOGS файлов (config.h), пишется
//      второй перегон (первый — только если LOG_RUN1 = 1). Переживает перезагрузку.
//      Файл открывается в Excel: разделитель «;», десятичная запятая.
//        Второй перегон №19;начало 14.10.2026 09:30:00   (или «;дата неизвестна»)
//        минута;время;куб;царга;датчик 3;Тфикс;событие
//        95;11:38;84,10;75,32;74,80;75,30;11:38:20 фиксация Тфикс 75,30 (с экрана)
//      «время» — начало минуты, «Тфикс» — какая действовала в эту минуту,
//      «событие» — все события минуты через « | », у каждого время
//      (без часов — «таймер 0:41:07» от начала перегона), не больше 400 байт.
//      Старые файлы на 5 колонок («Перегон 2») тоже видны в вебе и скачиваются.
//   4. Журнал Тфикс: последние FIX_EVENTS_RAM событий в памяти (для веба)
//      и файл /log/N.ev рядом с CSV перегона (удаляется вместе с ним).
#include "app.h"
#include <LittleFS.h>
#include <time.h>
#include <stdarg.h>

static const uint16_t RECENT_N = 1800;           // 30 мин × 1 с
static const uint32_t DAY_N    = 17280;          // 24 ч × 5 с
static const uint8_t  DAY_STEP = 5;

struct DaySample { int16_t c, k, u; };           // сотые доли °C, INT16_MIN = нет данных

static Sample    *recent = nullptr;
static uint16_t   recentHead = 0, recentN = 0;   // head — куда писать следующую
static DaySample *day = nullptr;
static uint32_t   dayHead = 0, dayN = 0;
static uint32_t   lastDaySlot = UINT32_MAX;

static bool     fsOk = false;
static String   logPath;                         // пусто — перегон в файл не пишется
static uint32_t minuteSlot = UINT32_MAX;
static float    sum[NCH];
static uint16_t cnt[NCH];

// Строка текущей минуты: время её начала, Тфикс и события
static const uint16_t ROW_EV_MAX = 400;          // байт в колонке «событие» одной строки
static char     rowClock[6] = "";                // ЧЧ:ММ начала минуты (пусто без часов)
static float    rowFix = NAN;                    // Тфикс, которая действует в эту минуту
static char     rowEv[ROW_EV_MAX + 1] = "";
static uint16_t rowEvLen = 0;
static bool     rowEvCut = false;                // строка уже обрезана «…», дальше не пишем

static FixEvent evRing[FIX_EVENTS_RAM];
static uint8_t  evHead = 0, evN = 0;

static int16_t pack(float v) {
  if (isnan(v)) return INT16_MIN;
  return (int16_t)constrain(lroundf(v * 100.0f), -32000L, 32000L);
}
static float unpack(int16_t v) { return v == INT16_MIN ? NAN : v / 100.0f; }

static void rowEvClear() { rowEvLen = 0; rowEv[0] = 0; rowEvCut = false; }

void historyBegin() {
  logPath = "";                                 // файл перегона появится после выбора перегона
  minuteSlot = UINT32_MAX;
  rowEvClear();
  if (!recent) recent = (Sample *)ps_malloc(sizeof(Sample) * RECENT_N);
  if (!recent) recent = (Sample *)malloc(sizeof(Sample) * RECENT_N);
  if (!day) day = (DaySample *)ps_malloc(sizeof(DaySample) * DAY_N);
  if (!day) {
    // Нет PSRAM: в Arduino IDE должно быть «PSRAM: OPI PSRAM» (для N16R8)
    Serial.println(F("[hist] PSRAM не найден! Проверьте Tools -> PSRAM: OPI PSRAM. История за сутки отключена."));
  }

  // LittleFS: раздел «spiffs». Схема разделов в Arduino IDE:
  // Tools -> Partition Scheme -> «8M with spiffs (3MB APP/1.5MB SPIFFS)».
  // При первом запуске раздел форматируется сам (true).
  fsOk = LittleFS.begin(true);
  if (!fsOk) { Serial.println(F("[hist] LittleFS не запустился, лог на flash отключён")); return; }
  if (!LittleFS.exists("/log")) LittleFS.mkdir("/log");
  Serial.printf("[hist] LittleFS: занято %u из %u КБ\n", (unsigned)(LittleFS.usedBytes() / 1024), (unsigned)(LittleFS.totalBytes() / 1024));
}

uint16_t recentCount() { return recentN; }

Sample recentAt(uint16_t back) {
  if (!recent || back >= recentN) return {NAN, NAN, NAN};
  int idx = (int)recentHead - 1 - back;
  if (idx < 0) idx += RECENT_N;
  return recent[idx];
}

// номера файлов лога: самый старый и самый новый
static void scanLogs(uint32_t &lo, uint32_t &hi, uint8_t &n) {
  lo = UINT32_MAX; hi = 0; n = 0;
  File dir = LittleFS.open("/log");
  if (!dir) return;
  for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
    String name = f.name();
    if (!name.endsWith(".csv")) continue;          // .ev — журнал Тфикс того же перегона
    uint32_t num = strtoul(name.c_str(), nullptr, 10);
    if (num) { lo = min(lo, num); hi = max(hi, num); n++; }
  }
}

static void evFlush();
static uint8_t evUnwritten = 0;

// Пишется ли этот перегон в файл (config.h: LOG_RUN1)
static bool logRun(Run r) { return r == RUN_2 || (LOG_RUN1 && r == RUN_1); }

bool historyLogging() { return fsOk && !logPath.isEmpty() && st.run != RUN_NONE; }

static void appendMinute(uint32_t minute) {
  if (!fsOk || logPath.isEmpty()) return;
  File f = LittleFS.open(logPath, "a");
  if (!f) return;
  f.printf("%lu;%s", (unsigned long)minute, rowClock);
  for (uint8_t i = 0; i < NCH; i++) {
    // порядок колонок: куб, царга, датчик 3
    uint8_t ch = i == 0 ? CH_CUBE : i == 1 ? CH_COLUMN : CH_THIRD;
    f.print(';');
    if (cnt[ch]) f.print(fmtNum(sum[ch] / cnt[ch], 2));
  }
  f.print(';');
  if (!isnan(rowFix)) f.print(fmtNum(rowFix, 2));
  f.print(';');
  f.print(rowEv);
  f.print('\n');
  f.close();
}

// Началась новая минута перегона: строку прошлой — в файл, счётчики заново.
// Вызывается и из historyPush, и перед каждым событием, чтобы событие на
// границе минут попало в свою строку.
static void rollMinute() {
  uint32_t el = nowSec() - st.runStart, minute = el / 60;
  if (minute == minuteSlot) return;
  if (minuteSlot != UINT32_MAX) {
    appendMinute(minuteSlot);
    rowEvClear();
  }
  // события, пришедшие до выбора перегона, остаются в первой строке файла
  for (uint8_t i = 0; i < NCH; i++) { sum[i] = 0; cnt[i] = 0; }
  minuteSlot = minute;
  rowClock[0] = 0;
  if (timeValid()) {
    // время начала минуты: сейчас минус сколько секунд от её начала прошло
    time_t t = time(nullptr) - (time_t)(el % 60);
    struct tm tm; localtime_r(&t, &tm);
    strftime(rowClock, sizeof(rowClock), "%H:%M", &tm);
  }
}

// Что видно из файла: первая строка (перегон, дата), шапка (5 или 7 колонок)
// и номер минуты в последней строке (разбор — logInfo ниже)
struct LogInfo { uint8_t run, cols; char start[20]; uint32_t minutes, size; };
static bool logInfo(uint32_t num, LogInfo &li);

void historyRunStarted(bool fresh) {
  // недописанная минута прошлого файла (перегон сменили через экран выбора) — в его файл
  if (!logPath.isEmpty()) {
    if (minuteSlot != UINT32_MAX) appendMinute(minuteSlot);
    rowEvClear();
  }
  minuteSlot = UINT32_MAX;
  rowFix = NAN;
  for (uint8_t i = 0; i < NCH; i++) { sum[i] = 0; cnt[i] = 0; }
  if (!logRun(st.run)) {
    // перегон в лог не пишется: файл не открываем, иначе «Продолжить» после
    // перезагрузки дописало бы строки в файл прошлого второго перегона
    logPath = "";
    rowEvClear();
    evUnwritten = 0;
    return;
  }
  if (!fsOk) return;
  uint32_t lo, hi; uint8_t n;
  scanLogs(lo, hi, n);
  LogInfo li;
  if (!fresh && hi && logInfo(hi, li) && li.cols == 7) {
    // продолжаем последний файл; файл прошивки до 14.10.2026 (5 колонок)
    // не трогаем — перегон после обновления пойдёт в новый файл
    logPath = "/log/" + String(hi) + ".csv";
    evFlush();
    return;
  }
  // новый файл; старые сверх KEEP_LOGS удаляем
  while (n >= KEEP_LOGS && lo <= hi) {
    String old = "/log/" + String(lo) + ".csv";
    if (LittleFS.exists(old)) { LittleFS.remove(old); n--; }
    String oldEv = "/log/" + String(lo) + ".ev";
    if (LittleFS.exists(oldEv)) LittleFS.remove(oldEv);
    lo++;
  }
  logPath = "/log/" + String(hi + 1) + ".csv";
  File f = LittleFS.open(logPath, "w");
  if (f) {
    // дата начала — по часам контроллера (интернет или браузер); без часов «дата неизвестна»
    char start[40] = "дата неизвестна";
    if (timeValid()) {
      time_t t = time(nullptr) - (time_t)(nowSec() - st.runStart);
      struct tm tm; localtime_r(&t, &tm);
      strftime(start, sizeof(start), "начало %d.%m.%Y %H:%M:%S", &tm);
    }
    f.print("\xEF\xBB\xBF");   // BOM, чтобы Excel понял кириллицу
    f.printf("%s перегон №%lu;%s\n", st.run == RUN_1 ? "Первый" : "Второй", (unsigned long)(hi + 1), start);
    f.print("минута;время;куб;царга;датчик 3;Тфикс;событие\n");
    f.close();
  }
  evFlush();
}

void historyPush(const Probe p[NCH]) {
  Sample s = {p[CH_COLUMN].t, p[CH_CUBE].t, p[CH_THIRD].t};
  if (recent) {
    recent[recentHead] = s;
    recentHead = (recentHead + 1) % RECENT_N;
    if (recentN < RECENT_N) recentN++;
  }
  uint32_t now = nowSec();
  uint32_t slot = now / DAY_STEP;
  if (day && slot != lastDaySlot) {
    lastDaySlot = slot;
    day[dayHead] = {pack(s.c), pack(s.k), pack(s.u)};
    dayHead = (dayHead + 1) % DAY_N;
    if (dayN < DAY_N) dayN++;
  }

  // поминутный лог на flash — только пока идёт перегон, который пишется
  if (st.run == RUN_NONE || logPath.isEmpty()) return;
  rollMinute();
  rowFix = st.fix;                               // Тфикс в конце минуты — в её строку
  for (uint8_t i = 0; i < NCH; i++) {
    if (!isnan(p[i].t)) { sum[i] += p[i].t; cnt[i]++; }
  }
}

// ---------------------------------------------------------------------
//  События хода перегона — колонка «событие» CSV
// ---------------------------------------------------------------------
const char *evSrcText(uint8_t src) {
  switch (src) {
    case SRC_WEB:  return "из веба";
    case SRC_BOOT: return "при загрузке";
    default:       return "с экрана";      // и окно «Зафиксировать?» после стабилизации
  }
}

// Дописывает текст в колонку: «;» → «,», «"» → «'», переводы строки → пробел;
// не длиннее ROW_EV_MAX байт, лишнее обрезается по границе символа и «…»
static void rowEvPut(const char *s) {
  for (; *s && !rowEvCut; s++) {
    char c = *s;
    if (c == ';') c = ',';
    else if (c == '"') c = '\'';
    else if ((uint8_t)c < 0x20) c = ' ';
    if (rowEvLen >= ROW_EV_MAX) {
      rowEvLen = ROW_EV_MAX - 3;
      while (rowEvLen && ((uint8_t)rowEv[rowEvLen] & 0xC0) == 0x80) rowEvLen--;   // середина буквы UTF-8
      memcpy(rowEv + rowEvLen, "\xE2\x80\xA6", 3);                                  // «…»
      rowEvLen += 3;
      rowEvCut = true;
    } else {
      rowEv[rowEvLen++] = c;
    }
  }
  rowEv[rowEvLen] = 0;
}

// Событие в строку текущей минуты (без вывода в Serial)
static void rowEvent(const char *text) {
  if (!fsOk) return;
  if (st.run != RUN_NONE) {
    if (logPath.isEmpty()) return;               // этот перегон в файл не пишется
    rollMinute();
  }
  // до выбора перегона событие ждёт в строке и попадёт в первую минуту файла
  char when[40];
  if (timeValid()) { time_t t = time(nullptr); struct tm tm; localtime_r(&t, &tm); strftime(when, sizeof(when), "%H:%M:%S", &tm); }
  else if (st.run != RUN_NONE) snprintf(when, sizeof(when), "таймер %s", fmtHMS(nowSec() - st.runStart).c_str());
  else strlcpy(when, "до выбора перегона", sizeof(when));
  if (rowEvLen) rowEvPut(" | ");
  rowEvPut(when);
  rowEvPut(" ");
  rowEvPut(text);
}

void historyEvent(const char *text) {
  Serial.printf("[log] %s\n", text);
  rowEvent(text);
}

void historyEventf(const char *fmt, ...) {
  char b[256];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(b, sizeof(b), fmt, ap);
  va_end(ap);
  historyEvent(b);
}

bool historyCsvPath(String &path) {
  if (!fsOk || logPath.isEmpty() || !LittleFS.exists(logPath)) return false;
  path = logPath;
  return true;
}

static void printVal(Print &out, float v) {
  if (isnan(v)) out.print(F("null"));
  else out.print(v, 2);
}

// JSON для графиков веба:
// {"now":секунда,"step":шаг_с,"c":[царга],"k":[куб],"u":[датчик 3],"fix":[[сек_назад,Т],...]}
void historyJson(uint32_t minutes, Print &out) {
  uint32_t now = nowSec();
  uint32_t step;
  uint32_t n;
  bool fromRecent;
  if (minutes == 30 || !day) {
    fromRecent = true;
    step = 2;
    n = min<uint32_t>(recentN / step, 900);
  } else {
    fromRecent = false;
    uint32_t span = minutes ? minutes * 60 : (st.run != RUN_NONE || st.lastRun != RUN_NONE ? now - st.runStart : 1800);
    uint32_t avail = dayN * DAY_STEP;
    span = max<uint32_t>(60, min(span, avail));
    uint32_t factor = max<uint32_t>(1, (span / DAY_STEP + 899) / 900);
    step = DAY_STEP * factor;
    n = min<uint32_t>(span / step, dayN / factor);
  }
  out.printf("{\"now\":%lu,\"step\":%lu", (unsigned long)now, (unsigned long)step);
  const char *keys[3] = {"c", "k", "u"};
  for (uint8_t key = 0; key < 3; key++) {
    out.printf(",\"%s\":[", keys[key]);
    for (uint32_t i = 0; i < n; i++) {
      uint32_t back = n - 1 - i;             // от старых к новым
      float v;
      if (fromRecent) {
        Sample s = recentAt(back * step);
        v = key == 0 ? s.c : key == 1 ? s.k : s.u;
      } else {
        int32_t idx = (int32_t)dayHead - 1 - (int32_t)(back * (step / DAY_STEP));
        while (idx < 0) idx += DAY_N;
        const DaySample &d = day[idx];
        v = unpack(key == 0 ? d.c : key == 1 ? d.k : d.u);
      }
      if (i) out.print(',');
      printVal(out, v);
    }
    out.print(']');
  }
  out.print(F(",\"fix\":["));
  for (uint8_t i = 0; i < st.nFixes; i++) {
    if (i) out.print(',');
    out.printf("[%lu,", (unsigned long)(now - st.fixes[i].t));
    printVal(out, st.fixes[i].v);
    out.print(']');
  }
  out.print(F("]}"));
}

// ---------------------------------------------------------------------
//  Журнал событий Тфикс
// ---------------------------------------------------------------------
static const char *evKindText(uint8_t k) {
  switch (k) {
    case EV_FIX:     return "фиксация";
    case EV_CLEAR:   return "сброс";
    case EV_CONFIRM: return "подтверждение";
    case EV_REFUSE:  return "отказ";
    case EV_RESTORE: return "восстановлена из памяти";
    case EV_CORRUPT: return "запись испорчена";
    case EV_ASK:     return "стабильно, просит зафиксировать";
    default:         return "?";
  }
}
static const char *evKindKey(uint8_t k) {
  static const char *keys[] = {"fix", "clear", "confirm", "refuse", "restore", "corrupt", "ask"};
  return k < sizeof(keys) / sizeof(keys[0]) ? keys[k] : "?";
}
static const char *evSrcKey(uint8_t s) {
  static const char *keys[] = {"screen", "web", "stab", "boot"};
  return s < 4 ? keys[s] : "?";
}
static String evNum(float v) { return isnan(v) ? String("") : fmtNum(v, 2); }

// файл журнала рядом с CSV текущего перегона
static void evAppend(const FixEvent &e) {
  String path = logPath.substring(0, logPath.length() - 4) + ".ev";
  bool fresh = !LittleFS.exists(path);
  File f = LittleFS.open(path, "a");
  if (!f) return;
  if (fresh) {
    f.print("\xEF\xBB\xBF");
    f.print("время;событие;была Тфикс;стала Тфикс;царга;источник;причина\n");
  }
  String when = evTimeText(e.at, e.clock, true);
  const char *why = e.kind == EV_REFUSE ? fixErrText((FixErr)e.err, e.pstate) : "";
  f.printf("%s;%s;%s;%s;%s;%s;%s\n", when.c_str(), evKindText(e.kind), evNum(e.oldV).c_str(), evNum(e.newV).c_str(),
           evNum(e.cur).c_str(), fixSrcText(e.src), why);
  f.close();
}

// События до выбора перегона (например, «запись испорчена» при включении):
// файла ещё нет, держим их в памяти и дописываем, когда перегон начнётся
// (счётчик evUnwritten объявлен выше, у historyRunStarted)

static void evFlush() {
  if (!fsOk || logPath.isEmpty()) return;
  for (uint8_t k = evUnwritten; k > 0; k--) evAppend(evRing[(evHead + FIX_EVENTS_RAM - k) % FIX_EVENTS_RAM]);
  evUnwritten = 0;
}

// Текст события Тфикс для колонки «событие»
static void fixEvRow(const FixEvent &e) {
  char b[160];
  const char *src = evSrcText(e.src);
  switch (e.kind) {
    case EV_FIX:
      if (isnan(e.oldV)) snprintf(b, sizeof(b), "фиксация Тфикс %s (%s)", evNum(e.newV).c_str(), src);
      else snprintf(b, sizeof(b), "фиксация Тфикс %s → %s (%s)", evNum(e.oldV).c_str(), evNum(e.newV).c_str(), src);
      break;
    case EV_CLEAR:   snprintf(b, sizeof(b), "Тфикс %s сброшена (%s)", evNum(e.oldV).c_str(), src); break;
    case EV_CONFIRM: snprintf(b, sizeof(b), "Тфикс %s подтверждена после перезагрузки (%s)", evNum(e.oldV).c_str(), src); break;
    case EV_REFUSE:  snprintf(b, sizeof(b), "фиксация отклонена (%s): %s", src, fixErrText((FixErr)e.err, e.pstate)); break;
    case EV_RESTORE: snprintf(b, sizeof(b), "Тфикс %s из памяти, ждёт подтверждения", evNum(e.oldV).c_str()); break;
    case EV_CORRUPT: snprintf(b, sizeof(b), "запись перегона в памяти испорчена, перегон с нуля"); break;
    case EV_ASK:     snprintf(b, sizeof(b), "стабильно %u мин, просит зафиксировать, царга %s", cfg.stabWindow / 60, evNum(e.cur).c_str()); break;
    default: return;
  }
  rowEvent(b);
}

void historyEvent(const FixEvent &e) {
  evRing[evHead] = e;
  evHead = (evHead + 1) % FIX_EVENTS_RAM;
  if (evN < FIX_EVENTS_RAM) evN++;

  String when = evTimeText(e.at, e.clock, true);
  const char *why = e.kind == EV_REFUSE ? fixErrText((FixErr)e.err, e.pstate) : "";
  Serial.printf("[fix] %s %s: было %s, стало %s, царга %s, %s%s%s\n", when.c_str(), evKindText(e.kind),
                isnan(e.oldV) ? "—" : evNum(e.oldV).c_str(), isnan(e.newV) ? "—" : evNum(e.newV).c_str(),
                isnan(e.cur) ? "—" : evNum(e.cur).c_str(), fixSrcText(e.src), *why ? " — " : "", why);

  // в колонку «событие» CSV; Тфикс строки — уже после этого события
  fixEvRow(e);
  if (historyLogging()) rowFix = st.fix;

  // если LittleFS не запустился — только память
  if (!fsOk) return;
  if (logPath.isEmpty()) {
    // перегон ещё не выбран: в .ev попадёт, когда начнётся (перегон без лога — не попадёт)
    if (st.run == RUN_NONE && evUnwritten < FIX_EVENTS_RAM) evUnwritten++;
    return;
  }
  evAppend(e);
}

static void jsonStr(Print &out, const char *v) {
  out.print('"');
  for (const char *c = v; *c; c++) {
    if (*c == '"' || *c == '\\') out.print('\\');
    if ((uint8_t)*c >= 0x20) out.print(*c);
  }
  out.print('"');
}

// [{"at":…,"clock":1,"time":"13.10 14:05:22","kind":"fix","what":"фиксация","old":78.4,"new":78.42,
//   "cur":78.42,"src":"screen","from":"с экрана","err":""}, …] — новые сверху
void eventsJson(Print &out) {
  out.print('[');
  for (uint8_t i = 0; i < evN; i++) {
    int idx = (int)evHead - 1 - i;
    if (idx < 0) idx += FIX_EVENTS_RAM;
    const FixEvent &e = evRing[idx];
    if (i) out.print(',');
    out.printf("{\"at\":%lu,\"clock\":%u,\"time\":", (unsigned long)e.at, e.clock);
    jsonStr(out, evTimeText(e.at, e.clock, true).c_str());
    out.print(F(",\"kind\":\"")); out.print(evKindKey(e.kind));
    out.print(F("\",\"what\":")); jsonStr(out, evKindText(e.kind));
    out.print(F(",\"old\":")); printVal(out, e.oldV);
    out.print(F(",\"new\":")); printVal(out, e.newV);
    out.print(F(",\"cur\":")); printVal(out, e.cur);
    out.print(F(",\"src\":\"")); out.print(evSrcKey(e.src));
    out.print(F("\",\"from\":")); jsonStr(out, fixSrcText(e.src));
    out.print(F(",\"err\":")); jsonStr(out, e.kind == EV_REFUSE ? fixErrText((FixErr)e.err, e.pstate) : "");
    out.print('}');
  }
  out.print(']');
}

// ---------------------------------------------------------------------
//  Прошлые перегоны для веба: список, скачивание, удаление
// ---------------------------------------------------------------------
static uint32_t curLogNum() { return logPath.isEmpty() ? 0 : strtoul(logPath.c_str() + 5, nullptr, 10); }

// номера файлов /log/N.csv по убыванию, не больше max
static uint8_t listLogs(uint32_t *nums, uint8_t max) {
  uint8_t k = 0;
  File dir = LittleFS.open("/log");
  if (!dir) return 0;
  for (File f = dir.openNextFile(); f; f = dir.openNextFile()) {
    String name = f.name();
    if (!name.endsWith(".csv")) continue;
    uint32_t num = strtoul(name.c_str(), nullptr, 10);
    if (!num) continue;
    uint8_t i = k < max ? k++ : max;             // вставка по убыванию; самый старый выпадает
    while (i > 0 && nums[i - 1] < num) { if (i < max) nums[i] = nums[i - 1]; i--; }
    if (i < max) nums[i] = num;
  }
  return k;
}

// Разбор файла лога (struct LogInfo — выше, перед historyRunStarted)
static bool logInfo(uint32_t num, LogInfo &li) {
  memset(&li, 0, sizeof(li));
  char path[24];
  snprintf(path, sizeof(path), "/log/%lu.csv", (unsigned long)num);
  if (!LittleFS.exists(path)) return false;      // без лишней ошибки open() в мониторе порта
  File f = LittleFS.open(path, "r");
  if (!f) return false;
  li.size = f.size();
  static char buf[600];                          // строка с событиями — до ~460 байт
  size_t k = f.read((uint8_t *)buf, 200);
  buf[k] = 0;
  char *p = buf;
  if (!strncmp(p, "\xEF\xBB\xBF", 3)) p += 3;
  char *nl = strchr(p, '\n');
  if (nl) {
    *nl = 0;
    static const char OLD[] = "Перегон ", NEWD[] = ";начало ";
    if (!strncmp(p, OLD, sizeof(OLD) - 1)) li.run = atoi(p + sizeof(OLD) - 1);   // файл прошивки до 14.10.2026
    else {
      li.run = !strncmp(p, "Первый", strlen("Первый")) ? 1 : 2;
      const char *d = strstr(p, NEWD);
      // «14.10.2026 09:30:00»: берём, только если похоже на дату
      if (d && strlen(d + sizeof(NEWD) - 1) >= 19) {
        d += sizeof(NEWD) - 1;
        bool ok = true;
        for (uint8_t i = 0; i < 19; i++) {
          char c = d[i], want = i == 2 || i == 5 ? '.' : i == 10 ? ' ' : i == 13 || i == 16 ? ':' : '0';
          ok = ok && (want == '0' ? c >= '0' && c <= '9' : c == want);
        }
        if (ok) { memcpy(li.start, d, 19); li.start[19] = 0; }
      }
    }
    // шапка: 4 «;» — старый файл на 5 колонок, 6 — на 7
    uint8_t semi = 0;
    for (char *c = nl + 1; *c && *c != '\n'; c++) semi += *c == ';';
    li.cols = semi + 1;
  }
  // последняя строка: «минута;…» — длительность = минута + 1
  size_t from = li.size > sizeof(buf) - 1 ? li.size - (sizeof(buf) - 1) : 0;
  f.seek(from);
  k = f.read((uint8_t *)buf, sizeof(buf) - 1);
  buf[k] = 0;
  int end = (int)k - 1;
  while (end >= 0 && (buf[end] == '\n' || buf[end] == '\r')) end--;
  int s = end;
  while (s >= 0 && buf[s] != '\n') s--;
  s++;
  if (s <= end && buf[s] >= '0' && buf[s] <= '9') li.minutes = strtoul(buf + s, nullptr, 10) + 1;
  f.close();
  return true;
}

// {"fs":true,"run1":false,"logs":[{"n":18,"run":2,"start":"14.10.2026 12:37:00","min":36,"size":1234,
//   "cols":7,"cur":true,"live":true,"del":false},…]} — новые сверху; start пустой, если дата неизвестна.
// cur — в этот файл пишется (или допишется «Продолжить»), live — перегон идёт сейчас,
// del — можно удалить (не текущий и не последний).
void logsJson(Print &out) {
  out.printf("{\"fs\":%s,\"run1\":%s,\"keep\":%u,\"logs\":[", fsOk ? "true" : "false", LOG_RUN1 ? "true" : "false", (unsigned)KEEP_LOGS);
  if (fsOk) {
    uint32_t nums[20];
    uint8_t k = listLogs(nums, 20);
    uint32_t cur = curLogNum();
    bool first = true;
    for (uint8_t i = 0; i < k; i++) {
      LogInfo li;
      if (!logInfo(nums[i], li)) continue;
      bool isCur = nums[i] == cur, live = isCur && st.run != RUN_NONE;
      if (live) li.minutes = (nowSec() - st.runStart) / 60;
      out.printf("%s{\"n\":%lu,\"run\":%u,\"start\":\"%s\",\"min\":%lu,\"size\":%lu,\"cols\":%u,\"cur\":%s,\"live\":%s,\"del\":%s}",
                 first ? "" : ",", (unsigned long)nums[i], li.run, li.start, (unsigned long)li.minutes, (unsigned long)li.size, li.cols,
                 isCur ? "true" : "false", live ? "true" : "false", !isCur && i > 0 ? "true" : "false");
      first = false;
    }
  }
  out.print(F("]}"));
}

bool historyLogFile(uint32_t n, String &path, String &name) {
  if (!fsOk) return false;
  if (!n) n = curLogNum();
  LogInfo li;
  if (!n || !logInfo(n, li)) return false;
  char b[48];
  if (li.start[0])   // «14.10.2026 12:37:00» -> kolonna-18_2026-10-14_12-37.csv
    snprintf(b, sizeof(b), "kolonna-%lu_%.4s-%.2s-%.2s_%.2s-%.2s.csv", (unsigned long)n, li.start + 6, li.start + 3, li.start, li.start + 11, li.start + 14);
  else
    snprintf(b, sizeof(b), "kolonna-%lu.csv", (unsigned long)n);
  path = "/log/" + String(n) + ".csv";
  name = b;
  return true;
}

LogDel historyLogDelete(uint32_t n) {
  if (!fsOk || !n) return LOGDEL_NONE;
  String path = "/log/" + String(n) + ".csv";
  if (!LittleFS.exists(path)) return LOGDEL_NONE;
  if (n == curLogNum()) return LOGDEL_CURRENT;
  // самый большой номер «Продолжить» после перезагрузки допишет — его не трогаем
  uint32_t lo, hi; uint8_t k;
  scanLogs(lo, hi, k);
  if (n == hi) return LOGDEL_LAST;
  LittleFS.remove(path);
  String ev = "/log/" + String(n) + ".ev";
  if (LittleFS.exists(ev)) LittleFS.remove(ev);
  Serial.printf("[hist] перегон №%lu удалён из веба\n", (unsigned long)n);
  return LOGDEL_OK;
}
