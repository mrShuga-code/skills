// led.cpp — RGB-светодиод на плате (WS2812 на GPIO48/38) как индикатор для отладки.
//
//   зелёный горит        — подключён к Wi-Fi, аварий нет
//   синий мигает (1 Гц)  — ищет домашнюю сеть Wi-Fi
//   синий горит          — поднята своя точка доступа «Kolonna-setup»
//   красный мигает (4 Гц)— авария: неисправен датчик или тревога «Хвосты»
//                          (авария важнее сети: пока она есть — только красный)
//
// Пин и яркость — в config.h (STATUS_LED_PIN, STATUS_LED_BRIGHT). Если светодиод
// не горит совсем — на вашей ревизии платы он на GPIO38, поставьте 38.
// Цвет пишется в светодиод только когда меняется (это занимает ~30 мкс).
#include "app.h"

static uint32_t shown = 0xFFFFFFFF;   // какой цвет сейчас горит (0xRRGGBB)

static void ledWrite(uint32_t rgb) {
  if (rgb == shown) return;
  shown = rgb;
#if STATUS_LED_PIN >= 0
  rgbLedWrite(STATUS_LED_PIN, (rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
#endif
}

static uint32_t color(uint8_t r, uint8_t g, uint8_t b) {
  const uint16_t k = STATUS_LED_BRIGHT;
  return ((uint32_t)(r * k / 255) << 16) | ((uint32_t)(g * k / 255) << 8) | (uint32_t)(b * k / 255);
}

// Авария — то, что на экране красное и не проходит само: неисправный датчик
// (любой включённый, в любом перегоне) или тревога «Хвосты» во втором перегоне.
static bool ledAlarm() {
  return st.faultMask != 0 || (st.run == RUN_2 && st.mode == MODE_TAILS);
}

void ledBegin() { ledWrite(0); }

void ledLoop() {
  static uint32_t last = 0;
  uint32_t t = millis();
  if (t - last < 25) return;
  last = t;
  uint32_t c;
  if (ledAlarm()) {
    c = (t / 125) % 2 ? 0 : color(255, 0, 0);            // часто: 4 раза в секунду
  } else {
    switch (netState()) {
      case NET_ONLINE: c = color(0, 255, 0); break;
      case NET_AP:     c = color(0, 0, 255); break;
      default:         c = (t / 500) % 2 ? 0 : color(0, 0, 255); break;   // раз в секунду
    }
  }
  ledWrite(c);
}
