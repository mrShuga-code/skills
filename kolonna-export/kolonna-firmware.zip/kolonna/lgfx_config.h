// =====================================================================
//  lgfx_config.h — описание дисплея и тача для библиотеки LovyanGFX.
//  Основано на настройках из статьи mostlybuilds, перенесено на ESP32-S3:
//  у S3 нет шины VSPI, поэтому экран сидит на SPI2 (GPIO 9–14).
//  Часто меняемые параметры (инверсия, поворот, частота, тач) вынесены
//  в config.h — правьте их там.
// =====================================================================
#pragma once

#define LGFX_USE_V1
#include <LovyanGFX.hpp>
#include "config.h"

class LGFX : public lgfx::LGFX_Device
{
  lgfx::Panel_ILI9341 _panel;
  lgfx::Bus_SPI       _bus;
  lgfx::Light_PWM     _light;
  lgfx::Touch_FT5x06  _touch;   // FT6336 работает через этот же драйвер

public:
  LGFX(void)
  {
    { // --- шина SPI экрана ---
      auto cfg = _bus.config();
      cfg.spi_host   = SPI2_HOST;        // на S3 только SPI2/SPI3; SPI3 занят датчиками
      cfg.spi_mode   = 0;
      cfg.freq_write = LCD_SPI_FREQ;     // см. config.h, если экран «сыпется»
      cfg.freq_read  = 16000000;
      cfg.spi_3wire  = false;
      cfg.use_lock   = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO; // на S3 обязательно AUTO
      cfg.pin_sclk = PIN_LCD_SCK;
      cfg.pin_mosi = PIN_LCD_MOSI;
      cfg.pin_miso = PIN_LCD_MISO;
      cfg.pin_dc   = PIN_LCD_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    { // --- сама матрица ---
      auto cfg = _panel.config();
      cfg.pin_cs   = PIN_LCD_CS;
      cfg.pin_rst  = PIN_LCD_RST;
      cfg.pin_busy = -1;
      cfg.memory_width  = 240;           // ILI9341 «по паспорту» вертикальный 240×320
      cfg.memory_height = 320;
      cfg.panel_width   = 240;
      cfg.panel_height  = 320;
      cfg.offset_x = 0;                  // если картинка сдвинута на несколько точек
      cfg.offset_y = 0;                  //   и по краю полоса мусора — подберите здесь
      cfg.offset_rotation  = LCD_OFFSET_ROTATION;  // ПОВОРОТ: см. config.h
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits  = 1;
      cfg.readable   = true;
      cfg.invert     = LCD_INVERT;       // ИНВЕРСИЯ ЦВЕТОВ: см. config.h
      cfg.rgb_order  = LCD_RGB_ORDER;    // КРАСНЫЙ/СИНИЙ перепутаны: см. config.h
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;            // SD-карту экрана не используем
      _panel.config(cfg);
    }
    { // --- подсветка, ШИМ на GPIO21 ---
      auto cfg = _light.config();
      cfg.pin_bl      = PIN_LCD_BL;
      cfg.invert      = LCD_BL_INVERT;
      cfg.freq        = 12000;           // выше слышимого писка
      cfg.pwm_channel = 7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    { // --- тач FT6336 по I2C ---
      auto cfg = _touch.config();
      cfg.x_min = TOUCH_X_MIN;
      cfg.x_max = TOUCH_X_MAX;
      cfg.y_min = TOUCH_Y_MIN;
      cfg.y_max = TOUCH_Y_MAX;
      cfg.pin_int = PIN_TOUCH_INT;
      cfg.pin_rst = PIN_TOUCH_RST;
      cfg.bus_shared = false;
      cfg.offset_rotation = TOUCH_OFFSET_ROTATION;  // НАЖАТИЯ НЕ ТАМ: см. config.h
      cfg.i2c_port = 1;
      cfg.i2c_addr = TOUCH_I2C_ADDR;
      cfg.pin_sda  = PIN_TOUCH_SDA;
      cfg.pin_scl  = PIN_TOUCH_SCL;
      cfg.freq     = 400000;
      _touch.config(cfg);
      _panel.setTouch(&_touch);
    }
    setPanel(&_panel);
  }
};
