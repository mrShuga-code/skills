// logic.cpp — логика перегонов (по документу «Логика контроллера колонны»).
//
//  Первый перегон: куб и царга только цветом, датчик 3 — воздух.
//    Звук один — «Включите охлаждение», когда куб дошёл до порога.
//  Второй перегон: царга по отклонению от Тфикс, тревога «Хвосты»,
//    стабилизация с запросом оператору зафиксировать Тфикс, зоны куба, узел отбора.
//
//  Тфикс (ТЗ «Зафиксировать Тфикс», редакция 2):
//    - ставится только командой: экран, веб или «Зафиксировать» в окне
//      после стабилизации; значение — текущая температура царги (среднее 5 с);
//    - фиксировать можно, только когда данные царги достоверны (fixCheck);
//    - после перезагрузки восстанавливается из NVS и ждёт подтверждения,
//      до подтверждения «Хвосты» не считаются;
//    - пока датчик царги неисправен или данные устарели, Тфикс хранится,
//      а оценка «Хвостов» на паузе;
//    - каждое действие пишется в журнал (history.cpp) и сразу в NVS.
//
//  Ход перегона (старт, охлаждение, Тфикс, жёлтая зона, «Хвосты», сброс тревоги,
//  стабилизация, датчики) пишется событиями в колонку «событие» CSV (historyEvent).
//
//  Помощь на теле (план развития, 14.10.2026):
//    - отметки отбора на плитке УО: головы / тело / закрыт (cmdUoTap, «Хвосты»
//      сами ставят «ЗАКРЫТ», фиксация Тфикс — «ТЕЛО»), каждая — в лог с кубом;
//    - «царга вернулась к Тфикс»: в окне «Зафиксировать?» строка «было 75,30,
//      сейчас 75,31 (+0,01)», в лог — через сколько после «Хвостов» царга снова
//      в зелёной зоне старой Тфикс (раз за тревогу);
//    - «пар в узле отбора»: на разгоне второго перегона датчик 3 впервые выше
//      cfg.steamC — серия сигналов, надпись до «Понятно» (или до фиксации Тфикс),
//      раз за перегон; «Включите охлаждение» важнее и показывается первым.
//
//  logicTick() вызывается раз в секунду, когда датчики выдали новое среднее,
//  logicLoop() — на каждом проходе loop(): следит, что данные не устарели.
#include "app.h"
#include <time.h>

RunState st;

static SavedRun saved;          // что было до перезагрузки (из NVS)
static bool     savedValid = false;
static uint32_t lastStore = 0;  // когда последний раз писали таймер во flash
static uint32_t lastDataMs = 0; // millis(), когда пришло последнее среднее от датчиков
static uint32_t coolAt = 0;     // когда прозвучало «Включите охлаждение» (для лога)
static uint32_t yellowAt = UINT32_MAX;   // когда в лог ушла «жёлтая зона» (UINT32_MAX — ещё нет)
static uint8_t  probeLogged = 0;         // какие неисправности датчиков уже записаны в лог
static uint32_t probeLogAt[NCH];         // когда по каналу последний раз писали в лог
static uint32_t tailsAt = 0;             // когда сработали «Хвосты» (для «царга вернулась к Тфикс»)
static bool     returnLogged = true;     // возврат царги к старой Тфикс после этих «Хвостов» уже записан
static bool     steamCheck = false;      // после перезагрузки: первое годное чтение датчика 3 решит, был ли пар уже
static bool     steamShown = false;      // надпись «пар в узле отбора» уже показана (сигнал дан)

// Коридор стабилизации: температура царги не должна выйти за 0,05 °C
static const float CORRIDOR = 0.05f;

uint32_t nowSec() { return millis() / 1000; }

static float r2(float v) { return roundf(v * 100.0f) / 100.0f; }

// Для текстов лога: куб с одним знаком («——» без данных) и «50 с» / «1 мин 20 с» / «2 ч 5 мин»
static String cubeText() { return fmtNum(st.p[CH_CUBE].state == PROBE_OK ? st.p[CH_CUBE].t : NAN, 1); }
static String durText(uint32_t s) {
  char b[24];
  if (s < 60) snprintf(b, sizeof(b), "%lu с", (unsigned long)s);
  else if (s < 3600 && s % 60) snprintf(b, sizeof(b), "%lu мин %lu с", (unsigned long)(s / 60), (unsigned long)(s % 60));
  else if (s < 3600) snprintf(b, sizeof(b), "%lu мин", (unsigned long)(s / 60));
  else snprintf(b, sizeof(b), "%lu ч %lu мин", (unsigned long)(s / 3600), (unsigned long)(s / 60 % 60));
  return String(b);
}

// Отметка отбора на плитке УО: новое состояние и событие в лог с температурой куба
static void uoSet(UoState s, const char *what) {
  st.uo = s;
  st.uoAt = st.now;
  historyEventf("%s · куб %s", what, cubeText().c_str());
  uiMarkDirty();
}

static void storeRun() {
  if (st.run == RUN_NONE) return;
  // Тфикс из памяти ждёт подтверждения: запись в NVS не трогаем, пока
  // оператор не выберет «Подтвердить», «Заново» или «Сбросить»
  if (st.fixConfirm) return;
  SavedRun r;
  memset(&r, 0, sizeof(r));
  r.run = st.run;
  r.elapsed = st.now - st.runStart;
  r.hasFix = !isnan(st.fix);
  r.fix = st.fix;
  r.fixTime = st.fixTime;
  r.fixSrc = st.fixSrc;
  r.fixClock = st.fixClock;
  r.cool = st.cool;
  savedRunStore(r);
  lastStore = st.now;
}

// Время события: часы, если время известно, иначе секунда перегона
static void stamp(uint32_t &at, uint8_t &clock) {
  if (timeValid()) { at = (uint32_t)time(nullptr); clock = 1; }
  else { at = st.run != RUN_NONE ? st.now - st.runStart : 0; clock = 0; }
}

static void logEvent(FixEvKind kind, uint8_t src, FixErr err, float oldV, float newV) {
  FixEvent e;
  memset(&e, 0, sizeof(e));
  stamp(e.at, e.clock);
  e.kind = kind; e.src = src; e.err = err;
  e.oldV = oldV; e.newV = newV;
  e.cur = st.p[CH_COLUMN].state == PROBE_OK ? st.p[CH_COLUMN].t : NAN;
  e.pstate = st.p[CH_COLUMN].state;
  historyEvent(e);
}

static void pushFix(float v) {
  if (st.nFixes == MAX_FIXES) {
    memmove(&st.fixes[0], &st.fixes[1], sizeof(FixMark) * (MAX_FIXES - 1));
    st.nFixes--;
  }
  st.fixes[st.nFixes++] = {st.now, v};
}

void logicBegin() {
  memset(&st, 0, sizeof(st));
  st.run = RUN_NONE;
  st.lastRun = RUN_NONE;
  st.fix = NAN;
  for (uint8_t i = 0; i < NCH; i++) { st.p[i].t = NAN; st.p[i].state = PROBE_WAIT; }
  lastDataMs = 0;
  SavedLoad res = savedRunLoad(saved);
  savedValid = res == SAVED_OK;
  if (savedValid) {
    Serial.printf("[run] до перезагрузки шёл перегон %u, таймер %lu с\n", saved.run, (unsigned long)saved.elapsed);
  } else if (res == SAVED_BAD) {
    // контрольная сумма не сошлась или значения бессмысленные: ни Тфикс, ни таймер не берём
    Serial.println(F("[run] запись перегона в NVS испорчена, начинаем с нуля"));
    logEvent(EV_CORRUPT, SRC_BOOT, FIX_OK, NAN, NAN);
  }
}

// ---------------------------------------------------------------------
//  Зоны и цвета
// ---------------------------------------------------------------------
static const float *cubeZones() { return st.run == RUN_1 ? cfg.z1 : cfg.z2; }

float cubeGreenFrom() { return cubeZones()[0]; }

Tone cubeTone(float t) {
  if (isnan(t)) return TONE_GREY;
  const float *z = cubeZones();
  if (t < z[0]) return TONE_COLD;
  if (t < z[1]) return TONE_OK;
  if (t < z[2]) return TONE_WARN;
  if (t < z[3]) return TONE_HOT;
  return TONE_BAD;
}

const char *cubeZoneText(float t, char *buf, size_t n) {
  if (isnan(t)) { snprintf(buf, n, "нет данных"); return buf; }
  const float *z = cubeZones();
  bool words = st.run != RUN_1;    // во втором перегоне — словами, как в макете
  if (t < z[0]) snprintf(buf, n, words ? "разогрев" : "ниже %s", fmtNum(z[0], 0).c_str());
  else if (t < z[1]) {
    if (words) snprintf(buf, n, "рабочая зона");
    else snprintf(buf, n, "%s–%s", fmtNum(z[0], 0).c_str(), fmtNum(z[1] - 0.1f, 1).c_str());
  }
  else if (t < z[2]) snprintf(buf, n, "%s–%s", fmtNum(z[1], 1).c_str(), fmtNum(z[2] - 0.1f, 1).c_str());
  else if (t < z[3]) snprintf(buf, n, "%s–%s", fmtNum(z[2], 1).c_str(), fmtNum(z[3] - 0.1f, 1).c_str());
  else snprintf(buf, n, "от %s", fmtNum(z[3], 1).c_str());
  return buf;
}

Tone col1Tone(float t) {
  if (isnan(t)) return TONE_GREY;
  return t < cfg.col1 ? TONE_COLD : TONE_OK;
}

Tone columnTone() {
  float t = st.p[CH_COLUMN].t;
  if (isnan(t) || !columnValid()) return TONE_GREY;   // нет достоверных данных
  if (st.fixConfirm) return TONE_WHITE;               // Тфикс из памяти, оценки нет
  if (st.mode == MODE_STAB) return TONE_STAB;
  if (st.mode == MODE_TAILS) return TONE_BAD;
  if (isnan(st.fix)) return TONE_WHITE;          // Тфикс ещё не задана
  float d = r2(t - st.fix);
  if (d > cfg.red + 1e-4f) return TONE_BAD;
  if (d > cfg.green + 1e-4f) return TONE_WARN;
  return TONE_OK;                                // до +0,05 и любое падение
}

bool alarmTails() { return st.run == RUN_2 && st.mode == MODE_TAILS && cfg.buzzer; }

bool alarmFaultSound() {
  // В первом перегоне тревог нет (только охлаждение), неисправность видна серым «——»
  return st.run == RUN_2 && cfg.buzzer && (st.faultMask & ~st.faultAck);
}

// ---------------------------------------------------------------------
//  Команды (экран и веб вызывают одни и те же)
// ---------------------------------------------------------------------
bool hasSavedRun(Run &r, uint32_t &elapsed) {
  if (st.lastRun != RUN_NONE) { r = st.lastRun; elapsed = st.now - st.runStart; return true; }
  if (savedValid) { r = (Run)saved.run; elapsed = saved.elapsed; return true; }
  return false;
}

void cmdChooseRun(Run r) {
  if (r != RUN_1 && r != RUN_2) return;
  st.now = nowSec();
  if (r == st.lastRun) {
    // тот же перегон, что шёл до этого: продолжаем вместе с таймером
    st.run = r;
    Serial.printf("[run] продолжаем перегон %u\n", r);
    historyEventf("продолжение с экрана выбора, куб %s", cubeText().c_str());
  } else if (st.lastRun == RUN_NONE && savedValid && saved.run == r) {
    // после перезагрузки выбрали тот же перегон: таймер и Тфикс из flash
    st.run = r;
    // аптайм после перезагрузки меньше прошедшего времени перегона: разность
    // «уходит за ноль» по модулю 2^32, а все потребители считают now - runStart
    // в uint32_t, поэтому таймер продолжается с сохранённого значения
    st.runStart = st.now - saved.elapsed;
    st.mode = MODE_DRAW;
    st.redSince = st.stabStart = st.stableFor = 0;
    st.newUntil = 0;
    st.ask = false;
    st.fix = r == RUN_2 && saved.hasFix ? saved.fix : NAN;
    st.fixTime = saved.fixTime;
    st.fixSrc = saved.fixSrc;
    st.fixClock = saved.fixClock;
    st.cool = (CoolState)saved.cool;
    if (st.cool == COOL_ALERT) st.cool = COOL_IDLE;   // снова проверится по температуре
    st.nFixes = 0;
    if (!isnan(st.fix)) pushFix(st.fix);
    probeLogged = 0;                    // неисправные сейчас датчики попадут в лог заново
    memset(probeLogAt, 0, sizeof(probeLogAt));
    st.uo = UO_NONE; st.uoAt = 0;       // отметка отбора только в памяти: после перезагрузки её нет
    returnLogged = true;
    // пар: первое чтение датчика 3 покажет, был ли он уже (тогда сигнала не будет —
    // он был до перезагрузки). При Тфикс из памяти сигнал и так молчит, пока её не
    // сбросят; подтверждение Тфикс гасит его совсем (разгон позади)
    st.steamFired = false;
    st.steamMsg = false;
    steamCheck = true;
    steamShown = false;
    historyRunStarted(false);
    Serial.printf("[run] перегон %u продолжен после перезагрузки\n", r);
    historyEventf("продолжение после перезагрузки, куб %s", cubeText().c_str());
    if (!isnan(st.fix)) {
      // Тфикс видна, но «Хвосты» не считаются, пока оператор не подтвердит;
      // запись в NVS до его решения остаётся как есть
      st.fixConfirm = true;
      logEvent(EV_RESTORE, SRC_BOOT, FIX_OK, st.fix, st.fix);
    }
  } else {
    // новый перегон: всё с нуля
    st.run = r;
    st.runStart = st.now;
    st.mode = MODE_DRAW;
    st.fix = NAN;
    st.redSince = st.stabStart = st.stableFor = 0;
    st.spread = 0; st.spreadReady = false;
    st.newUntil = 0;
    st.fixConfirm = st.ask = false;
    st.fixTime = 0; st.fixSrc = SRC_SCREEN; st.fixClock = 0;
    st.cool = COOL_IDLE;
    st.nFixes = 0;
    probeLogged = 0;
    memset(probeLogAt, 0, sizeof(probeLogAt));
    st.uo = UO_NONE; st.uoAt = 0;
    returnLogged = true;
    st.steamFired = st.steamMsg = false;
    steamCheck = steamShown = false;
    historyRunStarted(true);
    Serial.printf("[run] новый перегон %u\n", r);
    historyEventf("старт перегона, куб %s", cubeText().c_str());
  }
  savedValid = false;
  st.lastRun = r;
  storeRun();
  uiCloseMenu();
  uiMarkDirty();
}

void cmdToSelect() {
  if (st.run == RUN_NONE) return;
  historyEvent("выход на экран выбора перегона");
  storeRun();
  st.lastRun = st.run;
  st.run = RUN_NONE;
  uiCloseMenu();
  uiMarkDirty();
}

// ---------------------------------------------------------------------
//  Тфикс: проверка данных, фиксация, подтверждение, сброс
// ---------------------------------------------------------------------
bool columnValid() {
  const Probe &c = st.p[CH_COLUMN];
  return c.state == PROBE_OK && !isnan(c.t) && !st.stale;
}

FixErr fixCheck() {
  if (st.run != RUN_2) return FIX_ERR_RUN;
  const Probe &c = st.p[CH_COLUMN];
  if (c.state != PROBE_OK || isnan(c.t)) return FIX_ERR_SENSOR;
  if (st.stale) return FIX_ERR_STALE;
  return FIX_OK;
}

FixState fixState() {
  if (isnan(st.fix)) return FS_NONE;
  if (st.fixConfirm) return FS_CONFIRM;
  if (!columnValid()) return FS_NODATA;
  return FS_ACTIVE;
}

const char *fixStateText(FixState s) {
  switch (s) {
    case FS_ACTIVE:  return "Активна";
    case FS_NODATA:  return "Нет достоверных данных";
    case FS_CONFIRM: return "Требуется подтверждение";
    default:         return "Не зафиксирована";
  }
}

const char *fixErrText(FixErr e, int probeState) {
  static char buf[64];
  Probe p = st.p[CH_COLUMN];
  if (probeState >= 0) p.state = (ProbeState)probeState;
  switch (e) {
    case FIX_OK:             return "";
    case FIX_ERR_RUN:        return "Тфикс есть только во втором перегоне";
    case FIX_ERR_SENSOR:
      snprintf(buf, sizeof(buf), "Датчик царги: %s", p.state == PROBE_OK ? "неисправен" : probeStateText(p));
      return buf;
    case FIX_ERR_STALE:      return "Нет свежих данных";
    case FIX_ERR_NOFIX:      return "Тфикс не задана";
    case FIX_ERR_NOTPENDING: return "Тфикс не ждёт подтверждения";
  }
  return "";
}

const char *fixSrcText(uint8_t src) {
  switch (src) {
    case SRC_WEB:  return "из браузера";
    case SRC_STAB: return "после стабилизации";
    case SRC_BOOT: return "при загрузке";
    default:       return "с экрана";
  }
}

String evTimeText(uint32_t at, uint8_t clock, bool date) {
  if (clock == 1) {
    time_t t = at; struct tm tm; localtime_r(&t, &tm);
    char b[24];
    strftime(b, sizeof(b), date ? "%d.%m %H:%M:%S" : "%H:%M", &tm);
    return String(b);
  }
  if (clock == 0) return "+" + fmtHMS(at);
  return String("—");
}

String fixTimeText() { return evTimeText(st.fixTime, st.fixClock, false); }

// отказ виден в журнале и в Serial (строкой журнала) вместе с причиной
static void refused(FixErr err, uint8_t src) { logEvent(EV_REFUSE, src, err, st.fix, NAN); }

FixErr cmdFix(FixSrc src) {
  st.now = nowSec();
  FixErr err = fixCheck();
  if (err) { refused(err, src); return err; }
  float old = st.fix;
  bool wasStab = st.mode == MODE_STAB;
  st.fix = r2(st.p[CH_COLUMN].t);
  pushFix(st.fix);
  st.mode = MODE_DRAW;                       // фиксация во время «Хвостов» и стабилизации — тоже в «Отбор»
  st.redSince = 0;
  st.stabStart = st.stableFor = 0;           // стабилизация прерывается
  st.newUntil = wasStab ? st.now + 180 : 0;  // после стабилизации — «Новая Тфикс, открывайте отбор» 3 мин
  st.fixConfirm = false;
  st.ask = false;
  stamp(st.fixTime, st.fixClock);
  st.fixSrc = src;
  storeRun();
  logEvent(EV_FIX, src, FIX_OK, old, st.fix);
  returnLogged = true;                       // старой Тфикс больше нет, возврат к ней не ждём
  st.steamFired = true;                      // Тфикс есть — разгон позади, сигнал «пар» уже не нужен
  st.steamMsg = false;
  // фиксация = оператор открывает отбор тела: отметка на плитке УО (если ещё не стоит)
  if (st.uo != UO_BODY) uoSet(UO_BODY, "тело: отбор открыт после фиксации Тфикс");
  buzzerShort();
  char msg[48];
  snprintf(msg, sizeof(msg), "Тфикс зафиксирована: %s", fmtNum(st.fix, 2).c_str());
  uiToast(msg, false);
  uiMarkDirty();
  return FIX_OK;
}

void cmdRemember() { cmdFix(SRC_SCREEN); }

FixErr cmdFixConfirm(FixSrc src) {
  st.now = nowSec();
  FixErr err = st.run != RUN_2 ? FIX_ERR_RUN : isnan(st.fix) ? FIX_ERR_NOFIX : !st.fixConfirm ? FIX_ERR_NOTPENDING : fixCheck();
  if (err) { refused(err, src); return err; }
  st.fixConfirm = false;
  st.redSince = 0;
  st.steamFired = true; st.steamMsg = false;   // Тфикс оставлена: разгон позади, сигнала пара не будет
  storeRun();
  logEvent(EV_CONFIRM, src, FIX_OK, st.fix, st.fix);
  buzzerShort();
  char msg[48];
  snprintf(msg, sizeof(msg), "Тфикс подтверждена: %s", fmtNum(st.fix, 2).c_str());
  uiToast(msg, false);
  uiMarkDirty();
  return FIX_OK;
}

FixErr cmdFixClear(FixSrc src) {
  st.now = nowSec();
  FixErr err = st.run != RUN_2 ? FIX_ERR_RUN : isnan(st.fix) ? FIX_ERR_NOFIX : FIX_OK;
  if (err) { refused(err, src); return err; }
  float old = st.fix;
  st.fix = NAN;
  pushFix(NAN);                              // на графике пунктир Тфикс обрывается здесь
  st.fixConfirm = false;
  st.ask = false;
  st.mode = MODE_DRAW;                       // сброс во время «Хвостов» или стабилизации снимает и их
  st.redSince = 0;
  st.stabStart = st.stableFor = 0;
  st.newUntil = 0;
  st.fixTime = 0; st.fixClock = 0; st.fixSrc = src;
  returnLogged = true;
  storeRun();
  logEvent(EV_CLEAR, src, FIX_OK, old, NAN);
  uiToast("Тфикс сброшена", false);
  uiMarkDirty();
  return FIX_OK;
}

void cmdResetAlarm(uint8_t src) {
  bool faultSound = alarmFaultSound();
  st.faultAck = st.faultMask;                // гасим звук неисправности
  if (st.run == RUN_2 && st.mode == MODE_TAILS) {
    st.mode = MODE_STAB;                     // отбор закрыт, ждём стабилизации
    st.stabStart = st.now;
    st.stableFor = 0;
    st.ask = false;
    Serial.println(F("[run] тревога сброшена, стабилизация"));
    historyEventf("сброс тревоги (%s), стабилизация", evSrcText(src));
  } else if (faultSound) {
    historyEventf("сброс тревоги неисправности датчика (%s)", evSrcText(src));
  }
  uiMarkDirty();
}

void cmdConfirmCool(uint8_t src) {
  if (st.cool != COOL_ALERT) return;
  st.cool = COOL_DONE;
  storeRun();
  historyEventf("охлаждение включено (%s), через %s", evSrcText(src), durText(nowSec() - coolAt).c_str());
  uiMarkDirty();
}

void cmdResetTimer() {
  if (st.run == RUN_NONE) return;
  historyEvent("таймер перегона обнулён");   // в строку старой минуты: дальше минуты снова с 0
  st.runStart = st.now;
  storeRun();
  uiMarkDirty();
}

String fixDiffText() {
  if (st.run != RUN_2 || isnan(st.fix) || fixCheck()) return String();
  float cur = r2(st.p[CH_COLUMN].t);
  return "было " + fmtNum(st.fix, 2) + ", сейчас " + fmtNum(cur, 2) + " (" + fmtSigned(r2(cur - st.fix), 2) + ")";
}

// ---------------------------------------------------------------------
//  Отметки отбора на плитке УО. Случайное касание сразу переключает этап,
//  поэтому короткий сигнал и строка на 2 с; повторное нажатие возвращает назад.
// ---------------------------------------------------------------------
void cmdUoTap(uint8_t src) {
  if (st.run != RUN_2) return;
  st.now = nowSec();
  char b[96];
  const char *who = evSrcText(src);
  switch (st.uo) {
    case UO_HEADS:
      snprintf(b, sizeof(b), "тело: отбор открыт (%s)", who);
      uoSet(UO_BODY, b);
      uiToast("Тело: отбор открыт", false);
      break;
    case UO_CLOSED:
      snprintf(b, sizeof(b), "тело: отбор открыт вручную (%s)", who);
      uoSet(UO_BODY, b);
      uiToast("Тело: отбор открыт вручную", false);
      break;
    default:                                   // нет отметки или «тело» → «головы»
      snprintf(b, sizeof(b), "головы (%s)", who);
      uoSet(UO_HEADS, b);
      uiToast("Головы", false);
      break;
  }
  buzzerShort();
}

String uoLabel() {
  switch (st.uo) {
    case UO_HEADS:  return "ГОЛОВЫ";
    case UO_BODY:   return "ТЕЛО";
    case UO_CLOSED: {
      uint32_t s = st.now - st.uoAt;
      return "ЗАКРЫТ " + (s < 3600 ? fmtMS(s) : fmtHMS(s));
    }
    default:        return String();
  }
}

// ---------------------------------------------------------------------
//  Сигнал «пар в узле отбора»
// ---------------------------------------------------------------------
bool steamAlert() { return st.run == RUN_2 && st.steamMsg && st.cool != COOL_ALERT; }

void cmdSteamAck(uint8_t src) {
  (void)src;
  if (!st.steamMsg) return;
  st.steamMsg = false;
  uiMarkDirty();
}

// ---------------------------------------------------------------------
//  Раз в секунду
// ---------------------------------------------------------------------
static void tickCooling() {
  float cube = st.p[CH_CUBE].t;
  if (isnan(cube)) return;
  float z0 = cubeGreenFrom();
  if (st.cool == COOL_IDLE && cube >= z0) {
    st.cool = COOL_ALERT;                    // зуммер: 3 коротких каждые 5 с
    coolAt = st.now;
    uiCloseMenu();
    Serial.printf("[run] куб %.1f: включите охлаждение\n", cube);
    historyEventf("куб %s: включите охлаждение, разгон %lu мин", fmtNum(cube, 1).c_str(), (unsigned long)((st.now - st.runStart) / 60));
  } else if (st.cool != COOL_IDLE && cube < z0 - 5.0f) {
    st.cool = COOL_IDLE;                     // куб остыл на 5 °C — сигнал снова взведён
  }
}

// Размах царги за окно и сколько секунд она держится в коридоре 0,05
static void tickColumnStats() {
  uint16_t win = cfg.stabWindow;
  uint16_t n = recentCount();
  float mn = 1e9f, mx = -1e9f;
  uint16_t cnt = 0;
  uint32_t sinceRun = st.now - st.runStart;      // не захватываем то, что было до перегона
  for (uint16_t b = 0; b < n && b < win && b <= sinceRun; b++) {
    float v = recentAt(b).c;
    if (isnan(v)) break;
    mn = min(mn, v); mx = max(mx, v); cnt++;
  }
  st.spread = cnt ? mx - mn : 0;
  st.spreadReady = cnt >= win && (st.now - st.runStart) >= win;

  if (st.mode != MODE_STAB) return;
  // сколько секунд назад от «сейчас» температура не выходила за коридор
  mn = 1e9f; mx = -1e9f;
  uint32_t stable = 0;
  uint32_t since = st.now - st.stabStart;
  for (uint16_t b = 0; b < n && b <= since; b++) {
    float v = recentAt(b).c;
    if (isnan(v)) break;
    mn = min(mn, v); mx = max(mx, v);
    if (mx - mn > CORRIDOR + 1e-4f) break;
    stable = b;
  }
  st.stableFor = stable;
}

static void tickColumn() {
  if (!columnValid()) { st.redSince = 0; return; }   // нет достоверных данных — тревогу не считаем

  // «Хвосты» считаются только от действующей Тфикс (не из памяти до подтверждения)
  if (st.mode == MODE_DRAW && !isnan(st.fix) && !st.fixConfirm) {
    float col = st.p[CH_COLUMN].t;
    if (col - st.fix > cfg.red + 1e-4f) {
      if (!st.redSince) st.redSince = st.now;
      if (st.now - st.redSince >= cfg.alarmDelay) {
        st.mode = MODE_TAILS;                    // тревога «Хвосты», зуммер
        uiCloseMenu();
        Serial.printf("[run] ХВОСТЫ: царга %.2f, Тфикс %.2f\n", col, st.fix);
        historyEventf("Хвосты: царга %s при Тфикс %s (%s)", fmtNum(r2(col), 2).c_str(), fmtNum(st.fix, 2).c_str(),
                      fmtSigned(r2(col - st.fix), 2).c_str());
        tailsAt = st.now;
        returnLogged = false;                    // ждём, когда царга вернётся к этой Тфикс
        uoSet(UO_CLOSED, "отбор закрыт (Хвосты)"); // оператор закрывает отбор: плитка УО красная
      }
    } else {
      st.redSince = 0;
    }
  } else {
    st.redSince = 0;
  }

  if (st.mode != MODE_STAB) return;
  // Стабильно всё окно: Тфикс сама не ставится, просим оператора её зафиксировать
  // (2 коротких сигнала и окно на экране, напоминание раз в минуту)
  if (!st.ask && st.stableFor >= cfg.stabWindow) {
    st.ask = true;
    st.askBeepAt = st.now;
    buzzerTwoShort();
    uiCloseMenu();
    logEvent(EV_ASK, SRC_STAB, FIX_OK, st.fix, NAN);
    Serial.printf("[run] стабильно %u мин: зафиксируйте Тфикс (сейчас %.2f)\n", cfg.stabWindow / 60, st.p[CH_COLUMN].t);
  } else if (st.ask && st.stableFor < cfg.stabWindow) {
    st.ask = false;                              // вышла из коридора: запрос снят, считаем заново
    Serial.println(F("[run] царга вышла из коридора 0,05, стабилизация заново"));
    historyEvent("царга вышла из коридора 0,05, стабилизация заново");
  } else if (st.ask && st.now - st.askBeepAt >= 60) {
    st.askBeepAt = st.now;
    buzzerTwoShort();
  }
}

// Царга вышла в жёлтую зону (выше Тфикс + «зелёный до») — в лог. Не чаще раза
// в минуту: если царга мечется у границы, строка не забивается.
static void tickYellow() {
  static Tone last = TONE_GREY;
  Tone t = columnTone();
  if (t == TONE_WARN && last != TONE_WARN && fixState() == FS_ACTIVE && (yellowAt == UINT32_MAX || st.now - yellowAt >= 60)) {
    float col = r2(st.p[CH_COLUMN].t);
    historyEventf("царга выше нормы %s (%s), жёлтая зона", fmtNum(col, 2).c_str(), fmtSigned(r2(col - st.fix), 2).c_str());
    yellowAt = st.now;
  }
  last = t;
}

// Неисправность датчика и возврат в норму — в лог. По каждому каналу не чаще
// раза в минуту: мигающий контакт не забивает строку, в лог идёт итог.
static void tickProbeLog() {
  static const char *names[NCH] = {"датчик 1 (куб)", "датчик 2 (царга)", "датчик 3 (УО)"};
  for (uint8_t i = 0; i < NCH; i++) {
    uint8_t bit = 1 << i;
    if ((st.faultMask & bit) == (probeLogged & bit)) continue;
    if (probeLogAt[i] && st.now - probeLogAt[i] < 60) continue;
    const char *name = i == CH_THIRD && st.run == RUN_1 ? "датчик 3 (воздух)" : names[i];
    if (st.faultMask & bit) historyEventf("%s: %s", name, probeStateText(st.p[i]));
    else if (!cfg.ch[i].enabled) historyEventf("%s выключен в настройках", name);
    else historyEventf("%s снова в норме", name);
    probeLogged ^= bit;
    probeLogAt[i] = st.now;
  }
}

// Пар дошёл до узла отбора: на разгоне (Тфикс ещё не было) датчик 3 впервые
// выше порога. Раз за перегон; после перезагрузки, если там уже горячо, сигнала нет.
static void tickSteam() {
  if (!st.steamFired) {
    const Probe &u = st.p[CH_THIRD];
    if (cfg.ch[CH_THIRD].enabled && u.state == PROBE_OK && !isnan(u.t)) {
      bool hot = u.t > cfg.steamC;
      if (steamCheck) {
        steamCheck = false;
        if (hot) st.steamFired = true;         // пар был до перезагрузки — не повторяем
      } else if (hot && isnan(st.fix)) {
        st.steamFired = true;
        st.steamMsg = true;
        Serial.printf("[run] пар в узле отбора: датчик 3 %.1f\n", u.t);
        historyEventf("пар в узле отбора: датчик 3 %s, куб %s", fmtNum(u.t, 1).c_str(), cubeText().c_str());
      }
    }
  }
  // надпись и серия сигналов — когда не горит «Включите охлаждение» (оно важнее)
  if (st.steamMsg && !steamShown && st.cool != COOL_ALERT) {
    steamShown = true;
    buzzerSeries();
    uiCloseMenu();
  }
}

// После «Хвостов» царга впервые снова в зелёной зоне старой Тфикс (до +«зелёный до»):
// в лог, через сколько после тревоги. Раз за тревогу; новая Тфикс или сброс снимают ожидание.
static void tickReturn() {
  if (returnLogged || !columnValid() || isnan(st.fix) || st.fixConfirm) return;
  if (r2(st.p[CH_COLUMN].t - st.fix) > cfg.green + 1e-4f) return;
  returnLogged = true;
  historyEventf("царга вернулась к Тфикс %s через %s после Хвостов", fmtNum(st.fix, 2).c_str(), durText(st.now - tailsAt).c_str());
}

// Свежесть данных: задача датчиков выдаёт среднее раз в секунду; если его
// нет дольше FIX_STALE_MS или сам канал царги давно не давал годного чтения —
// данные устарели: Тфикс не фиксируется, «Хвосты» на паузе.
static void updateStale() {
  if (!lastDataMs) return;
  uint32_t since = millis() - lastDataMs;
  uint32_t age = st.p[CH_COLUMN].age;
  bool stale = since > FIX_STALE_MS || (st.p[CH_COLUMN].state == PROBE_OK && age + since > FIX_STALE_MS);
  if (stale != st.stale) {
    st.stale = stale;
    if (stale) st.redSince = 0;                 // часы задержки тревоги обнуляются
    Serial.println(stale ? F("[run] данные датчиков устарели: Тфикс на паузе") : F("[run] данные датчиков снова свежие"));
    uiMarkDirty();
  }
}

void logicLoop() { updateStale(); }

void logicTick(const Probe p[NCH]) {
  st.now = nowSec();
  memcpy(st.p, p, sizeof(st.p));
  lastDataMs = millis();
  updateStale();

  // неисправности: бит на канал; если датчик починился — сбрасываем и «квитанцию»
  uint8_t mask = 0;
  for (uint8_t i = 0; i < NCH; i++) {
    if (cfg.ch[i].enabled && (p[i].state == PROBE_FAULT || p[i].state == PROBE_NOCHIP || p[i].state == PROBE_RANGE)) mask |= 1 << i;
  }
  st.faultAck &= mask;
  if (mask & ~st.faultMask) Serial.printf("[run] неисправен датчик, маска %02x\n", mask);
  st.faultMask = mask;

  if (st.run == RUN_NONE) return;

  tickProbeLog();
  tickCooling();
  if (st.run == RUN_2) {
    tickColumnStats();
    tickColumn();
    tickYellow();
    tickReturn();
    tickSteam();
  }

  if (st.now - lastStore >= 60) storeRun();   // таймер во flash раз в минуту
  uiMarkDirty();
}
