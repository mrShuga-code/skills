// net.cpp — Wi-Fi, время, обновление прошивки по сети.
//
//  Порядок подключения (как в документе):
//    основная сеть 10 с -> запасная 10 с -> своя точка «Kolonna-setup».
//  Пока работает своя точка, раз в минуту снова пробуем домашние сети
//  (если к точке никто не подключён). Измерения и экран от сети не зависят.
//
//  Имена сетей и пароли при первом запуске берутся из secrets.h,
//  дальше меняются в вебе (Настройки -> Wi-Fi) и хранятся в NVS.
//
//  Время: NTP из интернета, а без интернета — из браузера при открытии
//  страницы (часов с батарейкой в схеме нет).
#include "app.h"
#include <WiFi.h>
#include <ESPmDNS.h>
#include <ArduinoOTA.h>
#include <time.h>
#include <sys/time.h>

enum Phase : uint8_t { PH_TRY, PH_ONLINE, PH_AP };
static Phase phase = PH_TRY;
static uint8_t tryIdx = 0;
static uint32_t tryStart = 0, apSince = 0;
static bool apOn = false, otaStarted = false;

static void startAP() {
  if (apOn) return;
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(AP_SSID, AP_PASS);
  apOn = true;
  Serial.printf("[net] своя точка доступа «%s», адрес http://%s\n", AP_SSID, WiFi.softAPIP().toString().c_str());
}

static void stopAP() {
  if (!apOn) return;
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  apOn = false;
  Serial.println(F("[net] точка доступа выключена"));
}

// пробуем сеть номер i (0 — основная, 1 — запасная); пустые пропускаем
static bool startTry(uint8_t i) {
  for (; i < 2; i++) {
    if (cfg.ssid[i][0]) {
      tryIdx = i;
      tryStart = millis();
      WiFi.disconnect(false, false);
      WiFi.begin(cfg.ssid[i], cfg.pass[i]);
      phase = PH_TRY;
      Serial.printf("[net] подключаюсь к «%s» (%s)\n", cfg.ssid[i], i ? "запасная" : "основная");
      return true;
    }
  }
  return false;
}

static void startOta() {
  if (otaStarted) return;
  // Прошивка по сети из Arduino IDE: Tools -> Port -> «kolonna at ...»,
  // пароль — пароль веб-настроек. Второй способ — файл .bin в вебе.
  ArduinoOTA.setHostname(NET_HOSTNAME);
  ArduinoOTA.setPassword(cfg.webPass);
  ArduinoOTA.onStart([] { Serial.println(F("[ota] прошивка по сети…")); });
  ArduinoOTA.onError([](ota_error_t e) { Serial.printf("[ota] ошибка %u\n", e); });
  ArduinoOTA.begin();                       // заодно запускает mDNS: http://kolonna.local
  MDNS.addService("http", "tcp", 80);
  otaStarted = true;
}

void netBegin() {
  WiFi.persistent(false);                   // пароли храним сами, в NVS настроек
  WiFi.mode(WIFI_STA);
  WiFi.setHostname(NET_HOSTNAME);
  WiFi.setAutoReconnect(false);             // переподключением управляем сами
  configTzTime(TZ_INFO, NTP_SERVER1, NTP_SERVER2);
  if (!startTry(0)) {
    Serial.println(F("[net] сети не заданы"));
    startAP();
    phase = PH_AP;
    apSince = millis();
  }
}

void netReconnect() {
  Serial.println(F("[net] новые настройки Wi-Fi, переподключаюсь"));
  if (!startTry(0)) { startAP(); phase = PH_AP; apSince = millis(); }
}

void netLoop() {
  uint32_t t = millis();
  bool connected = WiFi.status() == WL_CONNECTED;
  switch (phase) {
    case PH_TRY:
      if (connected) {
        phase = PH_ONLINE;
        Serial.printf("[net] в сети «%s», адрес http://%s  или  http://%s.local\n",
                      WiFi.SSID().c_str(), WiFi.localIP().toString().c_str(), NET_HOSTNAME);
        if (apOn && WiFi.softAPgetStationNum() == 0) stopAP();
        startOta();
        uiMarkDirty();
      } else if (t - tryStart > WIFI_TRY_MS) {
        if (!startTry(tryIdx + 1)) {        // обе сети не ответили
          WiFi.disconnect(false, false);
          startAP();
          phase = PH_AP;
          apSince = t;
          startOta();
          uiMarkDirty();
        }
      }
      break;
    case PH_ONLINE:
      if (!connected) {
        Serial.println(F("[net] связь потеряна"));
        startTry(0);
        uiMarkDirty();
      } else if (apOn && WiFi.softAPgetStationNum() == 0) {
        stopAP();
      }
      break;
    case PH_AP:
      // раз в минуту пробуем домашние сети, если к точке никто не подключён
      if (t - apSince > WIFI_RETRY_MS && WiFi.softAPgetStationNum() == 0) {
        apSince = t;
        if (!startTry(0)) phase = PH_AP;
      }
      break;
  }
  if (otaStarted) ArduinoOTA.handle();
}

NetState netState() {
  if (phase == PH_ONLINE) return NET_ONLINE;
  if (apOn) return NET_AP;
  return NET_CONNECTING;
}

String netAddress() {
  if (phase == PH_ONLINE) return WiFi.localIP().toString();
  if (apOn) return WiFi.softAPIP().toString();
  return String();
}

String netSsid() {
  if (phase == PH_ONLINE) return WiFi.SSID();
  if (apOn) return String(AP_SSID);
  return String();
}

bool timeValid() { return time(nullptr) > 1700000000; }

void timeFromBrowser(uint32_t epoch) {
  if (timeValid() || epoch < 1700000000) return;
  struct timeval tv = {(time_t)epoch, 0};
  settimeofday(&tv, nullptr);
  Serial.println(F("[net] время взято из браузера"));
  uiMarkDirty();
}
