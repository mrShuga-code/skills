// relay.cpp — реле электроклапана отбора.
//
//  GPIO18 -> 220 Ом -> затвор полевого транзистора P3055LD (10 кОм с затвора
//  на GND держат его закрытым при загрузке), в стоке катушка реле 5 В
//  с диодом 1N4007. Контакты реле выведены на клеммник к клапану.
//
//  Клапан нормально закрытый: реле включено = клапан открыт.
//  Во втором перегоне реле переключает автоматика отбора (logic.cpp, режим
//  в окне плитки УО): только когда меняется то, что она хочет, поэтому кнопка
//  «Реле клапана» в вебе (/api/cmd?c=relayon|relayoff) по-прежнему работает
//  вручную до следующего решения автоматики. Состояние не запоминается: после
//  включения питания и перезагрузки реле всегда выключено. Ручное переключение
//  пишется в лог перегона, автоматика пишет свои события сама (с причиной).
//
//  ЕСЛИ РЕЛЕ РАБОТАЕТ НАОБОРОТ — поменяйте RELAY_ON_LEVEL в config.h на LOW.
#include "app.h"

static bool relayState = false;

static inline void pin(bool on) { digitalWrite(PIN_RELAY, on ? RELAY_ON_LEVEL : !RELAY_ON_LEVEL); }

void relayBegin() {
  pin(false);                 // сначала уровень, потом выход: без щелчка при старте
  pinMode(PIN_RELAY, OUTPUT);
  pin(false);
  relayState = false;
}

bool relayOn() { return relayState; }

void relaySet(bool on, uint8_t src) {
  if (on == relayState) return;
  relayState = on;
  pin(on);
  if (src == SRC_AUTO) return;
  historyEventf("реле клапана %s (%s)", on ? "включено" : "выключено", src == SRC_WEB ? "веб" : "экран");
}
