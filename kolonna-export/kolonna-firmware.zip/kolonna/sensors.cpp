// =====================================================================
//  sensors.cpp — три MAX31865 на шине SPI3.
//
//  Свой маленький драйвер вместо библиотеки Adafruit: библиотека делает
//  «одиночное» измерение с задержкой 75 мс и выключает ток датчика,
//  а по документу нужен непрерывный режим с фильтром 50 Гц.
//
//  Цикл одного канала (как в документе, раздел «Датчики и опрос»):
//    - MAX31865 меряет непрерывно, фильтр 50 Гц, 3 провода;
//    - каждые 200 мс читаем сопротивление и признак неисправности;
//    - пересчёт в °C по Каллендару–Ван Дюзену + поправка калибровки;
//    - одиночные скачки больше 2 °C отбрасываем как помеху;
//    - раз в секунду отдаём среднее за 5 с (25 чтений).
//
//  ЕСЛИ ДАТЧИК ПОКАЗЫВАЕТ ЕРУНДУ — что проверить (текст виден на экране и в вебе):
//    «нет модуля»    -> провода CLK/SDI/SDO/CS/питание модуля; CS не перепутаны?
//                       В мониторе порта при старте видно, какой CS не ответил.
//    «обрыв или КЗ»  -> провода датчика к клеммам F+/RTD+/RTD-, перемычки 2/3 Wire.
//                       Так же выглядит PT1000 на модуле с Rref 430 Ом: его
//                       сопротивление больше Rref и АЦП упирается в максимум.
//    «проверьте тип и Rref» -> модуль меряет, но выходит меньше -50 или больше
//                       250 °C: тип PT100/PT1000 и Rref в настройках не совпадают.
//                       Считается только ОТНОШЕНИЕ R0/Rref: PT100 + 430 Ом и
//                       PT1000 + 4300 Ом дают одно и то же, а PT1000 + 430 Ом — нет.
//                       В вебе (Настройки -> Датчики) видно сопротивление в Омах:
//                       ~108 Ом при 20 °C — это PT100, ~1080 Ом — PT1000.
//    скачет на 1–2 °C -> для 3 проводов запаяны «2/3 Wire» и «3», дорожка у «24» разрезана?
//    стабильно врёт на 0,3–1 °C -> калибровка по тающему льду: веб, Настройки ->
//                       Датчики -> «Калибровать по льду» (10 с, пересчитывает Rref)
// =====================================================================
#include "app.h"
#include <SPI.h>

static SPIClass sensSPI(HSPI);   // на ESP32-S3 HSPI = шина SPI3 (SPI2 занят экраном)
static const SPISettings spiSet(SENSOR_SPI_FREQ, MSBFIRST, SPI_MODE1);  // MAX31865: режим 1 или 3
static const uint8_t csPin[NCH] = {PIN_CS_CUBE, PIN_CS_COLUMN, PIN_CS_THIRD};

// регистры MAX31865
static const uint8_t REG_CONFIG = 0x00, REG_RTD_MSB = 0x01, REG_HFAULT_MSB = 0x03, REG_FAULT = 0x07;
static const uint8_t CFG_BIAS = 0x80, CFG_AUTO = 0x40, CFG_3WIRE = 0x10, CFG_FAULT_CLR = 0x02, CFG_50HZ = 0x01;

static const uint8_t RING = SENSOR_AVG_SEC * 1000 / SENSOR_PERIOD_MS;   // 25 чтений

struct Chan {
  float    ring[RING];
  uint8_t  head, count;
  float    last;          // последнее принятое значение
  uint8_t  spikes;        // сколько скачков подряд отброшено
  uint8_t  bad;           // сколько неисправных чтений подряд
  bool     chipOk;
  bool     range;         // последнее плохое чтение: температура вне диапазона
  uint8_t  fault;
  float    ohm;
  uint32_t okAt;          // millis() последнего принятого чтения (для проверки свежести Тфикс)
};
static Chan ch[NCH];

static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static Probe shared[NCH];
static uint32_t sharedSeq = 0;
static volatile bool needInit = true;

// Калибровка по льду: пока active, копятся те же чтения, что идут в среднее
// на экран (без одиночных скачков-помех), и их разброс
struct Cal {
  bool     active, done;
  uint32_t startMs;
  double   sum;
  float    mn, mx;
  uint16_t n, bad, wild;
};
static Cal cal[NCH];
static const uint32_t CAL_MS = CAL_SECONDS * 1000UL;

// ---------------------------------------------------------------------
static void writeReg(uint8_t i, uint8_t reg, uint8_t val) {
  sensSPI.beginTransaction(spiSet);
  digitalWrite(csPin[i], LOW);
  sensSPI.transfer(reg | 0x80);
  sensSPI.transfer(val);
  digitalWrite(csPin[i], HIGH);
  sensSPI.endTransaction();
}

static void readRegs(uint8_t i, uint8_t reg, uint8_t *buf, uint8_t n) {
  sensSPI.beginTransaction(spiSet);
  digitalWrite(csPin[i], LOW);
  sensSPI.transfer(reg & 0x7F);
  for (uint8_t k = 0; k < n; k++) buf[k] = sensSPI.transfer(0xFF);
  digitalWrite(csPin[i], HIGH);
  sensSPI.endTransaction();
}

static uint8_t configByte(uint8_t i) {
  uint8_t c = CFG_BIAS | CFG_AUTO;                  // ток датчика включён, непрерывное измерение
  if (cfg.ch[i].wires == 3) c |= CFG_3WIRE;          // 3 провода; для 2 и 4 бит сброшен
  if (SENSOR_FILTER_50HZ) c |= CFG_50HZ;             // режекторный фильтр сети 50 Гц
  return c;
}

// Настройка одного модуля. Фильтр 50/60 Гц можно менять только при
// выключенном непрерывном режиме, поэтому сначала гасим AUTO.
static bool chipInit(uint8_t i) {
  uint8_t c = configByte(i);
  writeReg(i, REG_CONFIG, 0x00);
  delay(2);
  writeReg(i, REG_CONFIG, c & ~CFG_AUTO);
  delay(10);
  writeReg(i, REG_CONFIG, c | CFG_FAULT_CLR);
  // пороги неисправности на весь диапазон: срабатывать только на обрыв/КЗ
  writeReg(i, REG_HFAULT_MSB + 0, 0xFF);
  writeReg(i, REG_HFAULT_MSB + 1, 0xFF);
  writeReg(i, REG_HFAULT_MSB + 2, 0x00);
  writeReg(i, REG_HFAULT_MSB + 3, 0x00);
  uint8_t rb = 0;
  readRegs(i, REG_CONFIG, &rb, 1);
  // если модуля нет, по линии SDO читается 0x00 или 0xFF и конфиг не совпадает
  return (rb & ~CFG_FAULT_CLR) == (c & ~CFG_FAULT_CLR);
}

// rtdToC() — пересчёт сопротивления в °C — лежит в util.cpp (нужен и калибровке)

// kind: 1 — годное чтение (ohm), 0 — обрыв или КЗ, -1 — меряет, но вне −50…250 °C
static void calAdd(uint8_t i, int8_t kind, float ohm) {
  portENTER_CRITICAL(&mux);
  Cal &k = cal[i];
  if (k.active) {
    if (kind > 0) {
      if (!k.n || ohm < k.mn) k.mn = ohm;
      if (!k.n || ohm > k.mx) k.mx = ohm;
      k.sum += ohm;
      k.n++;
    } else if (kind == 0) k.bad++;
    else k.wild++;
  }
  portEXIT_CRITICAL(&mux);
}

static void resetChan(uint8_t i) {
  ch[i].head = ch[i].count = 0;
  ch[i].last = NAN;
  ch[i].spikes = ch[i].bad = 0;
  ch[i].range = false;
  ch[i].okAt = 0;
}

// Одно чтение канала: каждые 200 мс
static void readOne(uint8_t i) {
  Chan &c = ch[i];
  uint8_t b[2];
  readRegs(i, REG_RTD_MSB, b, 2);
  uint16_t raw = (uint16_t(b[0]) << 8) | b[1];
  bool faultBit = raw & 1;
  uint16_t code = raw >> 1;
  float r0 = cfg.ch[i].pt1000 ? 1000.0f : 100.0f;
  c.ohm = code * cfg.ch[i].rref / 32768.0f;
  float t = rtdToC(c.ohm, r0) + cfg.ch[i].offset;

  // код 0 — КЗ, 0x7FFF — обрыв (сопротивление больше Rref); бит 0 — флаг неисправности
  bool wired = !faultBit && code != 0 && code != 0x7FFF;
  bool valid = wired && t > SENSOR_MIN_C && t < SENSOR_MAX_C;
  if (!wired) calAdd(i, 0, 0);
  else if (!valid) calAdd(i, -1, 0);
  if (faultBit) {
    readRegs(i, REG_FAULT, &c.fault, 1);
    writeReg(i, REG_CONFIG, configByte(i) | CFG_FAULT_CLR);   // сбросить флаг и мерить дальше
  }
  if (!valid) {
    c.range = wired;                                       // меряет, но не то: тип/Rref
    if (c.bad < 255) c.bad++;
    if (c.bad >= 3) { c.count = 0; c.last = NAN; }        // 3 плохих чтения подряд — неисправность
    return;
  }
  c.bad = 0;
  c.fault = 0;
  // фильтр одиночных скачков: больше 2 °C от прошлого — помеха,
  // но если скачок держится 3 чтения подряд — значит температура правда изменилась
  if (!isnan(c.last) && fabsf(t - c.last) > SENSOR_SPIKE_C && c.spikes < 2) {
    c.spikes++;
    return;
  }
  if (c.spikes >= 2) c.count = 0;   // настоящий скачок: старое среднее выбрасываем
  c.spikes = 0;
  c.last = t;
  c.okAt = millis();
  calAdd(i, 1, c.ohm);                                     // калибровка: это чтение годное
  c.ring[c.head] = t;
  c.head = (c.head + 1) % RING;
  if (c.count < RING) c.count++;
}

static void publish() {
  Probe out[NCH];
  for (uint8_t i = 0; i < NCH; i++) {
    Chan &c = ch[i];
    out[i].ohm = c.ohm;
    out[i].fault = c.fault;
    out[i].t = NAN;
    out[i].age = c.okAt ? millis() - c.okAt : UINT32_MAX / 2;
    if (!cfg.ch[i].enabled) { out[i].state = PROBE_OFF; continue; }
    if (!c.chipOk)          { out[i].state = PROBE_NOCHIP; continue; }
    if (c.bad >= 3)         { out[i].state = c.range ? PROBE_RANGE : PROBE_FAULT; continue; }
    if (c.count < 3)        { out[i].state = PROBE_WAIT; continue; }
    float s = 0;
    for (uint8_t k = 0; k < c.count; k++) s += c.ring[k];
    out[i].t = s / c.count;
    out[i].state = PROBE_OK;
  }
  portENTER_CRITICAL(&mux);
  memcpy(shared, out, sizeof(out));
  sharedSeq++;
  portEXIT_CRITICAL(&mux);
}

static void sensorTask(void *) {
  TickType_t lastWake = xTaskGetTickCount();
  uint8_t tick = 0;
  uint16_t checkTick = 0;
  for (;;) {
    if (needInit) {
      needInit = false;
      for (uint8_t i = 0; i < NCH; i++) {
        resetChan(i);
        portENTER_CRITICAL(&mux);
        cal[i] = Cal();                    // настройки поменялись — калибровку начинать заново
        portEXIT_CRITICAL(&mux);
        ch[i].chipOk = cfg.ch[i].enabled ? chipInit(i) : false;
        Serial.printf("[sens] датчик %u (CS %u): %s\n", i + 1, csPin[i],
                      !cfg.ch[i].enabled ? "выключен" : ch[i].chipOk ? "модуль найден" : "МОДУЛЬ НЕ ОТВЕЧАЕТ");
      }
      delay(80);   // первое преобразование после включения
      lastWake = xTaskGetTickCount();
    }
    for (uint8_t i = 0; i < NCH; i++)
      if (cfg.ch[i].enabled && ch[i].chipOk) readOne(i);

    // калибровка: через CAL_SECONDS секунд — готово (даже если модуль пропал: тогда n = 0)
    portENTER_CRITICAL(&mux);
    for (uint8_t i = 0; i < NCH; i++)
      if (cal[i].active && millis() - cal[i].startMs >= CAL_MS) { cal[i].active = false; cal[i].done = true; }
    portEXIT_CRITICAL(&mux);

    // раз в 5 с проверяем, что модули на месте (провод отошёл, помеха сбросила конфиг)
    if (++checkTick >= 5000 / SENSOR_PERIOD_MS) {
      checkTick = 0;
      for (uint8_t i = 0; i < NCH; i++) {
        if (!cfg.ch[i].enabled) continue;
        uint8_t rb = 0;
        readRegs(i, REG_CONFIG, &rb, 1);
        bool ok = (rb & ~CFG_FAULT_CLR) == (configByte(i) & ~CFG_FAULT_CLR);
        if (!ok || !ch[i].chipOk) {
          // модуль сбросился или его не было — настраиваем заново
          bool was = ch[i].chipOk;
          resetChan(i);
          ch[i].chipOk = chipInit(i);
          if (ch[i].chipOk != was)
            Serial.printf("[sens] датчик %u: %s\n", i + 1, ch[i].chipOk ? "модуль снова на связи" : "модуль не отвечает");
        }
      }
    }
    if (++tick >= 1000 / SENSOR_PERIOD_MS) { tick = 0; publish(); }
    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(SENSOR_PERIOD_MS));
  }
}

void sensorsBegin() {
  for (uint8_t i = 0; i < NCH; i++) {      // все CS в 1 до первой передачи
    pinMode(csPin[i], OUTPUT);
    digitalWrite(csPin[i], HIGH);
    resetChan(i);
    shared[i].t = NAN;
    shared[i].state = PROBE_WAIT;
  }
  sensSPI.begin(PIN_SENS_CLK, PIN_SENS_SDO, PIN_SENS_SDI, -1);   // (SCK, MISO, MOSI, SS)
  // ядро 0: датчики не зависят от экрана и сети
  xTaskCreatePinnedToCore(sensorTask, "sensors", 4096, nullptr, 3, nullptr, 0);
}

void sensorsReconfigure() { needInit = true; }

uint32_t sensorsGet(Probe out[NCH]) {
  portENTER_CRITICAL(&mux);
  memcpy(out, shared, sizeof(shared));
  uint32_t s = sharedSeq;
  portEXIT_CRITICAL(&mux);
  return s;
}

// ---------------------------------------------------------------------
//  Калибровка по льду (кнопка в вебе)
// ---------------------------------------------------------------------
bool sensorsCalStart(uint8_t i) {
  if (i >= NCH || !cfg.ch[i].enabled || !ch[i].chipOk) return false;
  portENTER_CRITICAL(&mux);
  cal[i] = Cal();
  cal[i].active = true;
  cal[i].startMs = millis();
  portEXIT_CRITICAL(&mux);
  Serial.printf("[cal] датчик %u: калибровка по льду, %u с\n", i + 1, (unsigned)CAL_SECONDS);
  return true;
}

CalInfo sensorsCalInfo(uint8_t i) {
  CalInfo r = {CAL_IDLE, 0, NAN, NAN, NAN, 0, 0, 0};
  if (i >= NCH) return r;
  portENTER_CRITICAL(&mux);
  Cal c = cal[i];
  portEXIT_CRITICAL(&mux);
  r.n = c.n; r.bad = c.bad; r.wild = c.wild;
  if (c.n) { r.ohmMin = c.mn; r.ohmMax = c.mx; }
  if (c.active) {
    uint32_t el = millis() - c.startMs;
    r.state = CAL_RUN;
    r.leftMs = el < CAL_MS ? CAL_MS - el : 0;
  } else if (c.done) {
    r.state = CAL_DONE;
    r.ohm = c.n ? (float)(c.sum / c.n) : NAN;
  }
  return r;
}

void sensorsCalClear(uint8_t i) {
  if (i >= NCH) return;
  portENTER_CRITICAL(&mux);
  cal[i] = Cal();
  portEXIT_CRITICAL(&mux);
}

const char *probeStateText(const Probe &p) {
  switch (p.state) {
    case PROBE_OK:     return "норма";
    case PROBE_OFF:    return "выключен";
    case PROBE_NOCHIP: return "нет модуля";
    case PROBE_FAULT:  return "обрыв или КЗ";
    case PROBE_RANGE:  return "проверьте тип и Rref";
    default:           return "запуск";
  }
}
