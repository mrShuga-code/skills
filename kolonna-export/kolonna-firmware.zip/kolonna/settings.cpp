// settings.cpp — настройки в NVS (энергонезависимая память ESP32).
// Все настройки хранятся одним блоком. Новые поля добавляются только в конец
// структуры Settings: блок прошлой прошивки короче, он читается как есть, а
// новые поля берут заводские значения. Если структуру пришлось бы менять
// иначе, SETTINGS_VERSION увеличивается и настройки сбрасываются к заводским
// (Wi-Fi снова берётся из secrets.h).
#include "app.h"
#include <Preferences.h>
#include "secrets.h"

#ifndef WEB_ADMIN_PASS
#define WEB_ADMIN_PASS "123"
#endif

static const uint16_t SETTINGS_VERSION = 1;
// Размер блока прошивки до 14.10.2026 (без steamC): такой блок тоже загружается
static const size_t SETTINGS_SIZE_V1 = offsetof(Settings, steamC);
static_assert(SETTINGS_SIZE_V1 == 332, "старый блок настроек был 332 байта: поля перед steamC менять нельзя");
static Preferences prefs;
Settings cfg;
static uint32_t calAt[NCH];        // даты калибровки по льду, ключ NVS «calat» (не в блоке Settings)

static bool     dirty = false;
static uint32_t dirtyAt = 0;

static void copyStr(char *dst, const char *src, size_t n) {
  strncpy(dst, src ? src : "", n - 1);
  dst[n - 1] = 0;
}

void settingsDefaults(Settings &s) {
  memset(&s, 0, sizeof(s));
  for (uint8_t i = 0; i < NCH; i++) {
    s.ch[i].enabled = true;
    s.ch[i].pt1000  = SENSOR_DEFAULT_PT1000;
    s.ch[i].rref    = SENSOR_DEFAULT_PT1000 ? SENSOR_RREF_PT1000 : SENSOR_RREF_PT100;
    s.ch[i].wires   = SENSOR_DEFAULT_WIRES;
    s.ch[i].offset  = 0.0f;
  }
  s.stabWindow = 300;
  s.green      = 0.05f;
  s.red        = 0.10f;
  s.alarmDelay = 3;
  s.buzzer     = true;
  const float z2[4] = {55.0f, 88.3f, 91.5f, 93.2f};
  const float z1[4] = {55.0f, 90.0f, 94.0f, 98.0f};
  memcpy(s.z2, z2, sizeof(z2));
  memcpy(s.z1, z1, sizeof(z1));
  s.col1     = 65.0f;
  s.chartMin = 10;
  s.bright   = 100;
  s.steamC   = 50.0f;
  // Wi-Fi и пароль берутся из secrets.h только как заводские значения
  copyStr(s.ssid[0], WIFI_MAIN_SSID, sizeof(s.ssid[0]));
  copyStr(s.pass[0], WIFI_MAIN_PASS, sizeof(s.pass[0]));
  copyStr(s.ssid[1], WIFI_BACKUP_SSID, sizeof(s.ssid[1]));
  copyStr(s.pass[1], WIFI_BACKUP_PASS, sizeof(s.pass[1]));
  copyStr(s.webPass, WEB_ADMIN_PASS, sizeof(s.webPass));
}

// защита от испорченных значений в памяти
static void sanitize(Settings &s) {
  for (uint8_t i = 0; i < NCH; i++) {
    if (!(s.ch[i].rref > 10 && s.ch[i].rref < 20000)) s.ch[i].rref = s.ch[i].pt1000 ? SENSOR_RREF_PT1000 : SENSOR_RREF_PT100;
    if (s.ch[i].wires != 2 && s.ch[i].wires != 3 && s.ch[i].wires != 4) s.ch[i].wires = 3;
    if (!(fabsf(s.ch[i].offset) <= 10)) s.ch[i].offset = 0;
  }
  s.stabWindow = constrain(s.stabWindow, 120, 900);
  if (!(s.green >= 0.02f && s.green < 1)) s.green = 0.05f;
  if (!(s.red > s.green && s.red <= 0.30f + 1e-4f)) s.red = max(0.10f, s.green + 0.01f);
  s.alarmDelay = constrain(s.alarmDelay, 1, 10);
  s.chartMin   = constrain(s.chartMin, 1, 30);
  s.bright     = constrain(s.bright, 10, 100);
  if (!(s.steamC >= 30 && s.steamC <= 90)) s.steamC = 50; else s.steamC = roundf(s.steamC);
  if (!(s.col1 >= 30 && s.col1 <= 95)) s.col1 = 65;
  for (uint8_t i = 0; i < 4; i++) {
    if (!(s.z1[i] > 0 && s.z1[i] < 120)) { float d[4] = {55, 90, 94, 98}; memcpy(s.z1, d, sizeof(d)); break; }
  }
  for (uint8_t i = 0; i < 4; i++) {
    if (!(s.z2[i] > 0 && s.z2[i] < 120)) { float d[4] = {55, 88.3f, 91.5f, 93.2f}; memcpy(s.z2, d, sizeof(d)); break; }
  }
  s.ssid[0][32] = s.ssid[1][32] = 0;
  s.pass[0][64] = s.pass[1][64] = 0;
  s.webPass[32] = 0;
}

// Переход на PT1000 (23.10.2026): один раз переводим датчики PT100 на PT1000 и
// 4300 Ом. Признак «сделано» — ключ NVS «pt1k», поэтому выбор PT100 в вебе
// после этого остаётся (запасной вариант) и при перезагрузке не сбивается.
static void migratePt1000() {
#if SENSOR_DEFAULT_PT1000
  if (prefs.getUChar("pt1k", 0)) return;
  uint8_t n = 0;
  for (uint8_t i = 0; i < NCH; i++) {
    if (cfg.ch[i].pt1000) continue;
    cfg.ch[i].pt1000 = true;
    cfg.ch[i].rref   = SENSOR_RREF_PT1000;
    cfg.ch[i].offset = 0.0f;
    calAt[i] = 0;
    n++;
  }
  if (n) {
    prefs.putBytes("calat", calAt, sizeof(calAt));
    settingsSaveNow();
    Serial.printf("[cfg] PT1000: %u датч. переведено с PT100 на PT1000, Rref 4300 Ом, калибровку сделайте заново\n", n);
  }
  prefs.putUChar("pt1k", 1);
#endif
}

void settingsLoad() {
  settingsDefaults(cfg);
  prefs.begin("kolonna", false);
  memset(calAt, 0, sizeof(calAt));
  if (prefs.getBytesLength("calat") == sizeof(calAt)) prefs.getBytes("calat", calAt, sizeof(calAt));
  size_t len = prefs.getBytesLength("cfg");
  if (prefs.getUShort("ver", 0) == SETTINGS_VERSION && (len == sizeof(Settings) || len == SETTINGS_SIZE_V1)) {
    // короткий блок прошлой прошивки: читаются его поля, остальные остаются заводскими
    prefs.getBytes("cfg", &cfg, sizeof(Settings));
    sanitize(cfg);
    Serial.println(len == sizeof(Settings) ? F("[cfg] настройки загружены из NVS") : F("[cfg] настройки прошлой прошивки загружены, новые поля — заводские"));
  } else {
    Serial.println(F("[cfg] первый запуск или новая версия: заводские настройки"));
    settingsSaveNow();
  }
  migratePt1000();
}

void settingsSaveNow() {
  sanitize(cfg);
  prefs.putUShort("ver", SETTINGS_VERSION);
  prefs.putBytes("cfg", &cfg, sizeof(Settings));
  dirty = false;
}

void settingsSave() {
  dirty = true;
  dirtyAt = millis();
}

void settingsTick() {
  if (dirty && millis() - dirtyAt > 2000) settingsSaveNow();
}

void settingsFactoryReset() {
  prefs.clear();
  memset(calAt, 0, sizeof(calAt));
  settingsDefaults(cfg);
  settingsSaveNow();
  migratePt1000();    // заводские уже PT1000: только ставит признак «переход сделан»
}

uint32_t calDate(uint8_t i) { return i < NCH ? calAt[i] : 0; }

void calDateSet(uint8_t i, uint32_t unixTime) {
  if (i >= NCH || calAt[i] == unixTime) return;
  calAt[i] = unixTime;
  prefs.putBytes("calat", calAt, sizeof(calAt));
}

// Калибровка тача: 8 чисел LovyanGFX + метка поворота. Если в config.h
// поменяли LCD_OFFSET_ROTATION или TOUCH_OFFSET_ROTATION, старая
// калибровка не подходит и не применяется.
static const uint16_t TCAL_TAG = 0xCA00 | (LCD_OFFSET_ROTATION << 4) | TOUCH_OFFSET_ROTATION;

bool touchCalLoad(uint16_t p[8]) {
  uint16_t buf[9];
  if (prefs.getBytesLength("tcal") != sizeof(buf) || prefs.getBytes("tcal", buf, sizeof(buf)) != sizeof(buf)) return false;
  if (buf[8] != TCAL_TAG) return false;
  memcpy(p, buf, 16);
  return true;
}

void touchCalSave(const uint16_t p[8]) {
  uint16_t buf[9];
  memcpy(buf, p, 16);
  buf[8] = TCAL_TAG;
  prefs.putBytes("tcal", buf, sizeof(buf));
}

// ---------------------------------------------------------------------
//  Запись перегона «run»: версия 2 с контрольной суммой.
//  Версия 1 (прошивка до 13.10.2026) была 16 байт без версии и CRC:
//  {uint8 run; uint32 elapsed; float fix; uint8 cool} — её тоже читаем,
//  чтобы после обновления прошивки не потерять идущий перегон.
// ---------------------------------------------------------------------
struct SavedRunV1 { uint8_t run; uint32_t elapsed; float fix; uint8_t cool; };

static uint32_t crc32(const uint8_t *p, size_t n) {
  uint32_t c = 0xFFFFFFFF;
  while (n--) {
    c ^= *p++;
    for (uint8_t k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320 & (0 - (c & 1)));
  }
  return ~c;
}
static uint32_t savedCrc(const SavedRun &r) { return crc32((const uint8_t *)&r, offsetof(SavedRun, crc)); }

// границы включены: r2() от 249,996 даёт ровно 250,00; ±inf вне диапазона
static bool fixSane(float v) { return !isnan(v) && v >= SENSOR_MIN_C && v <= SENSOR_MAX_C; }

SavedLoad savedRunLoad(SavedRun &r) {
  memset(&r, 0, sizeof(r));
  size_t len = prefs.getBytesLength("run");
  if (len == 0) return SAVED_NONE;
  if (len == sizeof(SavedRunV1)) {
    SavedRunV1 o;
    prefs.getBytes("run", &o, sizeof(o));
    if (o.run != RUN_1 && o.run != RUN_2) return SAVED_BAD;
    if (!isnan(o.fix) && !fixSane(o.fix)) return SAVED_BAD;
    r.ver = 1;
    r.run = o.run;
    r.cool = o.cool;
    r.elapsed = o.elapsed;
    r.hasFix = !isnan(o.fix);
    r.fix = r.hasFix ? o.fix : NAN;
    r.fixSrc = SRC_SCREEN;
    r.fixClock = 2;                       // когда зафиксирована — неизвестно
    Serial.println(F("[run] запись перегона старого формата (версия 1) прочитана"));
    return SAVED_OK;
  }
  if (len != sizeof(SavedRun)) return SAVED_BAD;
  prefs.getBytes("run", &r, sizeof(SavedRun));
  if (r.ver != SAVED_RUN_VERSION || r.crc != savedCrc(r)) return SAVED_BAD;
  if (r.run != RUN_1 && r.run != RUN_2) return SAVED_BAD;
  if (r.hasFix && !fixSane(r.fix)) return SAVED_BAD;
  if (!r.hasFix) r.fix = NAN;
  return SAVED_OK;
}

void savedRunStore(const SavedRun &in) {
  SavedRun r = in;
  r.ver = SAVED_RUN_VERSION;
  r.pad[0] = r.pad[1] = 0;
  r.crc = savedCrc(r);
  prefs.putBytes("run", &r, sizeof(SavedRun));
}
