// ui.cpp — экран 320×240 и тач.
//
//  Всё рисуется в спрайт (картинку в памяти PSRAM) и выводится на экран
//  целиком: так нет мерцания. Кнопки, которые нарисованы в кадре,
//  сразу записываются в список «зон нажатия» hits[] — тач проверяет
//  именно их, поэтому кнопка нажимается там, где она нарисована.
//
//  ЕСЛИ НАЖАТИЕ ПОПАДАЕТ НЕ В ТУ КНОПКУ — дело не в этом файле,
//  а в повороте тача: см. TOUCH_OFFSET_ROTATION и TOUCH_DEBUG в config.h
//  или сделайте калибровку (BOOT 3 с, см. ниже).
//
//  Кнопка BOOT на плате (когда экран уже работает):
//    держать 3 с и отпустить  — калибровка тача (4 угла)
//    держать 10 с и отпустить — сброс всех настроек к заводским
//  (ВНИМАНИЕ: не держите BOOT в момент включения питания — так ESP32
//   уходит в режим прошивки и программа не запускается.)
//
//  Раскладка экранов — как в макете контроллера.
#include "app.h"
#include "lgfx_config.h"
#include "fonts.h"
#include <time.h>
#include <string>

static LGFX lcd;
static LGFX_Sprite spr(&lcd);
static bool sprOk = false;

// ---------------------------------------------------------------------
//  Шрифты (сглаженные VLW с кириллицей, см. fonts.h)
// ---------------------------------------------------------------------
struct UFont { lgfx::VLWfont vlw; lgfx::PointerWrapper data; };
static UFont fXL, fL, fM, fV, fH, fT, fSB, fS;

static void fontLoad(UFont &f, const uint8_t *arr, size_t len) {
  f.data.set(arr, len);
  if (!f.vlw.loadFont(&f.data)) Serial.println(F("[ui] шрифт не загрузился"));
}

// ---------------------------------------------------------------------
//  Цвета (как в макете). Тип uint32_t = цвет 0xRRGGBB для LovyanGFX.
//  Если на экране все цвета «негативом» — это не здесь, см. LCD_INVERT,
//  если красный и синий поменялись местами — LCD_RGB_ORDER в config.h.
// ---------------------------------------------------------------------
typedef uint32_t rgb_t;
static const rgb_t C_BG = 0x0a0d10, C_TILE = 0x11161b, C_TILE_BR = 0x222a31;
static const rgb_t C_MUTED = 0x8b949c, C_DIM = 0x6f7a84, C_TXT = 0xc9d1d8, C_TXT2 = 0xdce3ea, C_WHITE = 0xeef1f4;
static const rgb_t C_BTN = 0x1b232b, C_BTN_BR = 0x2b3540, C_BTN_ON = 0x2b3540, C_BTN_DIM = 0x59636d;
static const rgb_t C_ALARM = 0xc62828, C_ALARM_BR = 0xff5a5a, C_ALARM_SUB = 0xffd0d0;
static const rgb_t C_COOL = 0x1d5fbf, C_COOL2 = 0x13407f, C_COOL_BR = 0x5ec8ff, C_COOL_SUB = 0xd6ecff;
static const rgb_t C_STEAM = 0x9a4f10, C_STEAM2 = 0x5e300a, C_STEAM_SUB = 0xffe3c4;   // «Пар в узле отбора»
static const rgb_t C_FLASH = 0x3a1010, C_TAILS_BG = 0x2a0d0d, C_ACCENT = 0x3ddc84, C_TAB_ON = 0x1f2a33;
static const rgb_t C_OK = 0x3ddc84, C_WARN = 0xffd23f, C_HOT = 0xff8c1a, C_BAD = 0xff4d4d;
static const rgb_t C_COLD = 0x5ec8ff, C_STAB = 0x5b7cff, C_GREY = 0x6f7a84;

static rgb_t toneColor(Tone t) {
  switch (t) {
    case TONE_COLD: return C_COLD;
    case TONE_OK:   return C_OK;
    case TONE_WARN: return C_WARN;
    case TONE_HOT:  return C_HOT;
    case TONE_BAD:  return C_BAD;
    case TONE_STAB: return C_STAB;
    case TONE_WHITE: return C_WHITE;
    default:        return C_GREY;
  }
}

// цвет a поверх b с прозрачностью k (0..1) — для цветных полос на графиках
static rgb_t blend(rgb_t a, rgb_t b, float k) {
  uint8_t r = ((a >> 16) & 255) * k + ((b >> 16) & 255) * (1 - k);
  uint8_t g = ((a >> 8) & 255) * k + ((b >> 8) & 255) * (1 - k);
  uint8_t bl = (a & 255) * k + (b & 255) * (1 - k);
  return ((rgb_t)r << 16) | ((rgb_t)g << 8) | bl;
}

// ---------------------------------------------------------------------
//  Текст
// ---------------------------------------------------------------------
using Datum = lgfx::textdatum_t;
static const Datum D_L = Datum::baseline_left, D_C = Datum::baseline_center, D_R = Datum::baseline_right;

static int txt(const char *s, int x, int y, UFont &f, rgb_t c, Datum d = D_L) {
  spr.setFont(&f.vlw);
  spr.setTextColor(c);          // один цвет = прозрачный фон, буквы сглаживаются по фону
  spr.setTextDatum(d);
  return spr.drawString(s, x, y);
}
static int txt(const String &s, int x, int y, UFont &f, rgb_t c, Datum d = D_L) { return txt(s.c_str(), x, y, f, c, d); }
static int textW(const char *s, UFont &f) { spr.setFont(&f.vlw); return spr.textWidth(s); }

// Обрезает строку до ширины maxW пикселей и ставит «…» (длинное имя сети Wi-Fi)
static String fitText(const String &s, UFont &f, int maxW) {
  if (textW(s.c_str(), f) <= maxW) return s;
  std::string t = s.c_str();
  while (!t.empty()) {
    do t.pop_back(); while (!t.empty() && (uint8_t(t.back()) & 0xC0) == 0x80);   // по целой букве UTF-8
    if (textW((t + "…").c_str(), f) <= maxW) break;
  }
  return String((t + "…").c_str());
}

// ---------------------------------------------------------------------
//  Зоны нажатия
// ---------------------------------------------------------------------
enum HitKind : uint8_t { TAP, HOLD, REPEAT, SLIDE };
enum : uint8_t {
  B_NONE = 0, B_SEL1, B_SEL2, B_BACK, B_FIX, B_RESET, B_MENU, B_COOL,
  B_TCOL, B_TCUBE, B_TAB0, B_TAB1, B_TAB2, B_MRUN, B_MDONE, B_CHART_CLOSE, B_TEST_NEXT,
  B_TUO, B_STEAM,                                        // плитка УО (отметка отбора), «Пар в узле отбора» — Понятно
  B_DLG_CANCEL, B_DLG_OK, B_DLG_A, B_DLG_B, B_DLG_X,     // кнопки окон Тфикс
  B_ROW = 32          // строки меню: B_ROW + строка*4 + (0 «−», 1 «+», 2 ползунок)
};
struct Hit { uint8_t id; HitKind kind; int16_t x, y, w, h; };
static Hit hits[40];
static uint8_t nHits = 0;

static void addHit(uint8_t id, HitKind k, int x, int y, int w, int h) {
  // кнопка почти у края — тянем зону до края: у краёв тач меряет хуже
  if (x < TOUCH_EDGE_PX)               { w += x; x = 0; }
  if (y < TOUCH_EDGE_PX)               { h += y; y = 0; }
  if (320 - (x + w) < TOUCH_EDGE_PX)   w = 320 - x;
  if (240 - (y + h) < TOUCH_EDGE_PX)   h = 240 - y;
  if (nHits < sizeof(hits) / sizeof(hits[0])) hits[nHits++] = {id, k, (int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h};
}
static int hitAt(int x, int y) {
  x = constrain(x, 0, 319); y = constrain(y, 0, 239);
  for (int i = nHits - 1; i >= 0; i--) {
    const Hit &h = hits[i];
    if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) return i;
  }
  // мимо всех кнопок — засчитываем ближайшую, если промах небольшой
  int best = -1, bestD = TOUCH_NEAR_PX * TOUCH_NEAR_PX + 1;
  for (int i = nHits - 1; i >= 0; i--) {
    const Hit &h = hits[i];
    int dx = x < h.x ? h.x - x : x >= h.x + h.w ? x - (h.x + h.w - 1) : 0;
    int dy = y < h.y ? h.y - y : y >= h.y + h.h ? y - (h.y + h.h - 1) : 0;
    if (dx * dx + dy * dy < bestD) { bestD = dx * dx + dy * dy; best = i; }
  }
  return best;
}

// ---------------------------------------------------------------------
//  Состояние экрана
// ---------------------------------------------------------------------
static volatile bool dirty = true;
static bool menuOpen = false, chartOpen = false;
static uint8_t screenTest = 0;                 // проверка экрана из меню: 0 — нет, 1…4 — страница
static bool touchCalPending = false;           // «Тач» в меню: калибровка после отпускания пальца
static uint8_t menuPage = 0, chartKind = 0;    // chartKind: 0 царга, 1 куб
static uint8_t pressId = B_NONE;               // какая кнопка сейчас нажата (подсветка)
static uint32_t pressAt = 0;                   // когда нажали (для удержания)
static uint32_t bootHeldMs = 0;                // сколько держат BOOT
static uint8_t  appliedBright = 0;

// Окна Тфикс поверх экрана второго перегона (ТЗ «Зафиксировать Тфикс»)
enum Dlg : uint8_t { DLG_NONE = 0, DLG_FIX, DLG_STABLE, DLG_RESTORE, DLG_CLEAR };
static uint8_t  dlg = DLG_NONE;
static char     toastMsg[112] = "";             // «Тфикс зафиксирована: 78,42» на 2 с
static bool     toastBad = false;
static uint32_t toastUntil = 0;

void uiMarkDirty() { dirty = true; }
// Окна «Тфикс из памяти» и «Стабильно, зафиксируйте» закрывает только оператор.
// Если их убрала тревога (охлаждение, перегон сменился и т. п.), окно
// откроется снова, когда тревога уйдёт и вопрос ещё не решён.
static bool wantRestore = false, wantStable = false;
void uiCloseMenu() {
  if (dlg == DLG_RESTORE) wantRestore = true;
  if (dlg == DLG_STABLE) wantStable = true;
  menuOpen = false; chartOpen = false; screenTest = 0; dlg = DLG_NONE; dirty = true;
}

void uiToast(const char *msg, bool bad) {
  snprintf(toastMsg, sizeof(toastMsg), "%s", msg);
  toastBad = bad;
  toastUntil = millis() + 2000;
  dirty = true;
}

static void openDlg(uint8_t d) { menuOpen = false; chartOpen = false; screenTest = 0; dlg = d; toastUntil = 0; dirty = true; }

// ---------------------------------------------------------------------
//  Кнопки и плитки
// ---------------------------------------------------------------------
static void tile(int x, int y, int w, int h, rgb_t bg = C_TILE, rgb_t br = C_TILE_BR) {
  spr.fillRoundRect(x, y, w, h, 6, bg);
  spr.drawRoundRect(x, y, w, h, 6, br);
}

struct BtnStyle { rgb_t bg, br, fg, sub; };
static const BtnStyle S_NORMAL = {C_BTN, C_BTN_BR, C_TXT2, C_MUTED};
static const BtnStyle S_DIM    = {C_BTN, C_BTN_BR, C_BTN_DIM, C_BTN_DIM};
static const BtnStyle S_ALARM  = {C_ALARM, C_ALARM_BR, 0xffffff, C_ALARM_SUB};

static void button(int x, int y, int w, int h, const char *label, const char *sub, uint8_t id, HitKind k,
                   const BtnStyle &s = S_NORMAL, UFont *font = nullptr) {
  bool pressed = id != B_NONE && pressId == id;
  rgb_t bg = pressed ? (s.bg == C_BTN ? C_BTN_ON : blend(0xffffff, s.bg, 0.15f)) : s.bg;
  spr.fillRoundRect(x, y, w, h, 6, bg);
  spr.drawRoundRect(x, y, w, h, 6, s.br);
  UFont &f = font ? *font : fT;
  int cx = x + w / 2;
  if (sub && *sub) {
    txt(label, cx, y + h / 2 + 1, f, s.fg, D_C);
    txt(sub, cx, y + h / 2 + 13, fS, s.sub, D_C);
  } else {
    txt(label, cx, y + h / 2 + 5, f, s.fg, D_C);
  }
  if (k == HOLD && pressed) {               // полоска удержания 1 с
    float p = min(1.0f, (millis() - pressAt) / 1000.0f);
    spr.fillRect(x + 1, y + h - 4, (int)((w - 2) * p), 3, C_ACCENT);
  }
  addHit(id, k, x, y, w, h);
}

static void probeText(const Probe &p, char *buf, size_t n, uint8_t dec) {
  if (p.state == PROBE_OK && !isnan(p.t)) snprintf(buf, n, "%s", fmtNum(p.t, dec).c_str());
  else snprintf(buf, n, "——");
}

// Короткий текст состояния для узких плиток (полный — probeStateText, он в вебе)
static const char *shortState(const Probe &p) {
  if (p.state == PROBE_RANGE) return "тип / Rref?";
  if (p.state == PROBE_FAULT) return "обрыв / КЗ";
  return probeStateText(p);
}

// ---------------------------------------------------------------------
//  Строка состояния и таймер
// ---------------------------------------------------------------------
static void statusBar(const char *mode) {
  rgb_t dot = C_GREY;
  String net;
  // Слева — к какой сети подключён контроллер. Если место есть (экран выбора
  // перегона), рядом и адрес для браузера; на экранах перегонов только имя сети.
  int maxW = (mode ? 160 - textW(mode, fSB) / 2 - 8 : 314 - textW("00:00", fS) - 10) - 17;
  switch (netState()) {
    case NET_ONLINE: {
      dot = C_OK;
      String ssid = netSsid();
      net = ssid + " · " + netAddress();
      if (ssid.isEmpty()) net = netAddress();
      else if (textW(net.c_str(), fS) > maxW) net = ssid;
      break;
    }
    case NET_AP:     dot = C_WARN; net = String(AP_SSID); break;
    default:         dot = C_GREY; net = "Wi-Fi…"; break;
  }
  spr.fillCircle(10, 9, 3, dot);
  txt(fitText(net, fS, maxW), 17, 13, fS, C_MUTED);
  if (mode) txt(mode, 160, 13, fSB, C_WHITE, D_C);
  String clock = timeValid() ? fmtClock(time(nullptr)) : String("--:--");
  txt(clock, 314, 13, fS, C_MUTED, D_R);
}

static void runtimeLine() {
  uint32_t el = st.now - st.runStart;
  int x = txt("ПЕРЕГОНКА ", 6, 237, fS, C_MUTED);
  txt(fmtHMS(el), 6 + x, 237, fSB, C_WHITE);
  if (timeValid()) txt("с " + fmtClock(time(nullptr) - el), 314, 237, fS, C_MUTED, D_R);
}

// Кнопка «Включите охлаждение» поверх нижних кнопок, мигает
static bool coolOverlay() {
  bool tails = st.run == RUN_2 && st.mode == MODE_TAILS;
  if (st.cool != COOL_ALERT || tails) return false;
  float k = 0.5f + 0.5f * sinf(millis() / 1200.0f * 2 * PI);
  rgb_t bg = pressId == B_COOL ? C_COOL2 : blend(C_COOL, C_COOL2, k);
  spr.fillRoundRect(4, 188, 312, 36, 6, bg);
  spr.drawRoundRect(4, 188, 312, 36, 6, C_COOL_BR);
  txt("Включите охлаждение", 160, 205, fT, 0xffffff, D_C);
  String s = "куб " + fmtNum(st.p[CH_CUBE].t, 1) + " °C · нажмите, когда включили";
  txt(s, 160, 218, fS, C_COOL_SUB, D_C);
  addHit(B_COOL, TAP, 4, 188, 312, 36);
  return true;
}

// «Пар в узле отбора» поверх нижних кнопок (второй перегон, разгон); нажатие = «Понятно».
// Пока горит «Включите охлаждение», не показывается (steamAlert), оно важнее.
static bool steamOverlay() {
  if (!steamAlert() || st.mode == MODE_TAILS) return false;
  spr.fillRoundRect(4, 188, 312, 36, 6, pressId == B_STEAM ? C_STEAM2 : C_STEAM);
  spr.drawRoundRect(4, 188, 312, 36, 6, C_HOT);
  txt("Пар в узле отбора", 160, 205, fT, 0xffffff, D_C);
  txt("приступите к стабилизации колонны · нажмите: понятно", 160, 218, fS, C_STEAM_SUB, D_C);
  addHit(B_STEAM, TAP, 4, 188, 312, 36);
  return true;
}

// ---------------------------------------------------------------------
//  Экран выбора перегона
// ---------------------------------------------------------------------
static void drawSelect() {
  statusBar(nullptr);
  txt("ВЫБЕРИТЕ ПЕРЕГОН", 160, 34, fSB, C_MUTED, D_C);
  Run last; uint32_t elapsed = 0;
  bool has = hasSavedRun(last, elapsed);
  for (uint8_t i = 0; i < 2; i++) {
    int x = i ? 163 : 6;
    uint8_t id = i ? B_SEL2 : B_SEL1;
    bool cur = has && last == (i ? RUN_2 : RUN_1);
    rgb_t bg = pressId == id ? C_BTN_ON : C_TILE;
    spr.fillRoundRect(x, 42, 151, 144, 8, bg);
    spr.drawRoundRect(x, 42, 151, 144, 8, cur ? C_ACCENT : C_BTN_BR);
    if (cur) spr.drawRoundRect(x + 1, 43, 149, 142, 7, C_ACCENT);
    int cx = x + 75;
    txt(i ? "Второй" : "Первый", cx, 86, fH, C_WHITE, D_C);
    txt("перегон", cx, 106, fH, C_WHITE, D_C);
    txt(i ? "Тфикс царги, хвосты," : "куб и царга по цветам,", cx, 130, fS, C_MUTED, D_C);
    txt(i ? "куб и узел отбора" : "датчик 3 — воздух", cx, 143, fS, C_MUTED, D_C);
    if (cur) {
      txt("продолжить", cx, 164, fSB, C_ACCENT, D_C);
      txt("таймер " + fmtHMS(elapsed), cx, 177, fS, C_ACCENT, D_C);
    }
    addHit(id, TAP, x, 42, 151, 144);
  }
  if (st.lastRun != RUN_NONE) {
    String back = st.lastRun == RUN_1 ? "Назад к первому перегону" : "Назад ко второму перегону";
    button(6, 192, 308, 28, back.c_str(), nullptr, B_BACK, TAP);
  }
  // адрес для браузера
  String addr = netState() == NET_ONLINE ? String(NET_HOSTNAME) + ".local · " + netAddress()
              : netState() == NET_AP ? String("Wi-Fi «") + AP_SSID + "» → 192.168.4.1" : String("подключаюсь к Wi-Fi…");
  txt(addr, 160, 236, fS, C_DIM, D_C);
}

// ---------------------------------------------------------------------
//  Первый перегон: три плитки, график куба, две кнопки
// ---------------------------------------------------------------------
static const float SC_LO = 20, SC_HI = 100;   // шкала под плитками, °C

static void zoneScale(int x, int y, int w, const float *edges, uint8_t nEdges, const rgb_t *cols, float t) {
  // полоска из цветных отрезков от 20 до 100 °C и белая отметка текущей температуры
  float prev = SC_LO;
  for (uint8_t i = 0; i <= nEdges; i++) {
    float e = i < nEdges ? constrain(edges[i], SC_LO, SC_HI) : SC_HI;
    int xa = x + (int)((prev - SC_LO) / (SC_HI - SC_LO) * w);
    int xb = x + (int)((e - SC_LO) / (SC_HI - SC_LO) * w);
    if (xb > xa) spr.fillRect(xa, y, xb - xa, 4, cols[i]);
    prev = max(prev, e);
  }
  if (!isnan(t)) {
    float p = constrain((t - SC_LO) / (SC_HI - SC_LO), 0.0f, 1.0f);
    spr.fillRect(x + (int)(p * w) - 1, y - 2, 2, 8, C_WHITE);
  }
}

static void tile3(int x, const char *name, const char *dn, const Probe &p, Tone tone, const char *zone, bool scale,
                  const float *edges, uint8_t nEdges) {
  rgb_t c = toneColor(tone);
  tile(x, 20, 102, 66, C_TILE, scale && tone != TONE_GREY ? c : C_TILE_BR);
  txt(name, x + 8, 32, fSB, C_MUTED);
  txt(dn, x + 95, 32, fS, C_DIM, D_R);
  char v[16];
  probeText(p, v, sizeof(v), 1);
  txt(v, x + 8, 55, fM, scale ? c : C_TXT);
  txt("°C", x + 95, 55, fS, C_DIM, D_R);
  if (scale) {
    spr.fillRoundRect(x + 7, 61, 88, 12, 3, tone == TONE_GREY ? C_TILE_BR : c);
    txt(zone, x + 51, 71, fSB, tone == TONE_GREY ? C_MUTED : C_BG, D_C);
    static const rgb_t cols[5] = {C_COLD, C_OK, C_WARN, C_HOT, C_BAD};
    zoneScale(x + 8, 78, 86, edges, nEdges, cols, p.state == PROBE_OK ? p.t : NAN);
  } else {
    txt(zone, x + 51, 71, fS, C_MUTED, D_C);
  }
}

// Линия графика толщиной 2 пикселя. Сглаженная drawWideLine на коротких
// отрезках даёт «бусы», поэтому рисуем два обычных drawLine рядом.
static void chartLine(int xa, int ya, int xb, int yb, rgb_t c) {
  spr.drawLine(xa, ya, xb, yb, c);
  if (abs(yb - ya) > abs(xb - xa)) spr.drawLine(xa + 1, ya, xb + 1, yb, c);   // круто — толщина по X
  else spr.drawLine(xa, ya + 1, xb, yb + 1, c);                                // полого — толщина по Y
}

// График куба 312×94 (как в макете: шкала не уже 4 °C, ≤ 4 делений, зоны цветом)
static void cubeChartSmall() {
  const int TX = 4, TY = 90;
  tile(TX, TY, 312, 94);
  const int x0 = TX + 30, x1 = TX + 304, y0 = TY + 21, y1 = TY + 78;
  uint32_t span = cfg.chartMin * 60;
  uint16_t n = recentCount();
  uint32_t maxBack = n ? min<uint32_t>(span, n - 1) : 0;
  float lo = 1e9f, hi = -1e9f;
  for (uint32_t b = 0; b <= maxBack && n; b++) {
    float v = recentAt(b).k;
    if (!isnan(v)) { lo = min(lo, v); hi = max(hi, v); }
  }
  char buf[40];
  snprintf(buf, sizeof(buf), "КУБ · %u МИН", cfg.chartMin);
  txt(buf, TX + 8, TY + 12, fSB, C_MUTED);
  if (lo > hi) {                                  // данных ещё нет
    txt("нет данных", (x0 + x1) / 2, (y0 + y1) / 2 + 4, fS, C_DIM, D_C);
    return;
  }
  if (hi - lo < 4) { float c = (lo + hi) / 2; lo = c - 2; hi = c + 2; }
  static const float steps[] = {1, 2, 5, 10, 20, 50};
  float stp = 50;
  for (float s : steps) if (ceilf(hi / s) - floorf(lo / s) <= 4) { stp = s; break; }
  lo = floorf(lo / stp) * stp; hi = ceilf(hi / stp) * stp;
  auto X = [&](float back) { return x1 - (x1 - x0) * back / span; };
  auto Y = [&](float v) { return y1 - (y1 - y0) * (v - lo) / (hi - lo); };

  // фон зонами куба и цветная полоска сбоку
  const float *z = cfg.z1;
  float edges[6] = {-100, z[0], z[1], z[2], z[3], 200};
  static const rgb_t cols[5] = {C_COLD, C_OK, C_WARN, C_HOT, C_BAD};
  for (uint8_t i = 0; i < 5; i++) {
    float a = max(edges[i], lo), b = min(edges[i + 1], hi);
    if (b <= a) continue;
    int ya = (int)roundf(Y(a)), yb = (int)roundf(Y(b));
    spr.fillRect(x0, yb, x1 - x0, ya - yb, blend(cols[i], C_TILE, 0.16f));
    spr.fillRect(x0 - 3, yb, 3, ya - yb, cols[i]);
  }
  for (float v = lo; v <= hi + stp / 2; v += stp) {
    int y = (int)roundf(Y(v));
    spr.drawFastHLine(x0, y, x1 - x0, C_TILE_BR);
    txt(fmtNum(v, 0), x0 - 5, y + 4, fS, C_MUTED, D_R);
  }
  // линия температуры: точки раз в 1–6 с, чтобы в окне было не больше ~270 точек
  uint32_t stepS = max<uint32_t>(1, (span + 273) / 274);
  spr.setClipRect(x0, y0 - 2, x1 - x0 + 4, y1 - y0 + 4);
  bool havePrev = false; int px = 0, py = 0;
  for (int32_t b = (int32_t)(maxBack - maxBack % stepS); b >= 0; b -= stepS) {
    float v = recentAt(b).k;
    if (isnan(v)) { havePrev = false; continue; }
    int x = (int)roundf(X(b)), y = (int)roundf(Y(v));
    if (havePrev) chartLine(px, py, x, y, C_WHITE);
    px = x; py = y; havePrev = true;
  }
  float last = recentAt(0).k;
  if (!isnan(last)) spr.fillSmoothCircle((int)X(0), (int)roundf(Y(last)), 3, toneColor(cubeTone(last)));
  spr.clearClipRect();

  // скорость нагрева за последние 5 минут
  uint32_t b5 = min<uint32_t>(300, n ? n - 1 : 0);
  float old = NAN;
  while (b5 >= 60 && isnan(old = recentAt(b5).k)) b5--;
  String rate = "—";
  if (!isnan(last) && !isnan(old) && b5 >= 60) {
    float r = (last - old) / (b5 / 60.0f);
    rate = fabsf(r) < 0.05f ? String("стоит") : fmtSigned(r, 1) + " °C/мин";
  }
  txt(rate, TX + 304, TY + 12, fSB, isnan(last) ? C_MUTED : toneColor(cubeTone(last)), D_R);
  // подписи времени
  txt("−" + fmtMS(span), x0, TY + 90, fS, C_MUTED, D_L);
  txt("−" + fmtMS(span / 2), (x0 + x1) / 2, TY + 90, fS, C_MUTED, D_C);
  txt("сейчас", x1, TY + 90, fS, C_MUTED, D_R);
}

static void drawRun1() {
  statusBar("ПЕРВЫЙ ПЕРЕГОН");
  char zbuf[24];
  const Probe &k = st.p[CH_CUBE], &c = st.p[CH_COLUMN], &a = st.p[CH_THIRD];
  float kt = k.state == PROBE_OK ? k.t : NAN, ct = c.state == PROBE_OK ? c.t : NAN;
  const char *kz = k.state == PROBE_OK ? cubeZoneText(kt, zbuf, sizeof(zbuf)) : shortState(k);
  tile3(4, "КУБ", "№1", k, cubeTone(kt), kz, true, cfg.z1, 4);
  char cz[24];
  if (c.state == PROBE_OK) snprintf(cz, sizeof(cz), "%s %s", ct < cfg.col1 ? "ниже" : "от", fmtNum(cfg.col1, 0).c_str());
  else snprintf(cz, sizeof(cz), "%s", shortState(c));
  float colEdges[1] = {cfg.col1};
  tile3(109, "ЦАРГА", "№2", c, col1Tone(ct), cz, true, colEdges, 1);
  tile3(214, "ВОЗДУХ", "№3", a, TONE_WHITE, a.state == PROBE_OK ? "не участвует" : shortState(a), false, nullptr, 0);
  cubeChartSmall();
  if (!coolOverlay()) {
    // «Сменить перегон» — в меню (внизу меню, как во втором перегоне)
    button(4, 188, 312, 36, "Меню", "пороги, экран, смена перегона", B_MENU, TAP);
  }
  runtimeLine();
}

// ---------------------------------------------------------------------
//  Второй перегон: царга крупно, куб и УО, три кнопки
// ---------------------------------------------------------------------
static void drawRun2() {
  statusBar("ВТОРОЙ ПЕРЕГОН");
  const Probe &c = st.p[CH_COLUMN];
  bool colOk = columnValid();                   // датчик в норме и данные свежие
  Tone tone = columnTone();
  rgb_t tc = toneColor(tone);
  bool tails = st.mode == MODE_TAILS;
  bool flash = tails && (millis() / 500) % 2;

  // --- плитка царги ---
  rgb_t bg = tails ? (flash ? C_FLASH : C_TAILS_BG) : C_TILE;
  tile(4, 20, 312, 104, bg, tone == TONE_WHITE || tone == TONE_GREY ? C_TILE_BR : tc);
  txt("ЦАРГА", 12, 33, fSB, C_MUTED);
  const char *chip = !colOk ? "ДАТЧИК" : st.fixConfirm ? "ПОДТВЕРДИТЕ" : st.mode == MODE_TAILS ? "ХВОСТЫ"
                   : st.mode == MODE_STAB ? "СТАБИЛ." : isnan(st.fix) ? "БЕЗ ТФИКС" : "ОТБОР";
  int cw = textW(chip, fSB) + 12;
  bool chipColored = tone != TONE_WHITE && tone != TONE_GREY;
  spr.fillRoundRect(309 - cw, 24, cw, 13, 3, chipColored ? tc : C_TILE_BR);
  txt(chip, 309 - cw / 2, 34, fSB, chipColored ? C_BG : C_TXT, D_C);

  char big[16];
  if (st.stale) snprintf(big, sizeof(big), "——");
  else probeText(c, big, sizeof(big), 2);
  txt(big, 160, 86, fXL, colOk ? tc : C_GREY, D_C);

  String L, R;
  rgb_t rc = C_TXT;
  if (!colOk) {
    // нет достоверных данных: причина слева, Тфикс (если есть) сохраняется справа
    L = st.stale && c.state == PROBE_OK ? String("нет свежих данных") : String(probeStateText(c));
    if (!isnan(st.fix)) R = "Тфикс " + fmtNum(st.fix, 2) + " сохранена";
    else if (c.state == PROBE_RANGE) R = fmtNum(c.ohm, 1) + " Ом";          // PT100 ~108, PT1000 ~1080 при 20 °C
    else if (c.state == PROBE_FAULT) R = "провода датчика 2";
    else if (st.stale) R = "Тфикс не задана";
    else R = "датчик 2, CS GPIO" + String(PIN_CS_COLUMN);
    if (!isnan(st.fix) && textW(L.c_str(), fT) + textW(R.c_str(), fT) + 12 > 296) R = "Тфикс " + fmtNum(st.fix, 2);
  } else if (st.fixConfirm) {
    L = "Тфикс " + fmtNum(st.fix, 2) + " из памяти"; R = "Δ " + fmtSigned(c.t - st.fix, 2) + " · нажмите";
  } else if (st.mode == MODE_STAB && st.ask) {
    spr.fillRect(12, 96, 296, 3, C_STAB);
    L = "стабильно " + fmtMS(cfg.stabWindow); R = "зафиксируйте Тфикс"; rc = C_OK;
  } else if (st.mode == MODE_STAB) {
    uint32_t el = min<uint32_t>(cfg.stabWindow, st.stableFor);
    spr.fillRect(12, 96, 296, 3, C_TILE_BR);
    spr.fillRect(12, 96, (int)(296.0f * el / cfg.stabWindow), 3, C_STAB);
    L = "стабилизация " + fmtMS(el) + " / " + fmtMS(cfg.stabWindow);
    R = "размах " + fmtNum(st.spread, 2);
  } else if (isnan(st.fix)) {
    if (st.spreadReady && st.spread <= 0.05f + 1e-4f) {
      L = "размах " + fmtNum(st.spread, 2); R = "стабильно, фиксируйте"; rc = C_OK;
    } else {
      L = "размах за " + String(cfg.stabWindow / 60) + " мин " + fmtNum(st.spread, 2); R = "Тфикс не задана";
    }
  } else if (st.now < st.newUntil) {
    L = "Новая Тфикс " + fmtNum(st.fix, 2); R = "открывайте отбор"; rc = C_OK;
  } else {
    L = "Тфикс " + fmtNum(st.fix, 2); R = "Δ " + fmtSigned(c.t - st.fix, 2); rc = tc;
  }
  txt(L, 12, 116, fT, C_TXT);
  txt(R, 308, 116, fT, rc, D_R);
  addHit(B_TCOL, TAP, 4, 20, 312, 104);

  // --- куб ---
  const Probe &k = st.p[CH_CUBE];
  float kt = k.state == PROBE_OK ? k.t : NAN;
  char v[16], zb[24];
  tile(4, 128, 196, 56);
  txt("КУБ", 12, 141, fSB, C_MUTED);
  probeText(k, v, sizeof(v), 1);
  txt(v, 12, 177, fL, toneColor(cubeTone(kt)));
  txt(k.state == PROBE_OK ? cubeZoneText(kt, zb, sizeof(zb)) : probeStateText(k), 192, 175, fS, C_MUTED, D_R);
  addHit(B_TCUBE, TAP, 4, 128, 196, 56);

  // --- узел отбора: без отметки зелёный, с отметкой отбора — цвет и подпись
  //     (жёлтая «ГОЛОВЫ», зелёная «ТЕЛО», красная «ЗАКРЫТ 3:12»); нажатие переключает.
  //     Отметка видна и при неисправном/выключенном датчике: иначе нажатия
  //     меняли бы её вслепую
  const Probe &u = st.p[CH_THIRD];
  String uoL = uoLabel();
  rgb_t uc = st.uo == UO_HEADS ? C_WARN : st.uo == UO_CLOSED ? C_BAD : C_OK;
  tile(204, 128, 112, 56, C_TILE, uoL.isEmpty() ? C_TILE_BR : uc);
  txt("УЗЕЛ ОТБОРА", 212, 141, fSB, C_MUTED);
  probeText(u, v, sizeof(v), 1);
  if (u.state != PROBE_OK && uoL.isEmpty()) {     // «——» и причина под ним
    txt(v, 212, 165, fM, C_GREY);
    txt(shortState(u), 212, 179, fS, C_MUTED);
  } else if (u.state != PROBE_OK) {               // «——», причина справа, под ними отметка
    txt(v, 212, 163, fM, C_GREY);
    txt(shortState(u), 308, 163, fS, C_MUTED, D_R);
    spr.fillRoundRect(211, 168, 98, 13, 3, uc);
    txt(uoL, 260, 178, fSB, C_BG, D_C);
  } else if (uoL.isEmpty()) {
    txt(v, 212, 177, fL, C_OK);
  } else {                                        // число поменьше, под ним цветная подпись
    txt(v, 212, 163, fM, uc);
    txt("°C", 308, 163, fS, C_DIM, D_R);
    spr.fillRoundRect(211, 168, 98, 13, 3, uc);
    txt(uoL, 260, 178, fSB, C_BG, D_C);
  }
  addHit(B_TUO, TAP, 204, 128, 112, 56);

  // --- кнопки ---
  if (!coolOverlay() && !steamOverlay()) {
    bool faultAlarm = st.faultMask & ~st.faultAck;
    if (tails) {
      // во время тревоги кнопка сброса красная и больше
      button(4, 188, 90, 36, "Тфикс", "зафиксировать", B_FIX, TAP);
      button(98, 188, 146, 36, "Сброс тревоги", "отбор закрыт", B_RESET, TAP, S_ALARM);
    } else {
      // нажатие открывает окно подтверждения (или окно «из памяти» / «стабильно»)
      button(4, 188, 118, 36, "Зафиксировать", "Тфикс", B_FIX, TAP);
      if (faultAlarm) button(126, 188, 118, 36, "Сброс тревоги", "датчик", B_RESET, TAP, S_ALARM);
      else button(126, 188, 118, 36, "Сброс тревоги", nullptr, B_RESET, TAP, S_DIM);
    }
    String sub = "окно " + String(cfg.stabWindow / 60) + " мин";
    button(248, 188, 68, 36, "Меню", sub.c_str(), B_MENU, TAP);
  }
  runtimeLine();
}

// ---------------------------------------------------------------------
//  График царги или куба за 30 минут (второй перегон, нажатие на плитку)
// ---------------------------------------------------------------------
struct Scale { float lo, hi, step; uint8_t dec; };

static Scale niceScale(float lo, float hi, float minSpan) {
  if (hi - lo < minSpan) { float c = (lo + hi) / 2; lo = c - minSpan / 2; hi = c + minSpan / 2; }
  float pad = (hi - lo) * 0.08f; lo -= pad; hi += pad;
  static const float steps[] = {0.01f, 0.02f, 0.05f, 0.1f, 0.2f, 0.5f, 1, 2, 5, 10, 20};
  float s = 20;
  for (float x : steps) if ((hi - lo) / x <= 5) { s = x; break; }
  lo = floorf(lo / s + 1e-4f) * s; hi = ceilf(hi / s - 1e-4f) * s;
  return {lo, hi, s, (uint8_t)(s < 0.1f ? 2 : s < 1 ? 1 : 0)};
}

static void drawBigChart() {
  const uint32_t span = 1800;
  bool col = chartKind == 0;
  uint16_t n = recentCount();
  uint32_t maxBack = n ? min<uint32_t>(span, n - 1) : 0;
  auto val = [&](uint32_t b) { Sample s = recentAt(b); return col ? s.c : s.k; };
  float lo = 1e9f, hi = -1e9f;
  for (uint32_t b = 0; b <= maxBack && n; b++) { float v = val(b); if (!isnan(v)) { lo = min(lo, v); hi = max(hi, v); } }
  bool haveFix = col && !isnan(st.fix);
  if (haveFix) { lo = min(lo, st.fix); hi = max(hi, st.fix); }
  float last = val(0);
  Tone tone = col ? columnTone() : cubeTone(last);

  txt(col ? "ЦАРГА · 30 МИН" : "КУБ · 30 МИН", 8, 14, fSB, C_MUTED);
  txt(fmtNum(last, col ? 2 : 1) + " °C", 312, 15, fV, toneColor(tone), D_R);
  const int x0 = 44, x1 = 312, y0 = 24, y1 = 188;
  tile(4, 20, 312, 186);
  if (lo > hi) {
    txt("нет данных", 160, 110, fT, C_DIM, D_C);
  } else {
    Scale sc = niceScale(lo, hi, col ? 0.12f : 2.0f);
    auto X = [&](float back) { return x1 - (x1 - x0) * back / span; };
    auto Y = [&](float v) { return y1 - (y1 - y0) * (constrain(v, sc.lo, sc.hi) - sc.lo) / (sc.hi - sc.lo); };
    // цветные полосы
    auto band = [&](float a, float b, rgb_t c) {
      a = max(a, sc.lo); b = min(b, sc.hi);
      if (b <= a) return;
      int ya = (int)roundf(Y(a)), yb = (int)roundf(Y(b));
      spr.fillRect(x0, yb, x1 - x0, ya - yb, blend(c, C_TILE, 0.14f));
    };
    if (col && haveFix) {
      band(sc.lo - 1, st.fix + cfg.green, C_OK);
      band(st.fix + cfg.green, st.fix + cfg.red, C_WARN);
      band(st.fix + cfg.red, sc.hi + 1, C_BAD);
    } else if (!col) {
      const float *z = cfg.z2;
      band(-100, z[0], C_COLD); band(z[0], z[1], C_OK); band(z[1], z[2], C_WARN);
      band(z[2], z[3], C_HOT); band(z[3], 200, C_BAD);
    }
    for (float v = sc.lo; v <= sc.hi + sc.step / 2; v += sc.step) {
      int y = (int)roundf(Y(v));
      spr.drawFastHLine(x0, y, x1 - x0, C_TILE_BR);
      txt(fmtNum(v, sc.dec), x0 - 4, y + 4, fS, C_MUTED, D_R);
    }
    // Тфикс: пунктир по времени (каждая Тфикс от момента записи)
    if (col) {
      for (uint8_t i = 0; i < st.nFixes; i++) {
        uint32_t from = st.now - st.fixes[i].t;
        uint32_t to = i + 1 < st.nFixes ? st.now - st.fixes[i + 1].t : 0;
        if (to > span || isnan(st.fixes[i].v)) continue;   // NAN — здесь Тфикс сбросили
        int xa = (int)X(min(from, span)), xb = (int)X(to);
        int y = (int)roundf(Y(st.fixes[i].v));
        for (int x = xa; x < xb; x += 9) spr.drawFastHLine(x, y, min(5, xb - x), C_OK);
      }
      if (haveFix) txt("Тфикс " + fmtNum(st.fix, 2), x1 - 4, (int)Y(st.fix) - 4, fS, C_OK, D_R);
    }
    spr.setClipRect(x0, y0 - 2, x1 - x0 + 2, y1 - y0 + 4);
    uint32_t stepS = 2;                        // точка раз в 2 с, 900 точек
    bool havePrev = false; int px = 0, py = 0;
    for (int32_t b = (int32_t)(maxBack - maxBack % stepS); b >= 0; b -= stepS) {
      float v = val(b);
      if (isnan(v)) { havePrev = false; continue; }
      int x = (int)roundf(X(b)), y = (int)roundf(Y(v));
      if (havePrev) chartLine(px, py, x, y, C_WHITE);
      px = x; py = y; havePrev = true;
    }
    if (!isnan(last)) spr.fillSmoothCircle(x1 - 1, (int)roundf(Y(last)), 3, toneColor(tone));
    spr.clearClipRect();
  }
  txt("−30 мин", x0, 202, fS, C_MUTED, D_L);
  txt("−20", x0 + (x1 - x0) / 3, 202, fS, C_MUTED, D_C);
  txt("−10", x0 + (x1 - x0) * 2 / 3, 202, fS, C_MUTED, D_C);
  txt("сейчас", x1, 202, fS, C_MUTED, D_R);
  button(4, 208, 312, 28, "Назад", nullptr, B_CHART_CLOSE, TAP);
  addHit(B_CHART_CLOSE, TAP, 0, 0, 320, 206);   // нажатие на сам график тоже закрывает
}

// ---------------------------------------------------------------------
//  Меню: вкладки, строки с − и + или ползунком
// ---------------------------------------------------------------------
enum RowKind : uint8_t { R_STEP, R_SLIDER, R_TIMER, R_ACT };
struct MenuRow {
  const char *title, *hint;
  RowKind kind;
  void (*step)(int d);          // для R_STEP
  String (*value)();
  int16_t smin, smax, sstep;    // для R_SLIDER
  int (*sget)();
  void (*sset)(int v);
  const char *btnA, *btnB;      // для R_ACT: две кнопки, step(-1) и step(+1)
};

static float rnd1(float v) { return roundf(v * 10) / 10; }
static float rnd2(float v) { return roundf(v * 100) / 100; }

static const MenuRow ROW_TIMER = {"Таймер перегонки", "держать 1 с: обнулить", R_TIMER, nullptr,
  []() -> String { return fmtHMS(st.now - st.runStart); }, 0, 0, 0, nullptr, nullptr};
static const MenuRow ROW_LIGHT = {"Подсветка", "при тревоге 100%", R_SLIDER, nullptr,
  []() -> String { return String(cfg.bright) + "%"; }, 10, 100, 5, [] { return (int)cfg.bright; }, [](int v) { cfg.bright = v; }};
static const MenuRow ROW_TEST = {"Проверка экрана", "цвета · калибровка тача", R_ACT,
  [](int d) { if (d < 0) screenTest = 1; else touchCalPending = true; },
  nullptr, 0, 0, 0, nullptr, nullptr, "Цвета", "Тач"};
static const MenuRow ROW_CHART = {"График куба", "окно, 1–30 мин", R_SLIDER, nullptr,
  []() -> String { return String(cfg.chartMin) + " мин"; }, 1, 30, 1, [] { return (int)cfg.chartMin; }, [](int v) { cfg.chartMin = v; }};

// второй перегон, вкладка «Царга»
static const MenuRow M2_COL[] = {
  {"Окно стабилизации", "2–15 мин", R_STEP,
    [](int d) { cfg.stabWindow = constrain(cfg.stabWindow / 60 + d, 2, 15) * 60; },
    []() -> String { return String(cfg.stabWindow / 60) + " мин"; }},
  {"Зелёный до", "выше — жёлтый", R_STEP,
    [](int d) { cfg.green = rnd2(constrain(cfg.green + d * 0.01f, 0.02f, cfg.red - 0.01f)); },
    []() -> String { return "+" + fmtNum(cfg.green, 2); }},
  {"Тревога выше", "красный, зуммер", R_STEP,
    [](int d) { cfg.red = rnd2(constrain(cfg.red + d * 0.01f, cfg.green + 0.01f, 0.30f)); },
    []() -> String { return "+" + fmtNum(cfg.red, 2); }},
  {"Задержка тревоги", "1–10 с", R_STEP,
    [](int d) { cfg.alarmDelay = constrain(cfg.alarmDelay + d, 1, 10); },
    []() -> String { return String(cfg.alarmDelay) + " с"; }},
  {"Зуммер", "тревога и сигналы", R_STEP,
    [](int) { cfg.buzzer = !cfg.buzzer; },
    []() -> String { return String(cfg.buzzer ? "вкл" : "выкл"); }},
  // сброс Тфикс только отсюда и с подтверждением (на главном экране кнопки нет)
  {"Тфикс", "сброс с подтверждением", R_ACT,
    [](int) { if (isnan(st.fix)) uiToast("Тфикс не задана", true); else openDlg(DLG_CLEAR); },
    nullptr, 0, 0, 0, nullptr, nullptr, "Сбросить Тфикс", nullptr},
};
// второй перегон, вкладка «Куб»
static const MenuRow M2_CUBE[] = {
  {"Куб: зелёный от", "и сигнал охлаждения", R_STEP,
    [](int d) { cfg.z2[0] = rnd1(constrain(cfg.z2[0] + d * 0.5f, 30.0f, cfg.z2[1] - 0.1f)); },
    []() -> String { return fmtNum(cfg.z2[0], 1); }},
  {"Куб: жёлтый от", "шаг 0,1", R_STEP,
    [](int d) { cfg.z2[1] = rnd1(constrain(cfg.z2[1] + d * 0.1f, cfg.z2[0] + 0.1f, cfg.z2[2] - 0.1f)); },
    []() -> String { return fmtNum(cfg.z2[1], 1); }},
  {"Куб: оранжевый от", "шаг 0,1", R_STEP,
    [](int d) { cfg.z2[2] = rnd1(constrain(cfg.z2[2] + d * 0.1f, cfg.z2[1] + 0.1f, cfg.z2[3] - 0.1f)); },
    []() -> String { return fmtNum(cfg.z2[2], 1); }},
  {"Куб: красный от", "шаг 0,1", R_STEP,
    [](int d) { cfg.z2[3] = rnd1(constrain(cfg.z2[3] + d * 0.1f, cfg.z2[2] + 0.1f, 99.0f)); },
    []() -> String { return fmtNum(cfg.z2[3], 1); }},
  // сигнал «пар в узле отбора» на разгоне: датчик 3 впервые выше порога
  {"Пар в узле отбора", "датчик 3 выше, 30–90", R_STEP,
    [](int d) { cfg.steamC = constrain(roundf(cfg.steamC) + d, 30.0f, 90.0f); },
    []() -> String { return fmtNum(cfg.steamC, 0); }},
};
// второй перегон, вкладка «Экран»
static const MenuRow M2_SCREEN[] = { ROW_TIMER, ROW_LIGHT, ROW_TEST };
// первый перегон, вкладка «Пороги»
static const MenuRow M1_ZONES[] = {
  {"Куб: зелёный от", "и сигнал охлаждения", R_STEP,
    [](int d) { cfg.z1[0] = rnd1(constrain(cfg.z1[0] + d * 0.5f, 30.0f, cfg.z1[1] - 0.5f)); },
    []() -> String { return fmtNum(cfg.z1[0], 1); }},
  {"Куб: жёлтый от", "шаг 0,5", R_STEP,
    [](int d) { cfg.z1[1] = rnd1(constrain(cfg.z1[1] + d * 0.5f, cfg.z1[0] + 0.5f, cfg.z1[2] - 0.5f)); },
    []() -> String { return fmtNum(cfg.z1[1], 1); }},
  {"Куб: оранжевый от", "шаг 0,5", R_STEP,
    [](int d) { cfg.z1[2] = rnd1(constrain(cfg.z1[2] + d * 0.5f, cfg.z1[1] + 0.5f, cfg.z1[3] - 0.5f)); },
    []() -> String { return fmtNum(cfg.z1[2], 1); }},
  {"Куб: красный от", "шаг 0,5", R_STEP,
    [](int d) { cfg.z1[3] = rnd1(constrain(cfg.z1[3] + d * 0.5f, cfg.z1[2] + 0.5f, 100.0f)); },
    []() -> String { return fmtNum(cfg.z1[3], 1); }},
  {"Царга: зелёная от", "ниже — синяя", R_STEP,
    [](int d) { cfg.col1 = rnd1(constrain(cfg.col1 + d * 0.5f, 30.0f, 95.0f)); },
    []() -> String { return fmtNum(cfg.col1, 1); }},
};
// первый перегон, вкладка «Экран»
static const MenuRow M1_SCREEN[] = { ROW_CHART, ROW_TIMER, ROW_LIGHT, ROW_TEST };

static void menuPageRows(const MenuRow *&rows, uint8_t &n) {
  if (st.run == RUN_1) {
    if (menuPage == 0) { rows = M1_ZONES; n = 5; } else { rows = M1_SCREEN; n = 4; }
  } else {
    if (menuPage == 0)      { rows = M2_COL; n = 6; }
    else if (menuPage == 1) { rows = M2_CUBE; n = 5; }
    else                    { rows = M2_SCREEN; n = 3; }
  }
}

// геометрия строк меню (общая для рисования и обработки ползунка)
static const int SL_X = 162, SL_W = 100;

static void drawMenu() {
  // первый перегон: «Пороги» | «Экран»; второй: «Царга» | «Куб» | «Экран»
  static const char *tabs1[] = {"Пороги", "Экран"}, *tabs2[] = {"Царга", "Куб", "Экран"};
  const char **tabs = st.run == RUN_1 ? tabs1 : tabs2;
  uint8_t nt = st.run == RUN_1 ? 2 : 3;
  if (menuPage >= nt) menuPage = 0;
  int tw = (312 - 4 * (nt - 1)) / nt;
  for (uint8_t i = 0; i < nt; i++) {
    int x = 4 + i * (tw + 4);
    bool on = menuPage == i;
    spr.fillRoundRect(x, 4, tw, 26, 5, on ? C_TAB_ON : C_TILE);
    spr.drawRoundRect(x, 4, tw, 26, 5, on ? C_ACCENT : C_BTN_BR);
    txt(tabs[i], x + tw / 2, 22, fT, on ? C_WHITE : C_MUTED, D_C);
    addHit(B_TAB0 + i, TAP, x, 4, tw, 26);
  }
  const MenuRow *rows; uint8_t n;
  menuPageRows(rows, n);
  uint8_t slots = max<uint8_t>(5, n);
  float rh = (168.0f - 3 * (slots - 1)) / slots;
  for (uint8_t i = 0; i < n; i++) {
    const MenuRow &r = rows[i];
    int y = 34 + (int)roundf(i * (rh + 3)), h = (int)rh;
    spr.fillRoundRect(4, y, 312, h, 5, C_TILE);
    spr.drawRoundRect(4, y, 312, h, 5, C_TILE_BR);
    bool compact = h < 28;
    txt(r.title, 12, y + (compact ? 11 : 14), fT, C_TXT);
    txt(r.hint, 12, y + (compact ? 22 : 26), fS, C_DIM);
    uint8_t base = B_ROW + i * 4;
    if (r.kind == R_SLIDER) {
      int v = r.sget();
      float p = (float)(v - r.smin) / (r.smax - r.smin);
      int cy = y + h / 2;
      spr.fillRoundRect(SL_X, cy - 2, SL_W, 4, 2, C_BTN_BR);
      spr.fillRoundRect(SL_X, cy - 2, (int)(SL_W * p), 4, 2, C_ACCENT);
      spr.fillSmoothCircle(SL_X + (int)(SL_W * p), cy, 7, pressId == base + 2 ? C_WHITE : C_ACCENT);
      txt(r.value(), 312, cy + 5, fV, C_WHITE, D_R);
      addHit(base + 2, SLIDE, SL_X - 12, y, SL_W + 24, h);
    } else if (r.kind == R_ACT && !r.btnB) {        // одна широкая кнопка
      int bh = min(h - 4, 26), by = y + (h - bh) / 2;
      uint8_t id = base;
      spr.fillRoundRect(162, by, 150, bh, 4, pressId == id ? C_BTN_ON : C_BTN);
      spr.drawRoundRect(162, by, 150, bh, 4, C_BTN_BR);
      txt(r.btnA, 237, by + bh / 2 + 5, fT, C_WHITE, D_C);
      addHit(id, TAP, 162, y, 150, h);
    } else if (r.kind == R_ACT) {
      int bh = min(h - 4, 26), by = y + (h - bh) / 2;
      for (uint8_t j = 0; j < 2; j++) {
        int bx = j ? 241 : 162;
        uint8_t id = base + j;
        spr.fillRoundRect(bx, by, 71, bh, 4, pressId == id ? C_BTN_ON : C_BTN);
        spr.drawRoundRect(bx, by, 71, bh, 4, C_BTN_BR);
        txt(j ? r.btnB : r.btnA, bx + 35, by + bh / 2 + 5, fT, C_WHITE, D_C);
        addHit(id, TAP, bx, y, 71, h);
      }
    } else {
      HitKind k = r.kind == R_TIMER ? HOLD : REPEAT;
      int bh = min(h - 4, 26), by = y + (h - bh) / 2;
      for (uint8_t j = 0; j < 2; j++) {
        int bx = j ? 270 : 162;
        uint8_t id = base + j;
        bool pressed = pressId == id;
        spr.fillRoundRect(bx, by, 42, bh, 4, pressed ? C_BTN_ON : C_BTN);
        spr.drawRoundRect(bx, by, 42, bh, 4, C_BTN_BR);
        txt(j ? "+" : "−", bx + 21, by + bh / 2 + 5, fV, C_WHITE, D_C);
        if (k == HOLD && pressed) {
          float p = min(1.0f, (millis() - pressAt) / 1000.0f);
          spr.fillRect(bx + 1, by + bh - 3, (int)(40 * p), 2, C_ACCENT);
        }
        addHit(id, k, bx, y, 42, h);
      }
      txt(r.value(), 237, y + h / 2 + 5, fV, C_WHITE, D_C);
    }
  }
  button(4, 206, 154, 30, "Сменить перегон", nullptr, B_MRUN, TAP);
  button(162, 206, 154, 30, "Готово", nullptr, B_MDONE, TAP);
}

// ---------------------------------------------------------------------
//  Проверка экрана из меню: 4 страницы, нажатие — следующая
//    1 цветные полосы и «ВЕРХ» (LCD_INVERT, LCD_RGB_ORDER, поворот)
//    2 16 градаций серого (пересвет: тёмные сливаются с серым)
//    3 чёрное поле (свет подсветки по краям)
//    4 белое поле (пятна, полосы), потом обратно в меню
// ---------------------------------------------------------------------
static void drawScreenTest() {
  char tag[40];
  switch (screenTest) {
    case 1: {
      spr.fillScreen(0x000000);
      static const rgb_t bars[4] = {0xff0000, 0x00ff00, 0x0000ff, 0xffffff};
      static const char *names[4] = {"КРАСНЫЙ", "ЗЕЛЁНЫЙ", "СИНИЙ", "БЕЛЫЙ"};
      for (uint8_t i = 0; i < 4; i++) {
        spr.fillRect(14 + i * 73, 20, 73, 140, bars[i]);
        txt(names[i], 14 + i * 73 + 36, 152, fS, i == 2 ? 0xffffff : 0x000000, D_C);
      }
      txt("ВЕРХ", 160, 14, fSB, 0xffffff, D_C);
      for (uint8_t c = 0; c < 4; c++) {                       // уголки: экран не обрезан и не сдвинут
        int x = c & 1 ? 306 : 0, y = c & 2 ? 238 : 0;           // горизонтальная черта
        spr.fillRect(x, y, 14, 2, 0xffffff);
        spr.fillRect(c & 1 ? 318 : 0, c & 2 ? 226 : 0, 2, 14, 0xffffff);
      }
      txt("Фон чёрный, полосы — в подписанных цветах.", 10, 178, fS, C_TXT);
      txt("белый фон, цвета «негативом» → LCD_INVERT", 10, 194, fS, C_MUTED);
      txt("красный и синий наоборот → LCD_RGB_ORDER", 10, 208, fS, C_MUTED);
      snprintf(tag, sizeof(tag), "1/4 · нажмите");
      break;
    }
    case 2:
      spr.fillScreen(0x000000);
      txt("ГРАДАЦИИ СЕРОГО", 160, 16, fSB, 0xffffff, D_C);
      for (uint8_t i = 0; i < 16; i++) {
        uint8_t v = i * 17;                                   // 0, 17 … 255
        spr.fillRect(10 + (i % 8) * 37, i < 8 ? 24 : 88, 37, 60, ((rgb_t)v << 16) | ((rgb_t)v << 8) | v);
      }
      txt("Все 16 полос должны различаться. Тёмные сливаются", 10, 166, fS, C_TXT);
      txt("с серым, а не с чёрным — экран пересвечен", 10, 181, fS, C_TXT);
      txt("(подсветка). Сливаются светлые — мало яркости.", 10, 196, fS, C_TXT);
      snprintf(tag, sizeof(tag), "2/4 · нажмите");
      break;
    case 3:
      spr.fillScreen(0x000000);
      txt("Чёрное поле. Светлеют края или углы —", 160, 112, fS, 0x3a4148, D_C);
      txt("это свет подсветки: уменьшите «Подсветку»", 160, 128, fS, 0x3a4148, D_C);
      snprintf(tag, sizeof(tag), "3/4 · подсветка %u%%", cfg.bright);
      break;
    default:
      spr.fillScreen(0xffffff);
      txt("Белое поле: ровное, без пятен и полос", 160, 120, fS, C_MUTED, D_C);
      snprintf(tag, sizeof(tag), "4/4 · нажмите — в меню");
      break;
  }
  txt(tag, 312, 234, fS, screenTest == 4 ? 0x5d6762 : C_MUTED, D_R);
  addHit(B_TEST_NEXT, TAP, 0, 0, 320, 240);
}

// ---------------------------------------------------------------------
//  Кнопка BOOT: калибровка тача и сброс настроек
// ---------------------------------------------------------------------
static void drawBootOverlay() {
  spr.fillRoundRect(20, 70, 280, 100, 8, C_TILE);
  spr.drawRoundRect(20, 70, 280, 100, 8, bootHeldMs >= 10000 ? C_BAD : C_COLD);
  if (bootHeldMs >= 10000) {
    txt("Отпустите BOOT:", 160, 105, fH, C_BAD, D_C);
    txt("сброс ВСЕХ настроек", 160, 128, fT, C_WHITE, D_C);
    txt("к заводским и перезагрузка", 160, 146, fS, C_MUTED, D_C);
  } else {
    txt("Отпустите BOOT:", 160, 105, fH, C_COLD, D_C);
    txt("калибровка тача", 160, 128, fT, C_WHITE, D_C);
    String s = "держите ещё " + String((10000 - bootHeldMs) / 1000 + 1) + " с — сброс настроек";
    txt(s, 160, 146, fS, C_MUTED, D_C);
  }
}

static void touchCalibrate() {
  lcd.fillScreen(C_BG);
  lcd.setFont(&fT.vlw);
  lcd.setTextColor(C_WHITE, C_BG);
  lcd.setTextDatum(Datum::middle_center);
  lcd.drawString("Калибровка тача", 160, 100);
  lcd.setFont(&fS.vlw);
  lcd.setTextColor(C_MUTED, C_BG);
  lcd.drawString("нажимайте по очереди на стрелки в углах", 160, 124);
  lcd.drawString("(лучше стилусом или ногтем, точно в кончик)", 160, 140);
  delay(1500);
  uint16_t cal[8];
  // LovyanGFX сам рисует стрелки в 4 углах и ждёт нажатий.
  // Калибровка исправляет и поворот, и зеркало, и сдвиг тача.
  lcd.calibrateTouch(cal, C_WHITE, C_BG, 14);
  lcd.setTouchCalibrate(cal);
  touchCalSave(cal);
  Serial.print(F("[ui] калибровка тача:"));
  for (uint8_t i = 0; i < 8; i++) Serial.printf(" %u", cal[i]);
  Serial.println();
  dirty = true;
}

static void bootButton() {
  static uint32_t downAt = 0;
  static bool wasDown = false;
  bool down = digitalRead(PIN_BOOT) == LOW;
  uint32_t t = millis();
  if (down && !wasDown) downAt = t;
  if (down) {
    uint32_t held = t - downAt;
    if ((held >= 3000) != (bootHeldMs >= 3000) || (held / 1000 != bootHeldMs / 1000)) dirty = true;
    bootHeldMs = held;
  } else if (wasDown) {
    uint32_t held = bootHeldMs;
    bootHeldMs = 0;
    dirty = true;
    if (held >= 10000) {
      Serial.println(F("[ui] BOOT 10 с: сброс настроек"));
      spr.fillScreen(C_BG);
      txt("Сброс настроек…", 160, 125, fH, C_BAD, D_C);
      if (sprOk) spr.pushSprite(0, 0);
      settingsFactoryReset();
      delay(800);
      ESP.restart();
    } else if (held >= 3000) {
      touchCalibrate();
    }
  }
  wasDown = down;
}

// ---------------------------------------------------------------------
//  Окна Тфикс: фиксация, «стабильно — зафиксируйте», «из памяти», сброс.
//  Значения в окне живые: фиксируется температура на момент нажатия
//  «Зафиксировать», а не на момент открытия окна.
// ---------------------------------------------------------------------
static const BtnStyle S_GO = {0x1c4a32, C_OK, 0xffffff, 0xbdf5d6};

// Затемняет уже нарисованный кадр в 4 раза (прямо в буфере спрайта, без readPixel)
static void dimScreen() {
  if (spr.getColorDepth() != 16) return;
  uint16_t *p = (uint16_t *)spr.getBuffer();
  if (!p) return;
  for (int i = 0; i < 320 * 240; i++) {
    uint16_t v = __builtin_bswap16(p[i]);           // в буфере RGB565 с обратным порядком байт
    p[i] = __builtin_bswap16((v >> 2) & 0x39E7);
  }
}

// Крупное значение «78,42 °C» по центру окна
static void dlgValue(float v, int y) {
  if (isnan(v)) { txt("——", 160, y, fXL, C_GREY, D_C); return; }
  String s = fmtNum(v, 2);
  int vw = textW(s.c_str(), fXL);
  txt(s, 150, y, fXL, C_WHITE, D_C);
  txt("°C", 150 + vw / 2 + 4, y - 18, fT, C_MUTED);
}

static void drawDialog() {
  dimScreen();
  nHits = 0;                                       // окно модальное: кнопки под ним не нажимаются
  addHit(B_NONE, TAP, 0, 0, 320, 240);
  const int x = 14, y = 22, w = 292, h = 196, by = y + h - 44;
  tile(x, y, w, h, 0x151b21, 0x3a4652);
  const Probe &c = st.p[CH_COLUMN];
  FixErr err = fixCheck();
  float now = err ? NAN : c.t;
  switch (dlg) {
    case DLG_FIX: {
      txt("ЗАФИКСИРОВАТЬ ТФИКС", 160, y + 16, fSB, C_MUTED, D_C);
      txt("Сейчас на царге", 160, y + 36, fT, C_TXT, D_C);
      dlgValue(now, y + 80);
      int ly = y + 102;
      if (err) {
        txt("Нельзя зафиксировать:", 160, ly, fT, C_BAD, D_C); ly += 16;
        txt(fixErrText(err), 160, ly, fT, C_TXT, D_C); ly += 16;
        if (!isnan(st.fix)) txt("Старая Тфикс " + fmtNum(st.fix, 2) + " остаётся", 160, ly, fS, C_MUTED, D_C);
        button(x + 8, by, 134, 36, "Отмена", nullptr, B_DLG_CANCEL, TAP);
        button(x + w - 142, by, 134, 36, "Зафиксировать", "недоступно", B_DLG_OK, TAP, S_DIM);
        break;
      }
      txt("Новая Тфикс " + fmtNum(roundf(now * 100) / 100, 2), 160, ly, fT, C_OK, D_C); ly += 15;
      // старая Тфикс и разница с ней (после «Хвостов» видно, вернулась ли царга); старая заменится
      if (!isnan(st.fix)) { txt(fixDiffText(), 160, ly, fT, C_WARN, D_C); ly += 15; }
      if (st.mode == MODE_STAB) {
        txt("Стабилизация прервётся, отбор и пороги", 160, ly, fS, C_MUTED, D_C); ly += 12;
        txt("пойдут от новой Тфикс", 160, ly, fS, C_MUTED, D_C); ly += 12;
      } else {
        txt("«Хвосты» будут считаться от новой Тфикс", 160, ly, fS, C_MUTED, D_C);
        ly += 12;
      }
      // ручную фиксацию не запрещаем, но предупреждаем, если царга ещё гуляет
      if (st.spreadReady && st.spread > cfg.green + 1e-4f && st.mode != MODE_STAB) {
        String wn = "Ещё не устоялась: размах " + fmtNum(st.spread, 2) + " за " + String(cfg.stabWindow / 60) + " мин";
        txt(wn, 160, ly, fS, C_WARN, D_C);
      }
      button(x + 8, by, 134, 36, "Отмена", nullptr, B_DLG_CANCEL, TAP);
      button(x + w - 142, by, 134, 36, "Зафиксировать", nullptr, B_DLG_OK, TAP, S_GO);
      break;
    }
    case DLG_STABLE: {
      String hd = "СТАБИЛЬНО " + String(cfg.stabWindow / 60) + " МИН · ЗАФИКСИРУЙТЕ ТФИКС";
      txt(hd, 160, y + 16, fSB, C_MUTED, D_C);
      txt("Сейчас на царге", 160, y + 36, fT, C_TXT, D_C);
      dlgValue(now, y + 78);
      int ly = y + 100;
      if (err) {
        txt("Нельзя зафиксировать:", 160, ly, fT, C_BAD, D_C); ly += 16;
        txt(fixErrText(err), 160, ly, fT, C_TXT, D_C);
        button(x + 8, by, 134, 36, "Позже", nullptr, B_DLG_CANCEL, TAP);
        button(x + w - 142, by, 134, 36, "Зафиксировать", "недоступно", B_DLG_OK, TAP, S_DIM);
        break;
      }
      txt("Новая Тфикс " + fmtNum(roundf(now * 100) / 100, 2), 160, ly, fT, C_OK, D_C); ly += 15;
      // старая Тфикс и разница: видно, вернулась ли царга после «Хвостов» к прежней
      if (!isnan(st.fix)) { txt(fixDiffText(), 160, ly, fT, C_WARN, D_C); ly += 15; }
      txt("Отбор и пороги пойдут от новой Тфикс.", 160, ly, fS, C_MUTED, D_C); ly += 13;
      txt("«Позже» — напомню через минуту", 160, ly, fS, C_MUTED, D_C);
      button(x + 8, by, 134, 36, "Позже", nullptr, B_DLG_CANCEL, TAP);
      button(x + w - 142, by, 134, 36, "Зафиксировать", nullptr, B_DLG_OK, TAP, S_GO);
      break;
    }
    case DLG_RESTORE: {
      txt("ТФИКС ИЗ ПАМЯТИ", 160, y + 16, fSB, C_MUTED, D_C);
      // крестик: окно закрывается, плитка остаётся «ПОДТВЕРДИТЕ»
      {
        int cx = x + w - 17, cy = y + 15;
        spr.drawRoundRect(cx - 13, cy - 11, 26, 22, 4, pressId == B_DLG_X ? C_WHITE : C_BTN_BR);
        spr.drawLine(cx - 5, cy - 5, cx + 5, cy + 5, C_TXT);
        spr.drawLine(cx - 5, cy + 5, cx + 5, cy - 5, C_TXT);
        spr.drawLine(cx - 4, cy - 5, cx + 6, cy + 5, C_TXT);
        spr.drawLine(cx - 4, cy + 5, cx + 6, cy - 5, C_TXT);
      }
      addHit(B_DLG_X, TAP, x + w - 40, y, 40, 32);
      txt("До перезагрузки была зафиксирована", 160, y + 36, fT, C_TXT, D_C);
      dlgValue(st.fix, y + 78);
      String when = st.fixClock <= 1 ? "в " + fixTimeText() + ", " + fixSrcText(st.fixSrc) : String(fixSrcText(st.fixSrc));
      txt(when, 160, y + 93, fS, C_MUTED, D_C);
      String cur = "Сейчас " + fmtNum(c.t, 2) + " · Δ " + fmtSigned(c.t - st.fix, 2);
      if (err == FIX_ERR_STALE) cur = "Сейчас ——, нет свежих данных";
      else if (err) cur = "Сейчас ——, датчик: " + String(probeStateText(c));
      txt(cur, 160, y + 110, fT, C_TXT2, D_C);
      txt("Пока не подтвердите, «Хвосты» не отслеживаются", 160, y + 126, fS, C_WARN, D_C);
      button(x + 8, by, 84, 36, "Сбросить", nullptr, B_DLG_A, TAP);
      if (err) {
        button(x + 96, by, 84, 36, "Заново", "недоступно", B_DLG_B, TAP, S_DIM);
        button(x + 184, by, 100, 36, "Подтвердить", "недоступно", B_DLG_OK, TAP, S_DIM);
      } else {
        button(x + 96, by, 84, 36, "Заново", "от текущей", B_DLG_B, TAP);
        button(x + 184, by, 100, 36, "Подтвердить", nullptr, B_DLG_OK, TAP, S_GO);
      }
      break;
    }
    case DLG_CLEAR: {
      txt("СБРОСИТЬ ТФИКС", 160, y + 16, fSB, C_MUTED, D_C);
      txt("Сбросить Тфикс " + fmtNum(st.fix, 2) + "?", 160, y + 66, fH, C_WHITE, D_C);
      txt("Оценка «Хвостов» остановится,", 160, y + 94, fT, C_TXT, D_C);
      txt("плитка станет белой «БЕЗ ТФИКС»", 160, y + 110, fT, C_TXT, D_C);
      button(x + 8, by, 134, 36, "Отмена", nullptr, B_DLG_CANCEL, TAP);
      button(x + w - 142, by, 134, 36, "Сбросить", nullptr, B_DLG_OK, TAP, S_ALARM);
      break;
    }
  }
}

static void drawToast() {
  rgb_t bg = toastBad ? (rgb_t)0x3a1414 : (rgb_t)0x1c4a32, br = toastBad ? C_ALARM_BR : C_OK;
  int w = min(312, textW(toastMsg, fT) + 28);
  spr.fillRoundRect(160 - w / 2, 150, w, 30, 6, bg);
  spr.drawRoundRect(160 - w / 2, 150, w, 30, 6, br);
  txt(toastMsg, 160, 169, fT, 0xffffff, D_C);
}

// Что делает кнопка окна
static void dlgAction(uint8_t id) {
  uint8_t d = dlg;
  dlg = DLG_NONE;
  if (id == B_DLG_CANCEL || id == B_DLG_X) {
    if (d == DLG_STABLE) Serial.println(F("[ui] «Позже»: напомню через минуту"));
    return;
  }
  FixErr err = FIX_OK;
  if (d == DLG_FIX && id == B_DLG_OK)          err = cmdFix(SRC_SCREEN);
  else if (d == DLG_STABLE && id == B_DLG_OK)  err = cmdFix(SRC_STAB);
  else if (d == DLG_RESTORE && id == B_DLG_OK) err = cmdFixConfirm(SRC_SCREEN);
  else if (d == DLG_RESTORE && id == B_DLG_B)  err = cmdFix(SRC_SCREEN);
  else if (d == DLG_RESTORE && id == B_DLG_A)  err = cmdFixClear(SRC_SCREEN);
  else if (d == DLG_CLEAR && id == B_DLG_OK)   err = cmdFixClear(SRC_SCREEN);
  // приглушённая кнопка тоже ведёт сюда: отказ попадает в журнал и показывается
  if (err) {
    char msg[112];
    snprintf(msg, sizeof(msg), "Нельзя: %s", fixErrText(err));
    uiToast(msg, true);
  }
}

// «Зафиксировать» на экране и нажатие на плитку царги в состояниях, где ждём оператора
static void fixButton() {
  if (st.fixConfirm) openDlg(DLG_RESTORE);
  else if (st.ask) openDlg(DLG_STABLE);
  else openDlg(DLG_FIX);
}

// ---------------------------------------------------------------------
//  Обработка нажатий
// ---------------------------------------------------------------------
static void menuAction(uint8_t id, int touchX) {
  const MenuRow *rows; uint8_t n;
  menuPageRows(rows, n);
  uint8_t row = (id - B_ROW) / 4, part = (id - B_ROW) % 4;
  if (row >= n) return;
  const MenuRow &r = rows[row];
  if (r.kind == R_TIMER) { cmdResetTimer(); return; }
  if (r.kind == R_ACT) { if (part < 2) r.step(part ? 1 : -1); return; }
  if (r.kind == R_SLIDER && part == 2) {
    float p = constrain((touchX - SL_X) / (float)SL_W, 0.0f, 1.0f);
    int v = r.smin + (int)roundf(p * (r.smax - r.smin) / r.sstep) * r.sstep;
    if (v != r.sget()) { r.sset(v); settingsSave(); }
    return;
  }
  if (r.kind == R_STEP && r.step) { r.step(part ? 1 : -1); settingsSave(); }
}

static void action(uint8_t id, int x) {
  switch (id) {
    case B_SEL1: cmdChooseRun(RUN_1); break;
    case B_SEL2: cmdChooseRun(RUN_2); break;
    case B_BACK: cmdChooseRun(st.lastRun); break;
    case B_FIX: fixButton(); break;
    case B_RESET: cmdResetAlarm(); break;
    case B_MENU: menuOpen = true; menuPage = 0; break;
    case B_COOL: cmdConfirmCool(); break;
    case B_TCOL:
      if (st.fixConfirm || st.ask) fixButton();      // плитка «ПОДТВЕРДИТЕ» / «зафиксируйте» открывает окно
      else { chartOpen = true; chartKind = 0; }
      break;
    case B_TCUBE: chartOpen = true; chartKind = 1; break;
    case B_TUO: cmdUoTap(); break;                 // отметка отбора: головы / тело / закрыт
    case B_STEAM: cmdSteamAck(); break;            // «Пар в узле отбора» — понятно
    case B_TAB0: menuPage = 0; break;
    case B_TAB1: menuPage = 1; break;
    case B_TAB2: menuPage = 2; break;
    case B_TEST_NEXT: screenTest = screenTest >= 4 ? 0 : screenTest + 1; break;
    case B_MRUN: cmdToSelect(); break;
    case B_MDONE: menuOpen = false; break;
    case B_CHART_CLOSE: chartOpen = false; break;
    case B_DLG_CANCEL: case B_DLG_OK: case B_DLG_A: case B_DLG_B: case B_DLG_X: dlgAction(id); break;
    default: if (id >= B_ROW) menuAction(id, x); break;
  }
  dirty = true;
}

static void touchLoop() {
  static bool down = false;
  static int8_t hit = -1;
  static uint8_t hitId = 0;
  static HitKind hitKind = TAP;
  static bool fired = false;
  static uint32_t lastSeen = 0, lastRepeat = 0;
  static int lx = 0, ly = 0;
  static uint8_t pressView = 0;                   // какой экран был, когда палец коснулся

  int32_t x, y;
  bool touched = lcd.getTouch(&x, &y);
  uint32_t t = millis();

#if TOUCH_DEBUG
  if (touched) {
    lgfx::touch_point_t raw;
    lcd.getTouchRaw(&raw, 1);
    Serial.printf("[touch] экран x=%ld y=%ld   сырые x=%d y=%d\n", (long)x, (long)y, raw.x, raw.y);
    lcd.drawFastHLine(x - 12, y, 25, C_BAD);
    lcd.drawFastVLine(x, y - 12, 25, C_BAD);
  }
#endif

  // окно или меню сменилось под пальцем (открылось само) — это нажатие больше ничего не делает
  uint8_t view = dlg | (menuOpen ? 0x40 : 0) | (chartOpen ? 0x80 : 0);
  if (down && hitId && view != pressView) { hitId = 0; fired = true; pressId = 0; dirty = true; }

  if (touched) {
    lastSeen = t; lx = x; ly = y;
    if (!down) {
      down = true; fired = false;
      hit = hitAt(x, y);
      hitId = hit >= 0 ? hits[hit].id : 0;
      hitKind = hit >= 0 ? hits[hit].kind : TAP;
      pressAt = t; lastRepeat = t;
      pressId = hitId;
      pressView = view;
      if (hitId) buzzerClick();
      if (hitKind == SLIDE && hitId) action(hitId, x);
      dirty = true;
    } else if (hitId) {
      if (hitKind == HOLD && !fired) {
        if (t - pressAt >= 1000) { fired = true; pressId = 0; action(hitId, x); buzzerClick(); }
        dirty = true;                             // рисуем полоску удержания
      } else if (hitKind == REPEAT && t - pressAt >= 500 && t - lastRepeat >= 150) {
        lastRepeat = t; fired = true; action(hitId, x);     // автоповтор при удержании − / +
      } else if (hitKind == SLIDE) {
        action(hitId, x);
      }
    }
  } else if (down && t - lastSeen > 60) {        // отпустили (60 мс — от дребезга тача)
    down = false;
    uint8_t id = hitId;
    pressId = 0;
    dirty = true;
    if (!id) return;
    int now = hitAt(lx, ly);
    bool inside = now >= 0 && hits[now].id == id;
    if ((hitKind == TAP || hitKind == REPEAT) && !fired && inside) action(id, lx);
  }
}

// ---------------------------------------------------------------------
//  Начало и цикл
// ---------------------------------------------------------------------
static void applyBrightness() {
  bool alarm = st.run == RUN_2 && (st.mode == MODE_TAILS || (st.faultMask & ~st.faultAck));
  uint8_t b = alarm ? 255 : (uint8_t)(cfg.bright * 255 / 100);
  if (b != appliedBright) { lcd.setBrightness(b); appliedBright = b; }
}

// Окна, которые открываются сами: Тфикс из памяти ждёт подтверждения,
// стабилизация просит зафиксировать. Открываются один раз на событие;
// закрытое крестиком или «Позже» снова открывается нажатием на плитку.
static void dialogEdges() {
  static bool confirmSeen = false, askSeen = false;
  if (st.run != RUN_2) { confirmSeen = askSeen = wantRestore = wantStable = false; dlg = DLG_NONE; return; }
  if (st.fixConfirm && !confirmSeen) wantRestore = true;
  if (st.ask && !askSeen) wantStable = true;
  confirmSeen = st.fixConfirm;
  askSeen = st.ask;
  if (!st.fixConfirm) wantRestore = false;
  if (!st.ask) wantStable = false;
  // пока горит «Включите охлаждение» или «Хвосты», окно не перекрывает тревогу
  bool alarm = st.cool == COOL_ALERT || st.mode == MODE_TAILS;
  if (!alarm && !dlg && !menuOpen && !chartOpen) {
    if (wantRestore) { openDlg(DLG_RESTORE); wantRestore = false; }
    else if (wantStable && !st.fixConfirm) { openDlg(DLG_STABLE); wantStable = false; }
  }
  // то, о чём спрашивало окно, уже решено (например, из браузера) — закрываем
  if (dlg == DLG_RESTORE && !st.fixConfirm) dlg = DLG_NONE;
  if (dlg == DLG_STABLE && !st.ask) dlg = DLG_NONE;
  if (dlg == DLG_CLEAR && isnan(st.fix)) dlg = DLG_NONE;
}

static void render() {
  nHits = 0;
  dialogEdges();
  spr.fillScreen(C_BG);
  if (screenTest && menuOpen && st.run != RUN_NONE) drawScreenTest();
  else if (menuOpen && st.run != RUN_NONE) drawMenu();
  else if (chartOpen && st.run == RUN_2) drawBigChart();
  else if (st.run == RUN_NONE) drawSelect();
  else if (st.run == RUN_1) drawRun1();
  else drawRun2();
  if (dlg && st.run == RUN_2 && !menuOpen && !chartOpen) drawDialog();
  else if (millis() < toastUntil && !screenTest) drawToast();
  if (bootHeldMs >= 3000) drawBootOverlay();
  spr.pushSprite(0, 0);
}

void uiBegin() {
  pinMode(PIN_BOOT, INPUT_PULLUP);
  lcd.init();
  // экран должен быть горизонтальным (320×240); если LCD_OFFSET_ROTATION
  // поставили 0 или 2 — поворачиваем сами и пишем предупреждение
  if (lcd.width() < lcd.height()) {
    Serial.println(F("[ui] экран вертикальный: LCD_OFFSET_ROTATION должен быть 1 или 3 (5 или 7 с зеркалом)"));
    lcd.setRotation(lcd.getRotation() ^ 1);
  }
  Serial.printf("[ui] экран %ld×%ld\n", (long)lcd.width(), (long)lcd.height());
  lcd.setBrightness(255);
  appliedBright = 255;

  fontLoad(fXL, font_xl, sizeof(font_xl));
  fontLoad(fL, font_l, sizeof(font_l));
  fontLoad(fM, font_m, sizeof(font_m));
  fontLoad(fV, font_v, sizeof(font_v));
  fontLoad(fH, font_h, sizeof(font_h));
  fontLoad(fT, font_t, sizeof(font_t));
  fontLoad(fSB, font_sb, sizeof(font_sb));
  fontLoad(fS, font_s, sizeof(font_s));

  // Кадр 320×240×16 бит = 150 КБ, кладём в PSRAM.
  // Если PSRAM не включён в Arduino IDE (Tools -> PSRAM: OPI PSRAM),
  // пробуем 8 бит в обычной памяти — цвета будут грубее.
  spr.setPsram(true);
  spr.setColorDepth(16);
  sprOk = spr.createSprite(320, 240);
  if (!sprOk) {
    Serial.println(F("[ui] нет PSRAM для кадра, перехожу на 8 бит"));
    spr.setPsram(false);
    spr.setColorDepth(8);
    sprOk = spr.createSprite(320, 240);
  }
  if (!sprOk) Serial.println(F("[ui] ОШИБКА: не хватает памяти для кадра"));

  uint16_t cal[8];
  if (touchCalLoad(cal)) {
    lcd.setTouchCalibrate(cal);
    Serial.println(F("[ui] калибровка тача загружена из памяти"));
  }

  // заставка, пока запускаются датчики
  if (sprOk) {
    spr.fillScreen(C_BG);
    txt("Колонна", 160, 110, fH, C_WHITE, D_C);
    txt("проверка датчиков…", 160, 132, fS, C_MUTED, D_C);
    spr.pushSprite(0, 0);
  }
}

void uiLoop() {
  static uint32_t lastDraw = 0, lastTouch = 0;
  uint32_t t = millis();
  if (t - lastTouch >= 15) { lastTouch = t; touchLoop(); }
  bootButton();
  if (touchCalPending) { touchCalPending = false; touchCalibrate(); }
  applyBrightness();
  if (!sprOk) return;
  // перерисовка: сразу после изменений (но не чаще 25 раз в секунду)
  // и 4 раза в секунду для часов, мигания тревоги и полосок
  if ((dirty && t - lastDraw >= 40) || t - lastDraw >= 250) {
    dirty = false;
    lastDraw = t;
    render();
  }
}
