// util.cpp — форматирование чисел и времени (запятая, как в документе)
//            и пересчёт сопротивления PT100/PT1000 в температуру
#include "app.h"
#include <time.h>

String fmtNum(float v, uint8_t dec) {
  if (isnan(v)) return "——";
  char buf[16];
  snprintf(buf, sizeof(buf), "%.*f", dec, (double)v);
  // без «-0,00»: проверяем до замены точки на запятую (atof не понимает запятую,
  // иначе -0,42 тоже теряло бы минус — исправлено 23.10.2026)
  bool negZero = buf[0] == '-' && atof(buf + 1) == 0;
  for (char *c = buf; *c; c++) if (*c == '.') *c = ',';
  if (negZero) return String(buf + 1);
  return String(buf);
}

String fmtSigned(float v, uint8_t dec) {
  if (isnan(v)) return "——";
  float lim = 0.5f * powf(10.0f, -dec);
  String s = fmtNum(fabsf(v), dec);
  return (v > -lim ? "+" : "−") + s;     // «−» — настоящий минус, он есть в шрифте
}

String fmtHMS(uint32_t s) {
  char buf[16];
  snprintf(buf, sizeof(buf), "%lu:%02lu:%02lu", (unsigned long)(s / 3600), (unsigned long)(s / 60 % 60), (unsigned long)(s % 60));
  return String(buf);
}

String fmtMS(uint32_t s) {
  char buf[12];
  snprintf(buf, sizeof(buf), "%lu:%02lu", (unsigned long)(s / 60), (unsigned long)(s % 60));
  return String(buf);
}

String fmtClock(int32_t unixTime) {
  if (unixTime < 1700000000) return "--:--";
  time_t t = unixTime;
  struct tm tm;
  localtime_r(&t, &tm);
  char buf[12];
  snprintf(buf, sizeof(buf), "%02d:%02d", tm.tm_hour, tm.tm_min);
  return String(buf);
}

// Сопротивление -> температура (Каллендар–Ван Дюзен), как в документе.
float rtdToC(float r, float r0) {
  const float A = 3.9083e-3f, B = -5.775e-7f;
  float z1 = -A, z2 = A * A - 4 * B, z3 = (4 * B) / r0, z4 = 2 * B;
  float d = z2 + z3 * r;
  if (d >= 0) {
    float t = (z1 + sqrtf(d)) / z4;
    if (t >= 0) return t;
  }
  // ниже 0 °C — полиномиальное приближение
  float rpoly = r / r0 * 100.0f, t = -242.02f;
  t += 2.2228f * rpoly;  rpoly *= r / r0 * 100.0f;
  t += 2.5859e-3f * rpoly; rpoly *= r / r0 * 100.0f;
  t -= 4.8260e-6f * rpoly; rpoly *= r / r0 * 100.0f;
  t -= 2.8183e-8f * rpoly; rpoly *= r / r0 * 100.0f;
  t += 1.5243e-10f * rpoly;
  return t;
}

// Температура -> сопротивление (выше 0 °C; для калибровки и симуляции)
float rtdOhm(float t, float r0) {
  const float A = 3.9083e-3f, B = -5.775e-7f;
  return r0 * (1 + A * t + B * t * t);
}
