// web.cpp — веб-интерфейс: http://kolonna.local (или IP со строки состояния экрана)
//
//  Страницы:   /          — монитор: температуры, графики, сброс тревоги (без пароля)
//              /settings  — настройки (логин admin, пароль веб-настроек)
//  API (JSON): /api/state, /api/history?m=30|120|0, /api/cmd?c=...,
//              /api/csv[?n=18] — CSV текущего (или N-го) перегона, без пароля,
//              /api/logs — прошлые перегоны на flash (номер, дата, длительность, размер),
//              /api/logdel?n=18 (POST, с паролем) — удалить перегон,
//              /api/events — журнал Тфикс (последние 20 событий, новые сверху),
//              /api/settings (GET/POST, с паролем), /api/scan (с паролем), /update,
//              /api/cal (GET/POST, с паролем) — калибровка датчиков по льду (по одному или все три сразу),
//              /api/calib (GET — скачать файл калибровки, POST — проверить/записать, с паролем)
//
//  В документе для живых данных указан WebSocket. Здесь страница просто
//  спрашивает /api/state раз в секунду: результат для глаза тот же, а
//  прошивке не нужна дополнительная библиотека.
//  Страницы лежат внутри прошивки (web_page.h), а не в LittleFS, чтобы
//  не нужно было отдельно заливать файловую систему.
#include "app.h"
#include <WebServer.h>
#include <WiFi.h>
#include <Update.h>
#include <LittleFS.h>
#include "web_page.h"

static WebServer server(80);
static const char *ADMIN_USER = "admin";

// Пишет JSON кусками прямо в ответ (без огромной строки в памяти)
class ChunkOut : public Print {
public:
  size_t write(uint8_t c) override { buf[n++] = c; if (n == sizeof(buf)) flush(); return 1; }
  size_t write(const uint8_t *b, size_t len) override { for (size_t i = 0; i < len; i++) write(b[i]); return len; }
  void flush() { if (n) { server.sendContent(buf, n); n = 0; } }
private:
  char buf[1024];
  size_t n = 0;
};

static bool auth() {
  if (server.authenticate(ADMIN_USER, cfg.webPass)) return true;
  server.requestAuthentication(BASIC_AUTH, "Kolonna", "Нужен пароль настроек");
  return false;
}

static const char *toneName(Tone t) {
  static const char *names[] = {"cold", "ok", "warn", "hot", "bad", "white", "stab", "grey"};
  return names[t];
}

static void jnum(String &s, float v, uint8_t dec = 2) {
  if (isnan(v)) s += "null"; else s += String(v, (unsigned int)dec);
}

static void jstr(String &s, const char *v) {
  s += '"';
  for (const char *c = v; *c; c++) {
    if (*c == '"' || *c == '\\') s += '\\';
    if ((uint8_t)*c >= 0x20) s += *c;
  }
  s += '"';
}

// unix-время по часам контроллера в строку strftime (пусто — часов нет или времени нет)
static String dateText(uint32_t unixTime, const char *fmt) {
  if (unixTime < 1700000000) return String("");
  time_t t = unixTime; struct tm tm; localtime_r(&t, &tm);
  char b[32]; strftime(b, sizeof(b), fmt, &tm);
  return String(b);
}

// ---------------------------------------------------------------------
//  /api/state — всё, что нужно монитору, раз в секунду
// ---------------------------------------------------------------------
static void handleState() {
  String s;
  s.reserve(1600);
  s += "{\"run\":"; s += st.run;
  s += ",\"last\":"; s += st.lastRun;
  Run saved; uint32_t savedEl = 0;
  if (st.run == RUN_NONE && hasSavedRun(saved, savedEl)) { s += ",\"saved\":"; s += saved; s += ",\"savedEl\":"; s += savedEl; }
  static const char *modes[] = {"draw", "tails", "stab"};
  s += ",\"mode\":\""; s += modes[st.mode]; s += '"';
  s += ",\"fix\":"; jnum(s, st.fix);
  s += ",\"green\":"; jnum(s, cfg.green); s += ",\"red\":"; jnum(s, cfg.red);
  s += ",\"win\":"; s += cfg.stabWindow;
  s += ",\"stable\":"; s += st.stableFor;
  s += ",\"spread\":"; jnum(s, st.spread); s += ",\"spreadReady\":"; s += st.spreadReady ? "true" : "false";
  s += ",\"newFix\":"; s += (st.now < st.newUntil) ? "true" : "false";
  s += ",\"cool\":"; s += st.cool;
  s += ",\"faults\":"; s += st.faultMask & ~st.faultAck;
  s += ",\"buzzer\":"; s += cfg.buzzer ? "true" : "false";
  s += ",\"relay\":"; s += relayOn() ? "true" : "false";     // реле клапана отбора
  s += ",\"tails\":"; s += (st.run == RUN_2 && st.mode == MODE_TAILS) ? "true" : "false";
  // Тфикс: состояние словами — те же, что на экране
  static const char *fsKeys[] = {"none", "active", "nodata", "confirm"};
  FixState fs = fixState();
  s += ",\"fixState\":\""; s += fsKeys[fs]; s += '"';
  s += ",\"fixStateText\":"; jstr(s, fixStateText(fs));
  s += ",\"fixAt\":"; jstr(s, isnan(st.fix) ? "" : fixTimeText().c_str());
  s += ",\"fixSrc\":"; jstr(s, isnan(st.fix) ? "" : fixSrcText(st.fixSrc));
  s += ",\"ask\":"; s += st.ask ? "true" : "false";
  s += ",\"stale\":"; s += st.stale ? "true" : "false";
  s += ",\"valid\":"; s += columnValid() ? "true" : "false";
  FixErr fe = fixCheck();
  s += ",\"fixErr\":"; jstr(s, fixErrText(fe));
  s += ",\"wasNow\":"; jstr(s, fixDiffText().c_str());        // «было 75,30, сейчас 75,31 (+0,01)»
  // плитка УО: отметка отбора (0 нет, 1 головы, 2 тело, 3 закрыт) и её подпись, как на экране
  s += ",\"uo\":"; s += st.uo;
  s += ",\"uoText\":"; jstr(s, uoLabel().c_str());
  s += ",\"steam\":"; s += steamAlert() ? "true" : "false";    // надпись «Пар в узле отбора…»
  // датчики в порядке каналов: [куб, царга, датчик 3]
  s += ",\"p\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    const Probe &p = st.p[i];
    if (i) s += ',';
    s += "{\"t\":"; jnum(s, p.state == PROBE_OK ? p.t : NAN);
    s += ",\"on\":"; s += cfg.ch[i].enabled ? "true" : "false";
    s += ",\"ok\":"; s += p.state == PROBE_OK ? "true" : "false";
    s += ",\"txt\":"; jstr(s, probeStateText(p));
    s += '}';
  }
  s += ']';
  float kt = st.p[CH_CUBE].state == PROBE_OK ? st.p[CH_CUBE].t : NAN;
  float ct = st.p[CH_COLUMN].state == PROBE_OK ? st.p[CH_COLUMN].t : NAN;
  char zb[32];
  s += ",\"tone\":{\"k\":\""; s += toneName(cubeTone(kt));
  s += "\",\"c\":\""; s += toneName(st.run == RUN_1 ? col1Tone(ct) : columnTone()); s += "\"}";
  s += ",\"zone\":"; jstr(s, cubeZoneText(kt, zb, sizeof(zb)));
  const float *z = st.run == RUN_1 ? cfg.z1 : cfg.z2;
  s += ",\"z\":["; for (uint8_t i = 0; i < 4; i++) { if (i) s += ','; jnum(s, z[i], 1); } s += ']';
  s += ",\"col1\":"; jnum(s, cfg.col1, 1);
  uint32_t el = st.now - st.runStart;
  s += ",\"elapsed\":"; s += el;
  s += ",\"timeOk\":"; s += timeValid() ? "true" : "false";
  s += ",\"start\":\""; s += timeValid() ? fmtClock(time(nullptr) - el) : String(""); s += '"';
  s += ",\"clock\":\""; s += timeValid() ? fmtClock(time(nullptr)) : String("--:--"); s += '"';
  s += ",\"net\":\""; s += netState() == NET_ONLINE ? "online" : netState() == NET_AP ? "ap" : "connecting"; s += '"';
  s += ",\"ip\":\""; s += netAddress(); s += '"';
  s += '}';
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

// ---------------------------------------------------------------------
//  /api/cmd?c=run1|run2|select|back|reset|cool|steamok|relayon|relayoff|time&t=unix
//           |fix|fixok — Тфикс: зафиксировать, подтвердить. Сбросить Тфикс
//  можно только с экрана (меню «Царга» или окно «Тфикс из памяти»), по ТЗ.
//  Браузер температуру не передаёт: контроллер берёт своё измерение на момент
//  команды. Ответ на команды Тфикс: {"ok":true,"fix":78.42} или
//  {"ok":false,"err":"stale","msg":"Нет свежих данных","fix":78.40}.
//  Пароля на кнопках главной страницы нет (решение по ТЗ от 13.10.2026).
// ---------------------------------------------------------------------
static void fixReply(FixErr e) {
  static const char *keys[] = {"", "run", "sensor", "stale", "nofix", "notpending"};
  String s = "{\"ok\":";
  s += e == FIX_OK ? "true" : "false";
  if (e != FIX_OK) { s += ",\"err\":\""; s += keys[e]; s += "\",\"msg\":"; jstr(s, fixErrText(e)); }
  s += ",\"fix\":"; jnum(s, st.fix);
  s += ",\"fixState\":"; jstr(s, fixStateText(fixState()));
  s += '}';
  server.send(e == FIX_OK ? 200 : 409, "application/json", s);
}

static void handleCmd() {
  String c = server.arg("c");
  if (c == "fix")      { fixReply(cmdFix(SRC_WEB)); return; }
  if (c == "fixok")    { fixReply(cmdFixConfirm(SRC_WEB)); return; }
  if (c == "fixclear") {                     // по ТЗ сброс только с экрана
    server.send(403, "application/json", "{\"ok\":false,\"err\":\"screen\",\"msg\":\"Сбросить Тфикс можно только с экрана\"}");
    return;
  }
  if (c == "run1") cmdChooseRun(RUN_1);
  else if (c == "run2") cmdChooseRun(RUN_2);
  else if (c == "back") cmdChooseRun(st.lastRun);
  else if (c == "select") cmdToSelect();
  else if (c == "reset") cmdResetAlarm(SRC_WEB);
  else if (c == "cool") cmdConfirmCool(SRC_WEB);
  else if (c == "steamok") cmdSteamAck(SRC_WEB);
  else if (c == "relayon") relaySet(true, SRC_WEB);      // реле клапана, вручную
  else if (c == "relayoff") relaySet(false, SRC_WEB);
  else if (c == "time") timeFromBrowser(strtoul(server.arg("t").c_str(), nullptr, 10));
  else { server.send(400, "application/json", "{\"ok\":false}"); return; }
  server.send(200, "application/json", "{\"ok\":true}");
}

static void handleEvents() {
  server.sendHeader("Cache-Control", "no-store");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "application/json", "");
  ChunkOut out;
  eventsJson(out);
  out.flush();
  server.sendContent("");
}

static void handleHistory() {
  uint32_t m = server.hasArg("m") ? server.arg("m").toInt() : 30;
  if (m != 30 && m != 120 && m != 0) m = 30;
  server.sendHeader("Cache-Control", "no-store");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "application/json", "");
  ChunkOut out;
  historyJson(m, out);
  out.flush();
  server.sendContent("");    // конец ответа
}

// /api/csv — файл текущего перегона, /api/csv?n=18 — любого из хранящихся.
// Имя с датой начала: kolonna-18_2026-10-14_12-37.csv (без даты — kolonna-18.csv)
static void handleCsv() {
  uint32_t n = 0;
  if (server.hasArg("n")) {
    String a = server.arg("n");
    bool digits = a.length() > 0 && a.length() <= 9;
    for (unsigned i = 0; i < a.length(); i++) if (a[i] < '0' || a[i] > '9') digits = false;
    if (digits) n = strtoul(a.c_str(), nullptr, 10);
    if (!n) { server.send(400, "text/plain; charset=utf-8", "Неверный номер перегона"); return; }
  }
  String path, name;
  if (!historyLogFile(n, path, name)) {
    char msg[160];
    if (n) snprintf(msg, sizeof(msg), "Этого перегона уже нет: на контроллере хранятся последние %u", (unsigned)KEEP_LOGS);
    else if (st.run == RUN_1 && !LOG_RUN1) snprintf(msg, sizeof(msg), "Первый перегон в лог не пишется");
    else snprintf(msg, sizeof(msg), "Лога пока нет: выберите перегон");
    server.send(404, "text/plain; charset=utf-8", msg);
    return;
  }
  File f = LittleFS.open(path, "r");
  server.sendHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
  server.streamFile(f, "text/csv; charset=utf-8");
  f.close();
}

static void handleLogs() {
  server.sendHeader("Cache-Control", "no-store");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "application/json", "");
  ChunkOut out;
  logsJson(out);
  out.flush();
  server.sendContent("");
}

// Удалить перегон (Настройки, под паролем). Текущий и последний не удаляются:
// последний «Продолжить» после перезагрузки допишет.
static void handleLogDel() {
  if (!auth()) return;
  static const char *msgs[] = {"", "Этого перегона уже нет", "Текущий перегон удалить нельзя",
                               "Последний перегон удалить нельзя: его можно продолжить после перезагрузки"};
  LogDel r = historyLogDelete(strtoul(server.arg("n").c_str(), nullptr, 10));
  String s = "{\"ok\":";
  s += r == LOGDEL_OK ? "true" : "false";
  if (r != LOGDEL_OK) { s += ",\"msg\":"; jstr(s, msgs[r]); }
  s += '}';
  server.send(r == LOGDEL_OK ? 200 : r == LOGDEL_NONE ? 404 : 409, "application/json", s);
}

// ---------------------------------------------------------------------
//  Настройки
// ---------------------------------------------------------------------
static void handleSettingsGet() {
  if (!auth()) return;
  String s;
  s.reserve(1500);
  s += "{\"ch\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    const ChannelCfg &c = cfg.ch[i];
    const Probe &p = st.p[i];
    if (i) s += ',';
    s += "{\"on\":"; s += c.enabled ? "true" : "false";
    s += ",\"pt1000\":"; s += c.pt1000 ? "true" : "false";
    s += ",\"rref\":"; jnum(s, c.rref, 2);   // 2 знака: калиброванный Rref не должен округляться в форме
    s += ",\"wires\":"; s += c.wires;
    s += ",\"off\":"; jnum(s, c.offset, 2);
    s += ",\"cal\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str());   // дата калибровки по льду («» — неизвестна)
    s += ",\"t\":"; jnum(s, p.state == PROBE_OK ? p.t : NAN);
    s += ",\"ohm\":"; jnum(s, p.ohm, 2);
    s += ",\"fault\":"; s += p.fault;
    s += ",\"txt\":"; jstr(s, probeStateText(p));
    s += '}';
  }
  s += "],\"win\":"; s += cfg.stabWindow / 60;
  s += ",\"green\":"; jnum(s, cfg.green); s += ",\"red\":"; jnum(s, cfg.red);
  s += ",\"delay\":"; s += cfg.alarmDelay;
  s += ",\"buzzer\":"; s += cfg.buzzer ? "true" : "false";
  s += ",\"z2\":["; for (uint8_t i = 0; i < 4; i++) { if (i) s += ','; jnum(s, cfg.z2[i], 1); } s += ']';
  s += ",\"z1\":["; for (uint8_t i = 0; i < 4; i++) { if (i) s += ','; jnum(s, cfg.z1[i], 1); } s += ']';
  s += ",\"col1\":"; jnum(s, cfg.col1, 1);
  s += ",\"chart\":"; s += cfg.chartMin;
  s += ",\"bright\":"; s += cfg.bright;
  s += ",\"steam\":"; jnum(s, cfg.steamC, 0);
  // пароли никогда не отдаём, только «задан / не задан»
  s += ",\"ssid\":["; jstr(s, cfg.ssid[0]); s += ','; jstr(s, cfg.ssid[1]); s += ']';
  s += ",\"passSet\":["; s += cfg.pass[0][0] ? "true" : "false"; s += ','; s += cfg.pass[1][0] ? "true" : "false"; s += ']';
  s += ",\"net\":\""; s += netState() == NET_ONLINE ? WiFi.SSID() : String(netState() == NET_AP ? "точка доступа" : "подключение"); s += '"';
  s += ",\"ip\":\""; s += netAddress(); s += '"';
  s += '}';
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

static bool argF(const char *name, float &out) {
  if (!server.hasArg(name)) return false;
  String v = server.arg(name);
  v.replace(',', '.');
  v.trim();
  if (v.isEmpty()) return false;
  out = v.toFloat();
  return true;
}

static void handleSettingsPost() {
  if (!auth()) return;
  bool sensorsChanged = false, wifiChanged = false;
  float f;
  for (uint8_t i = 0; i < NCH; i++) {
    ChannelCfg &c = cfg.ch[i];
    ChannelCfg before = c;
    String p = "c" + String(i);
    if (server.hasArg(p + "on")) c.enabled = server.arg(p + "on") == "1";
    if (server.hasArg(p + "type")) c.pt1000 = server.arg(p + "type") == "1000";
    if (argF((p + "rref").c_str(), f) && fabsf(f - c.rref) >= 0.005f) c.rref = f;   // то же число из формы — не изменение
    if (server.hasArg(p + "wires")) c.wires = server.arg(p + "wires").toInt();
    if (argF((p + "off").c_str(), f)) c.offset = f;
    if (memcmp(&before, &c, sizeof(c)) != 0) sensorsChanged = true;
  }
  if (argF("win", f)) cfg.stabWindow = (uint16_t)(f * 60);
  if (argF("green", f)) cfg.green = f;
  if (argF("red", f)) cfg.red = f;
  if (argF("delay", f)) cfg.alarmDelay = (uint8_t)f;
  if (server.hasArg("buzzer")) cfg.buzzer = server.arg("buzzer") == "1";
  for (uint8_t i = 0; i < 4; i++) {
    if (argF(("z2_" + String(i)).c_str(), f)) cfg.z2[i] = f;
    if (argF(("z1_" + String(i)).c_str(), f)) cfg.z1[i] = f;
  }
  // зоны должны идти по возрастанию
  for (uint8_t i = 1; i < 4; i++) {
    if (cfg.z2[i] <= cfg.z2[i - 1]) cfg.z2[i] = cfg.z2[i - 1] + 0.1f;
    if (cfg.z1[i] <= cfg.z1[i - 1]) cfg.z1[i] = cfg.z1[i - 1] + 0.5f;
  }
  if (argF("col1", f)) cfg.col1 = f;
  if (argF("chart", f)) cfg.chartMin = (uint8_t)f;
  if (argF("steam", f)) cfg.steamC = f;
  if (argF("bright", f)) cfg.bright = (uint8_t)f;
  for (uint8_t i = 0; i < 2; i++) {
    String k = "ssid" + String(i), kp = "pass" + String(i);
    if (server.hasArg(k) && server.arg(k) != cfg.ssid[i]) {
      strlcpy(cfg.ssid[i], server.arg(k).c_str(), sizeof(cfg.ssid[i]));
      wifiChanged = true;
    }
    // пустое поле пароля = «не менять»; «-» = стереть пароль (открытая сеть)
    if (server.hasArg(kp) && server.arg(kp).length()) {
      String v = server.arg(kp);
      strlcpy(cfg.pass[i], v == "-" ? "" : v.c_str(), sizeof(cfg.pass[i]));
      wifiChanged = true;
    }
  }
  bool webPassChanged = false;
  if (server.hasArg("webpass") && server.arg("webpass").length() >= 3) {
    strlcpy(cfg.webPass, server.arg("webpass").c_str(), sizeof(cfg.webPass));
    webPassChanged = true;
  }
  settingsSaveNow();          // проверяет диапазоны и пишет в NVS
  if (sensorsChanged) sensorsReconfigure();
  uiMarkDirty();
  server.send(200, "application/json", webPassChanged ? "{\"ok\":true,\"relogin\":true}" : "{\"ok\":true}");
  if (wifiChanged) { delay(300); netReconnect(); }
}

// ---------------------------------------------------------------------
//  Калибровка по льду: /api/cal
//    GET                    — состояние трёх каналов (для полоски и результата)
//    POST c=0..2&a=start    — начать: CAL_SECONDS секунд копить сопротивление
//    POST c=..&a=save       — записать новый Rref, поправку обнулить
//    POST c=..&a=cancel     — забыть результат
//    POST c=..&a=reset      — Rref к номиналу из config.h (430 / 4300), поправку обнулить
//    POST c=all&a=start     — все три сразу (как кнопка «Калибровка нуля» тестовой прошивки):
//                             начать замер у всех включённых датчиков с модулем
//    POST c=all&a=save      — записать новый Rref у всех годных, у негодных остаётся их ошибка
//    POST c=all&a=cancel    — забыть результаты всех трёх
//  Новый Rref = Rref × R0 / R_льда: при нём сопротивление во льду считается
//  ровно R0 (100 или 1000 Ом), то есть 0,00 °C. Разброс резистора на модуле
//  (1 % = до 2,6 °C) так убирается целиком. Rref хранится с точностью 0,01 Ом
//  (это меньше 0,003 °C), чтобы форма настроек отдавала его обратно без округления.
//  Тексты ошибок — целые фразы; страница добавляет к ним показание и «Rref не изменён».
// ---------------------------------------------------------------------
static float rrefNominal(uint8_t i) { return cfg.ch[i].pt1000 ? SENSOR_RREF_PT1000 : SENSOR_RREF_PT100; }

struct CalResult { CalInfo info; float tIce, newRref; const char *err; };

static CalResult calResult(uint8_t i) {
  CalResult r = {sensorsCalInfo(i), NAN, NAN, ""};
  if (r.info.state != CAL_DONE) return r;
  float r0 = cfg.ch[i].pt1000 ? 1000.0f : 100.0f;
  const CalInfo &k = r.info;
  if (k.n < 5 && k.wild > k.bad) {
    r.err = "Датчик показывает вне −50…250 °C: проверьте тип датчика и Rref";
    return r;
  }
  if (k.n < 5 || isnan(k.ohm) || k.bad * 4 > k.n) {
    r.err = "Датчик не отвечал или показывал обрыв: проверьте провода и повторите";
    return r;
  }
  r.tIce = rtdToC(k.ohm, r0);                      // без поправки: её калибровка обнуляет
  if (fabsf(r.tIce) > CAL_MAX_DEV_C) {
    r.err = "Это далеко от 0 °C: датчик не во льду, или в поле Rref не тот резистор, что на модуле";
    return r;
  }
  if (rtdToC(k.ohmMax, r0) - rtdToC(k.ohmMin, r0) > CAL_MAX_SPREAD_C) {
    r.err = "Показания плыли: датчик ещё не остыл во льду или его трогали. Подождите минуту и повторите";
    return r;
  }
  r.newRref = roundf(cfg.ch[i].rref * r0 / k.ohm * 100.0f) / 100.0f;   // до 0,01 Ом
  return r;
}

static void sendCal(int code = 200, const char *err = nullptr) {
  String s;
  s.reserve(700);
  s += "{\"ok\":"; s += err ? "false" : "true";
  if (err) { s += ",\"err\":"; jstr(s, err); }
  s += ",\"secs\":"; s += CAL_SECONDS;
  s += ",\"ch\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    CalResult r = calResult(i);
    if (i) s += ',';
    s += "{\"st\":"; s += r.info.state;
    s += ",\"left\":"; s += r.info.leftMs;
    s += ",\"ohm\":"; jnum(s, r.info.ohm, 2);
    s += ",\"t\":"; jnum(s, r.tIce, 2);
    s += ",\"off\":"; jnum(s, cfg.ch[i].offset, 2);
    s += ",\"rref\":"; jnum(s, cfg.ch[i].rref, 2);
    s += ",\"nrref\":"; jnum(s, r.newRref, 2);
    s += ",\"nom\":"; jnum(s, rrefNominal(i), 0);
    s += ",\"err\":"; jstr(s, r.err);
    s += '}';
  }
  s += "]}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(code, "application/json", s);
}

// Записать результат калибровки датчика i (без settingsSaveNow). false — записывать нечего.
static bool calSaveCh(uint8_t i) {
  CalResult r = calResult(i);
  if (r.info.state != CAL_DONE || r.err[0] || isnan(r.newRref)) return false;
  Serial.printf("[cal] датчик %u: Rref %.2f -> %.2f Ом (во льду было %.2f °C без поправки)\n", i + 1, cfg.ch[i].rref, r.newRref, r.tIce);
  cfg.ch[i].rref = r.newRref;
  cfg.ch[i].offset = 0;
  calDateSet(i, timeValid() ? (uint32_t)time(nullptr) : 0);
  sensorsCalClear(i);
  return true;
}

// c=all: все три датчика одной кнопкой
static void handleCalAll(const String &a) {
  uint8_t n = 0;
  if (a == "start") {
    for (uint8_t i = 0; i < NCH; i++) { sensorsCalClear(i); n += sensorsCalStart(i); }
    Serial.printf("[cal] калибровка по льду всех трёх: датчиков в замере %u\n", n);
    if (!n) { sendCal(409, "ни один датчик не включён или модули не найдены"); return; }
  } else if (a == "save") {
    for (uint8_t i = 0; i < NCH; i++) n += calSaveCh(i);
    if (!n) { sendCal(409, "нечего сохранять: ни один датчик не откалиброван"); return; }
    settingsSaveNow();
  } else if (a == "cancel") {
    for (uint8_t i = 0; i < NCH; i++) sensorsCalClear(i);
  } else {
    sendCal(400, "неизвестное действие");
    return;
  }
  uiMarkDirty();
  sendCal();
}

static void handleCal() {
  if (!auth()) return;
  if (server.method() != HTTP_POST) { sendCal(); return; }
  String a = server.arg("a");
  if (server.arg("c") == "all") { handleCalAll(a); return; }
  int i = server.hasArg("c") ? server.arg("c").toInt() : -1;
  if (i < 0 || i >= NCH) { sendCal(400, "нет такого датчика"); return; }
  if (a == "start") {
    if (!sensorsCalStart(i)) { sendCal(409, "датчик выключен или модуль не найден"); return; }
  } else if (a == "save") {
    if (!calSaveCh(i)) { sendCal(409, "нечего сохранять: сначала откалибруйте"); return; }
    settingsSaveNow();
  } else if (a == "cancel") {
    sensorsCalClear(i);
  } else if (a == "reset") {
    Serial.printf("[cal] датчик %u: Rref к номиналу %.0f Ом, поправка 0\n", i + 1, rrefNominal(i));
    cfg.ch[i].rref = rrefNominal(i);
    cfg.ch[i].offset = 0;
    calDateSet(i, 0);
    sensorsCalClear(i);
    settingsSaveNow();
  } else {
    sendCal(400, "неизвестное действие");
    return;
  }
  uiMarkDirty();
  sendCal();
}

// ---------------------------------------------------------------------
//  Файл калибровки: /api/calib (под паролем настроек)
//    GET                  — скачать kolonna-kalibrovka_2026-10-14.json (без часов —
//                           kolonna-kalibrovka.json): по каждому датчику номер, имя,
//                           «включён», тип pt100/pt1000, Rref, поправка, провода и дата
//                           калибровки по льду. Паролей Wi-Fi и настроек в файле нет.
//    POST j=<файл>&a=check — проверить файл и отдать «было → станет» по датчикам
//    POST j=<файл>&a=write — записать Rref и поправку подходящих датчиков (settingsSaveNow)
//  Датчик из файла не загружается, если тип датчика или число проводов не совпадают
//  с настройками (калибровка относится к паре «датчик + модуль»), если Rref вне
//  допуска калибровки по льду (±CAL_MAX_DEV_C от номинала в пересчёте на Rref) или
//  |поправка| > 10 °C. Тип, провода и «включён» из файла не записываются: они
//  нужны только для проверки. Ответ: {"ok":true,"written":2,"ch":[{"n":1,"ok":true,
//  "same":false,"was":{…},"new":{…},"why":""},…]} или {"ok":false,"err":"…"}.
//  Разбор файла свой, без библиотеки JSON: ищутся ключи известного формата.
// ---------------------------------------------------------------------
static const char *CH_NAMES[NCH] = {"куб", "царга", "узел отбора"};
static const char *CALIB_FORMAT = "kolonna-kalibrovka";
static const size_t CALIB_MAX = 4096;     // файл больше — точно не наш

static void handleCalibGet() {
  if (!auth()) return;
  String s;
  s.reserve(800);
  bool clock = timeValid();
  uint32_t now = clock ? (uint32_t)time(nullptr) : 0;
  s += "{\"формат\":\""; s += CALIB_FORMAT; s += "\",\"версия\":1";
  s += ",\"скачано\":"; jstr(s, dateText(now, "%d.%m.%Y %H:%M").c_str());
  s += ",\"датчики\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    const ChannelCfg &c = cfg.ch[i];
    if (i) s += ',';
    s += "\n{\"номер\":"; s += i + 1;
    s += ",\"имя\":"; jstr(s, CH_NAMES[i]);
    s += ",\"включён\":"; s += c.enabled ? "true" : "false";
    s += ",\"тип\":\""; s += c.pt1000 ? "pt1000" : "pt100"; s += '"';
    s += ",\"rref\":"; jnum(s, c.rref, 2);
    s += ",\"поправка\":"; jnum(s, c.offset, 2);
    s += ",\"провода\":"; s += c.wires;
    s += ",\"калибровка\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str());
    s += '}';
  }
  s += "]}\n";
  String name = "kolonna-kalibrovka";
  if (clock) name += "_" + dateText(now, "%Y-%m-%d");
  name += ".json";
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
  server.send(200, "application/json; charset=utf-8", s);
}

// Значение ключа в куске JSON text[from..to): строка отдаётся без кавычек, число/true/false — как есть.
// Пробелы вокруг «:» допускаются; вложенных объектов в файле нет.
static bool jget(const String &text, int from, int to, const char *key, String &out) {
  String k = "\""; k += key; k += '"';
  int p = text.indexOf(k, from);
  if (p < 0 || p >= to) return false;
  p += k.length();
  while (p < to && text[p] == ' ') p++;
  if (p >= to || text[p] != ':') return false;
  p++;
  while (p < to && text[p] == ' ') p++;
  if (p >= to) return false;
  if (text[p] == '"') {
    int e = text.indexOf('"', p + 1);
    if (e < 0 || e > to) return false;
    out = text.substring(p + 1, e);
    return true;
  }
  int e = p;
  while (e < to && text[e] != ',' && text[e] != '}' && text[e] != ']') e++;
  if (e + 1 < to && text[e] == ',' && isdigit((unsigned char)text[e + 1])) return false;   // «432,10»: запятая вместо точки
  out = text.substring(p, e);
  out.trim();
  return out.length() > 0;
}

// «14.10.2026» -> unix-время (полдень по местному времени), 0 — нет даты или не разобрать
static uint32_t dateParse(const String &d) {
  int dd, mm, yy;
  if (d.length() != 10 || sscanf(d.c_str(), "%2d.%2d.%4d", &dd, &mm, &yy) != 3) return 0;
  if (dd < 1 || dd > 31 || mm < 1 || mm > 12 || yy < 2024 || yy > 2099) return 0;
  struct tm tm = {};
  tm.tm_mday = dd; tm.tm_mon = mm - 1; tm.tm_year = yy - 1900; tm.tm_hour = 12; tm.tm_isdst = -1;
  time_t t = mktime(&tm);
  return t < 1700000000 ? 0 : (uint32_t)t;
}

struct CalibRow {
  bool     ok;        // датчик можно записать
  bool     same;      // значения уже такие
  float    rref, off; // из файла
  uint32_t date;      // дата калибровки из файла
  String   why;       // почему не загружается
};

// Разбор и проверка файла: false — это не файл калибровки (err — почему)
static bool calibParse(const String &j, CalibRow rows[NCH], String &err) {
  String v;
  if (j.length() == 0 || j.length() > CALIB_MAX) { err = "это не файл калибровки колонны"; return false; }
  if (!jget(j, 0, j.length(), "формат", v) || v != CALIB_FORMAT) { err = "это не файл калибровки колонны"; return false; }
  if (!jget(j, 0, j.length(), "версия", v) || v != "1") { err = "файл калибровки другой версии"; return false; }
  int list = j.indexOf("\"датчики\"");
  if (list < 0) { err = "в файле нет датчиков"; return false; }
  for (uint8_t i = 0; i < NCH; i++) { rows[i].ok = false; rows[i].same = false; rows[i].rref = rows[i].off = NAN; rows[i].date = 0; rows[i].why = "в файле нет этого датчика"; }
  int p = list;
  uint8_t found = 0;
  for (uint8_t k = 0; k < NCH; k++) {
    int a = j.indexOf('{', p), b = a < 0 ? -1 : j.indexOf('}', a);
    if (a < 0 || b < 0) break;
    p = b + 1;
    if (!jget(j, a, b, "номер", v)) continue;
    int n = v.toInt();
    if (n < 1 || n > NCH) continue;
    found++;
    CalibRow &r = rows[n - 1];
    const ChannelCfg &c = cfg.ch[n - 1];
    String type, rref, off, wires, date;
    if (!jget(j, a, b, "тип", type) || !jget(j, a, b, "rref", rref) || !jget(j, a, b, "поправка", off) || !jget(j, a, b, "провода", wires)) { r.why = "в файле не хватает полей (или число с запятой вместо точки)"; continue; }
    jget(j, a, b, "калибровка", date);
    bool pt1000 = type == "pt1000";
    if (!pt1000 && type != "pt100") { r.why = "тип датчика в файле не разобрать: " + type; continue; }
    if (pt1000 != c.pt1000) { r.why = String("в файле ") + (pt1000 ? "PT1000" : "PT100") + ", а стоит " + (c.pt1000 ? "PT1000" : "PT100") + ": калибровка не подходит"; continue; }
    if (wires.toInt() != c.wires) { r.why = "в файле " + String(wires.toInt()) + " пров., а стоит " + String(c.wires) + ": калибровка не подходит"; continue; }
    r.rref = rref.toFloat(); r.off = off.toFloat();
    // допуск Rref — как у калибровки по льду: ±CAL_MAX_DEV_C от нуля в пересчёте на Rref
    float lo, hi;
    calRrefRange(c.pt1000, lo, hi);
    if (!(r.rref >= lo && r.rref <= hi)) { r.why = "Rref " + fmtNum(r.rref, 2) + " Ом вне допуска калибровки (" + fmtNum(lo, 1) + "…" + fmtNum(hi, 1) + ")"; continue; }
    if (!(fabsf(r.off) <= 10)) { r.why = "поправка " + fmtSigned(r.off, 2) + " °C больше ±10"; continue; }
    r.rref = roundf(r.rref * 100.0f) / 100.0f;
    r.off  = roundf(r.off * 100.0f) / 100.0f;
    r.date = dateParse(date);
    r.ok = true;
    r.why = "";
    r.same = fabsf(r.rref - c.rref) < 0.005f && fabsf(r.off - c.offset) < 0.005f && r.date == calDate(n - 1);
  }
  if (!found) { err = "в файле нет датчиков"; return false; }
  return true;
}

static void handleCalibPost() {
  if (!auth()) return;
  String j = server.arg("j"), a = server.arg("a");
  CalibRow rows[NCH];
  String err, s;
  if (!calibParse(j, rows, err)) {
    s = "{\"ok\":false,\"err\":"; jstr(s, err.c_str()); s += '}';
    server.send(400, "application/json", s);
    return;
  }
  bool write = a == "write";
  uint8_t loadable = 0, written = 0;
  for (uint8_t i = 0; i < NCH; i++) if (rows[i].ok) loadable++;
  if (write && !loadable) {
    server.send(409, "application/json", "{\"ok\":false,\"err\":\"ни один датчик из файла не подходит\"}");
    return;
  }
  s.reserve(900);
  s += "{\"ok\":true,\"ch\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    ChannelCfg &c = cfg.ch[i];
    CalibRow &r = rows[i];
    if (i) s += ',';
    s += "{\"n\":"; s += i + 1;
    s += ",\"ok\":"; s += r.ok ? "true" : "false";
    s += ",\"same\":"; s += r.same ? "true" : "false";
    s += ",\"was\":{\"pt1000\":"; s += c.pt1000 ? "true" : "false";
    s += ",\"wires\":"; s += c.wires;
    s += ",\"rref\":"; jnum(s, c.rref, 2);
    s += ",\"off\":"; jnum(s, c.offset, 2);
    s += ",\"cal\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str()); s += '}';
    s += ",\"new\":{\"rref\":"; jnum(s, r.rref, 2);
    s += ",\"off\":"; jnum(s, r.off, 2);
    s += ",\"cal\":"; jstr(s, dateText(r.date, "%d.%m.%Y").c_str()); s += '}';
    s += ",\"why\":"; jstr(s, r.why.c_str());
    s += '}';
    if (write && r.ok && !r.same) {
      Serial.printf("[cal] датчик %u из файла: Rref %.2f -> %.2f Ом, поправка %.2f -> %.2f\n", i + 1, c.rref, r.rref, c.offset, r.off);
      c.rref = r.rref;
      c.offset = r.off;
      calDateSet(i, r.date);
      sensorsCalClear(i);
      written++;
    }
  }
  s += "],\"written\":"; s += written;
  s += '}';
  if (write) { settingsSaveNow(); uiMarkDirty(); }
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

// поиск сетей (асинхронно: первый запрос запускает, следующие забирают результат)
static void handleScan() {
  if (!auth()) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_FAILED) { WiFi.scanNetworks(true); server.send(200, "application/json", "{\"busy\":true}"); return; }
  if (n == WIFI_SCAN_RUNNING) { server.send(200, "application/json", "{\"busy\":true}"); return; }
  String s = "{\"list\":[";
  for (int i = 0; i < n; i++) {
    if (i) s += ',';
    s += "{\"ssid\":"; jstr(s, WiFi.SSID(i).c_str());
    s += ",\"rssi\":"; s += WiFi.RSSI(i);
    s += ",\"open\":"; s += WiFi.encryptionType(i) == WIFI_AUTH_OPEN ? "true" : "false";
    s += '}';
  }
  s += "]}";
  WiFi.scanDelete();
  server.send(200, "application/json", s);
}

// ---------------------------------------------------------------------
//  Обновление прошивки файлом .bin (Arduino IDE: Sketch -> Export Compiled Binary)
// ---------------------------------------------------------------------
static bool uploadAllowed = false;

static void handleUpdateDone() {
  if (!auth()) return;
  bool ok = uploadAllowed && !Update.hasError();
  server.send(200, "text/plain; charset=utf-8", ok ? "Готово, перезагрузка…" : "Ошибка обновления");
  if (ok) { delay(500); ESP.restart(); }
}

static void handleUpdateUpload() {
  HTTPUpload &up = server.upload();
  if (up.status == UPLOAD_FILE_START) {
    uploadAllowed = server.authenticate(ADMIN_USER, cfg.webPass);
    if (!uploadAllowed) return;
    Serial.printf("[ota] файл %s\n", up.filename.c_str());
    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) Update.printError(Serial);
  } else if (!uploadAllowed) {
    return;
  } else if (up.status == UPLOAD_FILE_WRITE) {
    if (Update.write(up.buf, up.currentSize) != up.currentSize) Update.printError(Serial);
  } else if (up.status == UPLOAD_FILE_END) {
    if (Update.end(true)) Serial.printf("[ota] записано %u байт\n", (unsigned)up.totalSize);
    else Update.printError(Serial);
  } else if (up.status == UPLOAD_FILE_ABORTED) {
    Update.abort();
  }
}

void webBegin() {
  server.on("/", HTTP_GET, [] { server.send_P(200, "text/html; charset=utf-8", PAGE_MAIN); });
  server.on("/settings", HTTP_GET, [] { if (auth()) server.send_P(200, "text/html; charset=utf-8", PAGE_SETTINGS); });
  server.on("/api/state", HTTP_GET, handleState);
  server.on("/api/cmd", HTTP_POST, handleCmd);
  server.on("/api/history", HTTP_GET, handleHistory);
  server.on("/api/events", HTTP_GET, handleEvents);
  server.on("/api/csv", HTTP_GET, handleCsv);
  server.on("/api/logs", HTTP_GET, handleLogs);
  server.on("/api/logdel", HTTP_POST, handleLogDel);
  server.on("/api/settings", HTTP_GET, handleSettingsGet);
  server.on("/api/settings", HTTP_POST, handleSettingsPost);
  server.on("/api/scan", HTTP_GET, handleScan);
  server.on("/api/cal", HTTP_ANY, handleCal);
  server.on("/api/calib", HTTP_GET, handleCalibGet);
  server.on("/api/calib", HTTP_POST, handleCalibPost);
  server.on("/update", HTTP_POST, handleUpdateDone, handleUpdateUpload);
  server.onNotFound([] {
    // в режиме точки доступа телефон ищет «проверку интернета» — отправляем на главную
    if (netState() == NET_AP) {
      server.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/");
      server.send(302, "text/plain", "");
    } else {
      server.send(404, "text/plain; charset=utf-8", "Нет такой страницы");
    }
  });
  server.begin();
  Serial.println(F("[web] веб-сервер запущен на порту 80"));
}

void webLoop() { server.handleClient(); }
