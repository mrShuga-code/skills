// =====================================================================
//  app.h — тестовая прошивка датчиков (kolonna-test).
//
//  Что делает: постоянно показывает Т1 (куб), Т2 (царга), Т3 (узел отбора)
//  с датчиков PT1000, калибрует ноль всех трёх по льду одной кнопкой на
//  экране и пишет лог температур в CSV по кнопке в вебе.
//  Калибровка скачивается файлом того же формата, что в прошивке колонны,
//  и загружается туда: веб колонны -> Настройки -> Датчики -> «Загрузить калибровку».
//
//  Файлы, взятые из прошивки колонны БЕЗ ИЗМЕНЕНИЙ (менять там и копировать сюда):
//    config.h, lgfx_config.h, fonts.h, sensors.cpp, util.cpp, net.cpp
//  Свои файлы теста:
//    kolonna-test.ino — запуск и главный цикл
//    settings.cpp     — настройки теста в NVS (отдельное место «ktest»,
//                       настройки колонны не трогаются)
//    zerocal.cpp      — калибровка нуля по льду (все три датчика сразу)
//    tlog.cpp         — лог температур в LittleFS (/test/temps.csv)
//    ui.cpp           — экран и тач
//    web.cpp, web_page.h — веб: http://kolonna.local
// =====================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

#define TEST_VERSION "23.10.2026"

// Интервалы лога, с (выбор в вебе) и интервал по умолчанию
#define TLOG_DEFAULT_SEC  10
static const uint16_t TLOG_CHOICES[] = {2, 5, 10, 30, 60};
// Лог останавливается сам, если на flash осталось меньше этого (байт)
#define TLOG_MIN_FREE     (64 * 1024)

// ---------------------------------------------------------------------
//  Каналы и настройки
// ---------------------------------------------------------------------
static const uint8_t NCH = 3;
enum : uint8_t { CH_CUBE = 0, CH_COLUMN = 1, CH_THIRD = 2 };  // Т1, Т2, Т3

struct ChannelCfg {        // как в прошивке колонны (sensors.cpp читает эти поля)
  bool    enabled;
  bool    pt1000;
  float   rref;            // Ом
  uint8_t wires;           // 2, 3 или 4
  float   offset;          // поправка, °C (калибровка нуля её обнуляет)
};

struct Settings {
  ChannelCfg ch[NCH];
  char ssid[2][33];
  char pass[2][65];
  char webPass[33];
  uint16_t logSec;         // интервал лога, с
  uint8_t  bright;         // подсветка, % (10..100)
};
extern Settings cfg;

void settingsDefaults(Settings &s);
void settingsLoad();
void settingsSaveNow();
void settingsFactoryReset();
bool touchCalLoad(uint16_t p[8]);
void touchCalSave(const uint16_t p[8]);
uint32_t calDate(uint8_t i);                 // дата калибровки нуля (unix), 0 — нет
void calDateSet(uint8_t i, uint32_t unixTime);
float rrefNominal(uint8_t i);                // 4300 (PT1000) или 430 (PT100)

// ---------------------------------------------------------------------
//  Датчики (sensors.cpp из прошивки колонны)
// ---------------------------------------------------------------------
enum ProbeState : uint8_t { PROBE_OK = 0, PROBE_OFF, PROBE_FAULT, PROBE_NOCHIP, PROBE_WAIT, PROBE_RANGE };
struct Probe {
  float      t;
  float      ohm;
  ProbeState state;
  uint8_t    fault;
  uint32_t   age;
};
void sensorsBegin();
uint32_t sensorsGet(Probe out[NCH]);
void sensorsReconfigure();
const char *probeStateText(const Probe &p);

enum CalState : uint8_t { CAL_IDLE = 0, CAL_RUN, CAL_DONE };
struct CalInfo {
  CalState state;
  uint32_t leftMs;
  float    ohm;
  float    ohmMin, ohmMax;
  uint16_t n, bad, wild;
};
bool    sensorsCalStart(uint8_t i);
CalInfo sensorsCalInfo(uint8_t i);
void    sensorsCalClear(uint8_t i);

float rtdToC(float r, float r0);
float rtdOhm(float t, float r0);

// Сопротивление датчика по среднему за 5 с (для экрана и лога), Ом; NAN — нет
float probeOhm(uint8_t i, const Probe &p);

// ---------------------------------------------------------------------
//  Калибровка нуля (zerocal.cpp)
// ---------------------------------------------------------------------
enum ZeroState : uint8_t { Z_IDLE = 0, Z_RUN, Z_DONE };
enum ZeroErr : uint8_t { ZE_OK = 0, ZE_SKIP, ZE_RANGE, ZE_FAULT, ZE_FAR, ZE_DRIFT };
struct ZeroRow {
  ZeroErr err;
  float   tIce;        // что показывал во льду (без поправки), °C
  float   oldRref, newRref;
};
bool      zeroStart();             // false — ни один датчик не отвечает
ZeroState zeroState();
uint32_t  zeroLeftMs();
ZeroRow   zeroRow(uint8_t i);
uint8_t   zeroSave();              // сколько датчиков записано
void      zeroCancel();
void      zeroReset();             // Rref к номиналу, поправки 0 (только из веба)
const char *zeroErrText(ZeroErr e);       // полная фраза для веба
const char *zeroErrShort(ZeroErr e);      // коротко для экрана

// ---------------------------------------------------------------------
//  Лог температур (tlog.cpp)
// ---------------------------------------------------------------------
struct TlogInfo {
  bool     on;          // запись идёт
  bool     has;         // файл есть (можно скачать)
  uint16_t sec;         // интервал, с
  uint32_t rows;        // строк с данными
  uint32_t elapsed;     // секунд от старта
  uint32_t bytes;       // размер файла
  uint32_t freeBytes;   // свободно на flash
  char     start[20];   // «23.10.2026 14:05:00» (пусто, если часов не было)
  char     stopWhy[48]; // почему остановилась сама (пусто — остановили кнопкой)
};
void     tlogBegin();
void     tlogTick(const Probe p[NCH]);    // раз в секунду, с новым средним
bool     tlogStart(uint16_t sec);         // старый файл удаляется
void     tlogStop(const char *why = "");
void     tlogClear();                     // удалить файл (запись должна быть остановлена)
TlogInfo tlogInfo();
bool     tlogFile(String &path, String &name);
extern const char *TLOG_PATH;

// ---------------------------------------------------------------------
//  Экран, зуммер, сеть, веб
// ---------------------------------------------------------------------
void uiBegin();
void uiLoop();
void uiMarkDirty();
void uiToast(const char *msg, bool bad);
void buzzerBegin();
void buzzerClick();
void buzzerLoop();

enum NetState : uint8_t { NET_CONNECTING = 0, NET_ONLINE, NET_AP };
void netBegin();
void netLoop();
void netReconnect();
NetState netState();
String netAddress();
String netSsid();
bool timeValid();
void timeFromBrowser(uint32_t epoch);

void webBegin();
void webLoop();

String fmtNum(float v, uint8_t dec);
String fmtSigned(float v, uint8_t dec);
String fmtHMS(uint32_t s);
String fmtMS(uint32_t s);
String fmtClock(int32_t unixTime);
String dateText(uint32_t unixTime, const char *fmt);
