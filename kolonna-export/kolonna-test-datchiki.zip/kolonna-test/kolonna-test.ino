// =====================================================================
//  ТЕСТ ДАТЧИКОВ PT1000 — тестовая прошивка для той же платы колонны
//  ESP32-S3 DevKitC-1 N16R8 + 3× MAX31865 (резистор «432», 4300 Ом)
//  + ILI9341 2,8" с тачем FT6336. Пины те же, что у колонны (config.h).
//
//  Экран: Т1 куб, Т2 царга, Т3 узел отбора крупно, с сопротивлением и
//  разницей с Т1; внизу кнопка «Калибровка нуля» (все три датчика во льду).
//  Веб http://kolonna.local (адрес как у колонны):
//    — температуры раз в секунду;
//    — лог: интервал 2/5/10/30/60 с (по умолчанию 10), Старт / Стоп, Скачать CSV;
//    — калибровка: скачать файл (формат колонны), загрузить, сбросить (без пароля).
//
//  Настройки Arduino IDE — как у колонны (README.md колонны):
//    Board: ESP32S3 Dev Module, Flash Size: 16MB, PSRAM: OPI PSRAM,
//    Partition Scheme: 8M with spiffs (3MB APP/1.5MB SPIFFS)
//  НЕ включайте «Erase All Flash Before Upload»: тогда сотрутся настройки
//  и логи колонны. Без этого тест хранит всё отдельно и колонну не трогает.
//
//  secrets.h — скопируйте сюда из папки колонны (тот же файл).
//  Кнопка BOOT: 3 с — калибровка тача, 10 с — сброс настроек ТЕСТА.
// =====================================================================
#include "app.h"

float probeOhm(uint8_t i, const Probe &p) {
  if (i >= NCH || p.state != PROBE_OK || isnan(p.t)) return NAN;
  float r0 = cfg.ch[i].pt1000 ? 1000.0f : 100.0f;
  return rtdOhm(p.t - cfg.ch[i].offset, r0);
}

// Зуммер: только короткий щелчок при нажатии на экран (ключ P3055LD, как у колонны)
static uint32_t clickUntil = 0;
static bool clickOn = false;
void buzzerBegin() {
  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, !BUZZER_ON_LEVEL);
}
void buzzerClick() {
  if (TOUCH_CLICK_MS == 0) return;
  digitalWrite(PIN_BUZZER, BUZZER_ON_LEVEL);
  clickOn = true;
  clickUntil = millis() + TOUCH_CLICK_MS;
}
void buzzerLoop() {
  if (clickOn && (int32_t)(millis() - clickUntil) >= 0) { digitalWrite(PIN_BUZZER, !BUZZER_ON_LEVEL); clickOn = false; }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("\n=== Тест датчиков PT1000 (" TEST_VERSION ") ==="));
  settingsLoad();
  buzzerBegin();
  uiBegin();
  tlogBegin();
  sensorsBegin();
  netBegin();
  webBegin();
  Serial.println(F("Готово. Веб: http://kolonna.local"));
}

void loop() {
  static uint32_t seq = 0;
  Probe p[NCH];
  uint32_t s = sensorsGet(p);
  if (s != seq) {          // раз в секунду: свежее среднее за 5 с
    seq = s;
    tlogTick(p);
    uiMarkDirty();
  }
  uiLoop();
  buzzerLoop();
  netLoop();
  webLoop();
  delay(2);
}
