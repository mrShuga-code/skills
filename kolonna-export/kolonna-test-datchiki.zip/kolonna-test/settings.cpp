// settings.cpp — настройки тестовой прошивки в NVS.
//
//  Лежат в своём месте NVS «ktest», поэтому настройки колонны (место «kolonna»:
//  уставки, Wi-Fi, калибровка, перегон) тест не меняет. После возврата на
//  прошивку колонны всё там как было, а калибровку из теста переносите файлом.
//
//  Wi-Fi и пароль веба при первом запуске теста берутся из настроек колонны
//  (если колонна уже стояла на этой плате и сети меняли в её вебе), иначе
//  из secrets.h. Настройки колонны при этом только читаются.
#include "app.h"
#include <Preferences.h>
#include "secrets.h"

#ifndef WEB_ADMIN_PASS
#define WEB_ADMIN_PASS "123"
#endif

static const uint16_t SETTINGS_VERSION = 1;
static Preferences prefs;
Settings cfg;
static uint32_t calAt[NCH];

static void copyStr(char *dst, const char *src, size_t n) {
  strncpy(dst, src ? src : "", n - 1);
  dst[n - 1] = 0;
}

float rrefNominal(uint8_t i) { return cfg.ch[i].pt1000 ? SENSOR_RREF_PT1000 : SENSOR_RREF_PT100; }

void settingsDefaults(Settings &s) {
  memset(&s, 0, sizeof(s));
  for (uint8_t i = 0; i < NCH; i++) {
    s.ch[i].enabled = true;
    s.ch[i].pt1000  = true;                 // тест только для PT1000
    s.ch[i].rref    = SENSOR_RREF_PT1000;   // модуль с резистором «432»
    s.ch[i].wires   = SENSOR_DEFAULT_WIRES;
    s.ch[i].offset  = 0.0f;
  }
  copyStr(s.ssid[0], WIFI_MAIN_SSID, sizeof(s.ssid[0]));
  copyStr(s.pass[0], WIFI_MAIN_PASS, sizeof(s.pass[0]));
  copyStr(s.ssid[1], WIFI_BACKUP_SSID, sizeof(s.ssid[1]));
  copyStr(s.pass[1], WIFI_BACKUP_PASS, sizeof(s.pass[1]));
  copyStr(s.webPass, WEB_ADMIN_PASS, sizeof(s.webPass));
  s.logSec = TLOG_DEFAULT_SEC;
  s.bright = 70;
}

static void sanitize(Settings &s) {
  for (uint8_t i = 0; i < NCH; i++) {
    if (!(s.ch[i].rref > 10 && s.ch[i].rref < 20000)) s.ch[i].rref = s.ch[i].pt1000 ? SENSOR_RREF_PT1000 : SENSOR_RREF_PT100;
    if (s.ch[i].wires != 2 && s.ch[i].wires != 3 && s.ch[i].wires != 4) s.ch[i].wires = 3;
    if (!(fabsf(s.ch[i].offset) <= 10)) s.ch[i].offset = 0;
  }
  bool okSec = false;
  for (uint16_t v : TLOG_CHOICES) okSec = okSec || s.logSec == v;
  if (!okSec) s.logSec = TLOG_DEFAULT_SEC;
  s.bright = constrain(s.bright, 10, 100);
  s.ssid[0][32] = s.ssid[1][32] = 0;
  s.pass[0][64] = s.pass[1][64] = 0;
  s.webPass[32] = 0;
}

// Начало блока настроек прошивки колонны (settings.cpp колонны, первые 332 байта).
// Нужны только сети и пароль; поля до них повторяют колонну один в один.
struct KolonnaCfgHead {
  ChannelCfg ch[NCH];
  uint16_t stabWindow; float green, red; uint8_t alarmDelay; bool buzzer;
  float z2[4], z1[4], col1; uint8_t chartMin, bright;
  char ssid[2][33]; char pass[2][65]; char webPass[33];
};
static_assert(sizeof(KolonnaCfgHead) == 332, "начало блока настроек колонны — 332 байта");

static void wifiFromKolonna() {
  Preferences k;
  if (!k.begin("kolonna", true)) return;            // только чтение
  KolonnaCfgHead h;
  size_t len = k.getBytesLength("cfg");
  if (len >= sizeof(h) && k.getUShort("ver", 0) == 1) {
    uint8_t buf[512];
    if (len <= sizeof(buf) && k.getBytes("cfg", buf, len) == len) {
      memcpy(&h, buf, sizeof(h));
      h.ssid[0][32] = h.ssid[1][32] = 0; h.pass[0][64] = h.pass[1][64] = 0; h.webPass[32] = 0;
      if (h.ssid[0][0] || h.ssid[1][0]) {
        memcpy(cfg.ssid, h.ssid, sizeof(cfg.ssid));
        memcpy(cfg.pass, h.pass, sizeof(cfg.pass));
        if (h.webPass[0]) memcpy(cfg.webPass, h.webPass, sizeof(cfg.webPass));
        Serial.println(F("[cfg] Wi-Fi и пароль веба взяты из настроек колонны"));
      }
    }
  }
  k.end();
}

void settingsLoad() {
  settingsDefaults(cfg);
  memset(calAt, 0, sizeof(calAt));
  bool fresh = true;
  {
    prefs.begin("ktest", false);
    if (prefs.getBytesLength("calat") == sizeof(calAt)) prefs.getBytes("calat", calAt, sizeof(calAt));
    if (prefs.getUShort("ver", 0) == SETTINGS_VERSION && prefs.getBytesLength("cfg") == sizeof(Settings)) {
      prefs.getBytes("cfg", &cfg, sizeof(Settings));
      sanitize(cfg);
      fresh = false;
      Serial.println(F("[cfg] настройки теста загружены"));
    }
  }
  if (fresh) {
    Serial.println(F("[cfg] первый запуск теста: заводские настройки (PT1000, Rref 4300 Ом)"));
    wifiFromKolonna();
    settingsSaveNow();
  }
}

void settingsSaveNow() {
  sanitize(cfg);
  prefs.putUShort("ver", SETTINGS_VERSION);
  prefs.putBytes("cfg", &cfg, sizeof(Settings));
}

void settingsFactoryReset() {
  prefs.clear();
  memset(calAt, 0, sizeof(calAt));
  settingsDefaults(cfg);
  wifiFromKolonna();
  settingsSaveNow();
}

uint32_t calDate(uint8_t i) { return i < NCH ? calAt[i] : 0; }

void calDateSet(uint8_t i, uint32_t unixTime) {
  if (i >= NCH || calAt[i] == unixTime) return;
  calAt[i] = unixTime;
  prefs.putBytes("calat", calAt, sizeof(calAt));
}

// Калибровка тача: общая с колонной не делается (своё место NVS), метка поворота та же.
static const uint16_t TCAL_TAG = 0xCA00 | (LCD_OFFSET_ROTATION << 4) | TOUCH_OFFSET_ROTATION;

bool touchCalLoad(uint16_t p[8]) {
  uint16_t buf[9];
  if (prefs.getBytesLength("tcal") == sizeof(buf) && prefs.getBytes("tcal", buf, sizeof(buf)) == sizeof(buf) && buf[8] == TCAL_TAG) {
    memcpy(p, buf, 8 * sizeof(uint16_t));
    return true;
  }
  // нет своей — пробуем калибровку тача колонны (только чтение)
  Preferences k;
  bool ok = false;
  if (k.begin("kolonna", true)) {
    if (k.getBytesLength("tcal") == sizeof(buf) && k.getBytes("tcal", buf, sizeof(buf)) == sizeof(buf) && buf[8] == TCAL_TAG) {
      memcpy(p, buf, 8 * sizeof(uint16_t));
      ok = true;
    }
    k.end();
  }
  return ok;
}

void touchCalSave(const uint16_t p[8]) {
  uint16_t buf[9];
  memcpy(buf, p, 8 * sizeof(uint16_t));
  buf[8] = TCAL_TAG;
  prefs.putBytes("tcal", buf, sizeof(buf));
}
