// tlog.cpp — лог температур для теста остывания (кружка кипятка, три датчика в ней).
//
//  Старт и стоп — кнопками в вебе, интервал 2/5/10/30/60 с (по умолчанию 10 с).
//  Один файл /test/temps.csv на LittleFS; новый старт удаляет прошлый файл
//  (веб перед этим предлагает его скачать). Каждая строка дописывается в файл
//  сразу, поэтому перезагрузка или пропажа питания запись не теряют: после
//  включения запись продолжается в тот же файл с событием «перезагрузка».
//
//  Колонки CSV (UTF-8 с BOM, разделитель «;», запятая в числах — для Excel):
//    время     — часы контроллера «14:05:10» (пусто, если время не узнали)
//    секунды   — от старта записи
//    Т1 куб, Т2 царга, Т3 УО — °C, среднее за 5 с, с калибровкой нуля
//    R1, R2, R3 — сопротивление датчика, Ом, по тому же среднему и текущему Rref
//                 (пересчитать на другой Rref: R × Rref_новый / Rref_старый)
//    Т2−Т1, Т3−Т1 — разница с кубом, °C
//    событие   — старт, перезагрузка, неисправность датчика и её конец
//  Пустая ячейка — датчик в этот момент не давал годных данных.
#include "app.h"
#include <LittleFS.h>
#include <Preferences.h>

const char *TLOG_PATH = "/test/temps.csv";
static const char *HEADER = "\xEF\xBB\xBF" "время;секунды;Т1 куб;Т2 царга;Т3 УО;R1 Ом;R2 Ом;R3 Ом;Т2−Т1;Т3−Т1;событие\n";

// Что переживает перезагрузку (NVS «ktest», ключ «tlog»): пишется только
// при старте и стопе, не на каждой строке — бережём flash.
struct TlogSaved {
  uint8_t  on;
  uint8_t  pad;
  uint16_t sec;
  uint32_t startUnix;     // 0 — часов при старте не было
  char     start[20];
};

static Preferences prefs;
static bool fsOk = false;
static TlogSaved sv;
static uint32_t startMs = 0;      // millis() нулевой секунды (с поправкой на продолжение)
static uint32_t nextSec = 0;      // секунда следующей строки
static uint32_t rows = 0;
static String pendingEv;          // событие в следующую строку
static uint8_t lastState[NCH];
static char stopWhy[48] = "";

static void save() { prefs.putBytes("tlog", &sv, sizeof(sv)); }

static String cell(float v, uint8_t dec) { return isnan(v) ? String("") : fmtNum(v, dec); }

// «14:05:10» по часам контроллера (пусто, если время не узнали)
static String clockCell() {
  if (!timeValid()) return String("");
  time_t now = time(nullptr); struct tm tm; localtime_r(&now, &tm);
  char b[12]; snprintf(b, sizeof(b), "%02d:%02d:%02d", tm.tm_hour, tm.tm_min, tm.tm_sec);
  return String(b);
}

static uint32_t elapsedNow() { return (millis() - startMs) / 1000; }

// Последние строки файла: сколько строк данных и секунда последней
static void scanFile(uint32_t &n, uint32_t &lastSec) {
  n = 0; lastSec = 0;
  File f = LittleFS.open(TLOG_PATH, "r");
  if (!f) return;
  char buf[256];
  size_t k;
  String tail;
  bool first = true;
  while ((k = f.read((uint8_t *)buf, sizeof(buf))) > 0) {
    for (size_t i = 0; i < k; i++) if (buf[i] == '\n') { if (first) first = false; else n++; }
  }
  size_t size = f.size();
  size_t from = size > 200 ? size - 200 : 0;
  f.seek(from);
  k = f.read((uint8_t *)buf, sizeof(buf) - 1);
  buf[k] = 0;
  f.close();
  int end = (int)k - 1;
  while (end >= 0 && (buf[end] == '\n' || buf[end] == '\r')) end--;
  int s = end;
  while (s >= 0 && buf[s] != '\n') s--;
  s++;
  // «14:05:10;1230;…» или «;1230;…»
  char *semi = strchr(buf + s, ';');
  if (semi && semi[1] >= '0' && semi[1] <= '9') lastSec = strtoul(semi + 1, nullptr, 10);
}

void tlogBegin() {
  prefs.begin("ktest", false);
  fsOk = LittleFS.begin(true);
  if (!fsOk) { Serial.println(F("[tlog] LittleFS не запустилась: лог недоступен")); return; }
  if (!LittleFS.exists("/test")) LittleFS.mkdir("/test");
  memset(&sv, 0, sizeof(sv));
  if (prefs.getBytesLength("tlog") == sizeof(sv)) prefs.getBytes("tlog", &sv, sizeof(sv));
  sv.start[sizeof(sv.start) - 1] = 0;
  for (uint8_t i = 0; i < NCH; i++) lastState[i] = PROBE_OK;
  if (sv.on && LittleFS.exists(TLOG_PATH)) {
    uint32_t n, last;
    scanFile(n, last);
    rows = n;
    // продолжаем счёт секунд: по часам, если они есть с самого старта, иначе с последней строки
    uint32_t el = last + sv.sec;
    if (sv.startUnix && timeValid() && (uint32_t)time(nullptr) > sv.startUnix) el = (uint32_t)time(nullptr) - sv.startUnix;
    startMs = millis() - el * 1000UL;
    nextSec = el;
    pendingEv = "перезагрузка: запись продолжена";
    Serial.printf("[tlog] запись продолжается после перезагрузки: %lu строк, секунда %lu\n", (unsigned long)rows, (unsigned long)el);
  } else if (sv.on) {
    sv.on = 0; save();
  }
}

bool tlogStart(uint16_t sec) {
  if (!fsOk) return false;
  bool okSec = false;
  for (uint16_t v : TLOG_CHOICES) okSec = okSec || sec == v;
  if (!okSec) sec = TLOG_DEFAULT_SEC;
  if (LittleFS.exists(TLOG_PATH)) LittleFS.remove(TLOG_PATH);
  File f = LittleFS.open(TLOG_PATH, "w");
  if (!f) return false;
  f.print(HEADER);
  f.close();
  memset(&sv, 0, sizeof(sv));
  sv.on = 1;
  sv.sec = sec;
  if (timeValid()) {
    sv.startUnix = (uint32_t)time(nullptr);
    snprintf(sv.start, sizeof(sv.start), "%s", dateText(sv.startUnix, "%d.%m.%Y %H:%M:%S").c_str());
  }
  save();
  startMs = millis();
  nextSec = 0;
  rows = 0;
  stopWhy[0] = 0;
  for (uint8_t i = 0; i < NCH; i++) lastState[i] = PROBE_OK;
  pendingEv = "старт, интервал " + String(sec) + " с";
  Serial.printf("[tlog] старт записи, интервал %u с\n", sec);
  uiMarkDirty();
  return true;
}

void tlogStop(const char *why) {
  if (!sv.on) return;
  sv.on = 0;
  save();
  snprintf(stopWhy, sizeof(stopWhy), "%s", why ? why : "");
  // последняя строка — отметка остановки (без данных)
  File f = LittleFS.open(TLOG_PATH, "a");
  if (f) {
    String row = clockCell();
    row += ';'; row += String(elapsedNow()); row += ";;;;;;;;;";
    row += (why && *why) ? String("стоп: ") + why : String("стоп");
    f.print(row + "\n");
    f.close();
  }
  Serial.printf("[tlog] запись остановлена%s%s\n", why && *why ? ": " : "", why ? why : "");
  uiMarkDirty();
}

void tlogClear() {
  if (sv.on || !fsOk) return;
  LittleFS.remove(TLOG_PATH);
  rows = 0;
  sv.start[0] = 0;
  save();
}

static const char *chName(uint8_t i) { static const char *n[NCH] = {"Т1", "Т2", "Т3"}; return n[i]; }

void tlogTick(const Probe p[NCH]) {
  if (!sv.on || !fsOk) return;
  // события: датчик пропал / вернулся
  for (uint8_t i = 0; i < NCH; i++) {
    if (p[i].state == PROBE_WAIT || p[i].state == lastState[i]) continue;
    if (pendingEv.length()) pendingEv += ", ";
    pendingEv += chName(i);
    pendingEv += ": ";
    pendingEv += p[i].state == PROBE_OK ? "снова норма" : probeStateText(p[i]);
    lastState[i] = p[i].state;
  }
  uint32_t el = elapsedNow();
  if (el < nextSec) return;
  nextSec = (el / sv.sec + 1) * sv.sec;

  size_t total = LittleFS.totalBytes(), used = LittleFS.usedBytes();
  if (total - used < TLOG_MIN_FREE) { tlogStop("на flash кончилось место"); return; }

  float t[NCH], r[NCH];
  for (uint8_t i = 0; i < NCH; i++) {
    t[i] = p[i].state == PROBE_OK ? p[i].t : NAN;
    r[i] = probeOhm(i, p[i]);
  }
  String row;
  row.reserve(140);
  row += clockCell();
  row += ';'; row += String(el);
  for (uint8_t i = 0; i < NCH; i++) { row += ';'; row += cell(t[i], 2); }
  for (uint8_t i = 0; i < NCH; i++) { row += ';'; row += cell(r[i], 2); }
  row += ';'; row += cell(t[1] - t[0], 2);
  row += ';'; row += cell(t[2] - t[0], 2);
  row += ';';
  for (unsigned k = 0; k < pendingEv.length(); k++) {     // «;» и перевод строки сломали бы колонки
    char c = pendingEv[k];
    row += c == ';' ? ',' : c == '\n' ? ' ' : c;
  }
  row += '\n';
  File f = LittleFS.open(TLOG_PATH, "a");
  if (!f) { tlogStop("файл лога не открылся"); return; }
  f.print(row);
  f.close();
  pendingEv = "";
  rows++;
  uiMarkDirty();
}

TlogInfo tlogInfo() {
  TlogInfo r;
  memset(&r, 0, sizeof(r));
  r.on = sv.on;
  r.sec = sv.on ? sv.sec : cfg.logSec;
  r.rows = rows;
  r.elapsed = sv.on ? elapsedNow() : 0;
  if (fsOk) {
    r.has = LittleFS.exists(TLOG_PATH);
    if (r.has) { File f = LittleFS.open(TLOG_PATH, "r"); r.bytes = f ? f.size() : 0; if (f) f.close(); }
    size_t total = LittleFS.totalBytes(), used = LittleFS.usedBytes();
    r.freeBytes = total > used ? total - used : 0;
  }
  snprintf(r.start, sizeof(r.start), "%s", sv.start);
  snprintf(r.stopWhy, sizeof(r.stopWhy), "%s", stopWhy);
  return r;
}

bool tlogFile(String &path, String &name) {
  if (!fsOk || !LittleFS.exists(TLOG_PATH)) return false;
  path = TLOG_PATH;
  name = "kolonna-test";
  if (sv.startUnix) name += "_" + dateText(sv.startUnix, "%Y-%m-%d_%H-%M");
  name += ".csv";
  return true;
}
