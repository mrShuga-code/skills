// ui.cpp — экран теста датчиков 320×240 и тач.
//
//  Главный экран: три плитки Т1 куб, Т2 царга, Т3 УО (среднее за 5 с,
//  сопротивление, разница с Т1), внизу состояние лога и кнопка
//  «Калибровка нуля». Калибровка: окно «датчики во льду?» -> замер 10 с ->
//  таблица «во льду / Rref было -> станет» -> «Сохранить» или «Отмена».
//
//  Всё рисуется в спрайт и выводится целиком (как в прошивке колонны).
//  Кнопка BOOT: 3 с — калибровка тача, 10 с — сброс настроек теста.
#include "app.h"
#include "lgfx_config.h"
#include "fonts.h"
#include <time.h>
#include <string>

static LGFX lcd;
static LGFX_Sprite spr(&lcd);
static bool sprOk = false;

struct UFont { lgfx::VLWfont vlw; lgfx::PointerWrapper data; };
static UFont fXL, fL, fH, fT, fSB, fS;

static void fontLoad(UFont &f, const uint8_t *arr, size_t len) {
  f.data.set(arr, len);
  if (!f.vlw.loadFont(&f.data)) Serial.println(F("[ui] шрифт не загрузился"));
}

typedef uint32_t rgb_t;
static const rgb_t C_BG = 0x0a0d10, C_TILE = 0x11161b, C_TILE_BR = 0x222a31;
static const rgb_t C_MUTED = 0x8b949c, C_TXT2 = 0xdce3ea, C_WHITE = 0xeef1f4;
static const rgb_t C_BTN = 0x1b232b, C_BTN_BR = 0x2b3540, C_BTN_ON = 0x2b3540;
static const rgb_t C_OK = 0x3ddc84, C_WARN = 0xffd23f, C_BAD = 0xff4d4d, C_COLD = 0x5ec8ff, C_ACCENT = 0x3ddc84;
static const rgb_t C_REC = 0xff5a5a;

using Datum = lgfx::textdatum_t;
static const Datum D_L = Datum::baseline_left, D_C = Datum::baseline_center, D_R = Datum::baseline_right;

static int txt(const char *s, int x, int y, UFont &f, rgb_t c, Datum d = D_L) {
  spr.setFont(&f.vlw);
  spr.setTextColor(c);
  spr.setTextDatum(d);
  return spr.drawString(s, x, y);
}
static int txt(const String &s, int x, int y, UFont &f, rgb_t c, Datum d = D_L) { return txt(s.c_str(), x, y, f, c, d); }
static int textW(const char *s, UFont &f) { spr.setFont(&f.vlw); return spr.textWidth(s); }

static String fitText(const String &s, UFont &f, int maxW) {
  if (textW(s.c_str(), f) <= maxW) return s;
  std::string t = s.c_str();
  while (!t.empty()) {
    do t.pop_back(); while (!t.empty() && (uint8_t(t.back()) & 0xC0) == 0x80);
    if (textW((t + "…").c_str(), f) <= maxW) break;
  }
  return String((t + "…").c_str());
}

// ---------------------------------------------------------------------
//  Кнопки
// ---------------------------------------------------------------------
enum : uint8_t { B_NONE = 0, B_ZERO, B_GO, B_CANCEL, B_SAVE };
struct Hit { uint8_t id; int16_t x, y, w, h; };
static Hit hits[8];
static uint8_t nHits = 0;
static uint8_t pressId = B_NONE;

static void addHit(uint8_t id, int x, int y, int w, int h) {
  if (x < TOUCH_EDGE_PX)             { w += x; x = 0; }
  if (y < TOUCH_EDGE_PX)             { h += y; y = 0; }
  if (320 - (x + w) < TOUCH_EDGE_PX) w = 320 - x;
  if (240 - (y + h) < TOUCH_EDGE_PX) h = 240 - y;
  if (nHits < sizeof(hits) / sizeof(hits[0])) hits[nHits++] = {id, (int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h};
}
static uint8_t hitAt(int x, int y) {
  int best = -1, bestD = TOUCH_NEAR_PX * TOUCH_NEAR_PX + 1;
  for (int i = nHits - 1; i >= 0; i--) {
    const Hit &h = hits[i];
    if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) return h.id;
    int dx = x < h.x ? h.x - x : x >= h.x + h.w ? x - (h.x + h.w - 1) : 0;
    int dy = y < h.y ? h.y - y : y >= h.y + h.h ? y - (h.y + h.h - 1) : 0;
    if (dx * dx + dy * dy < bestD) { bestD = dx * dx + dy * dy; best = i; }
  }
  return best >= 0 ? hits[best].id : B_NONE;
}

struct BtnStyle { rgb_t bg, br, fg, sub; };
static const BtnStyle S_NORMAL = {C_BTN, C_BTN_BR, C_TXT2, C_MUTED};
static const BtnStyle S_GO     = {0x1c4a32, C_OK, 0xffffff, 0xbdf5d6};
static const BtnStyle S_COLD   = {0x13407f, C_COLD, 0xffffff, 0xd6ecff};

static void button(int x, int y, int w, int h, const char *label, const char *sub, uint8_t id, const BtnStyle &s = S_NORMAL) {
  bool pressed = pressId == id;
  rgb_t bg = pressed ? (s.bg == C_BTN ? C_BTN_ON : 0x2f6a4c) : s.bg;
  spr.fillRoundRect(x, y, w, h, 6, bg);
  spr.drawRoundRect(x, y, w, h, 6, s.br);
  int cx = x + w / 2;
  if (sub && *sub) {
    txt(label, cx, y + h / 2 + 1, fT, s.fg, D_C);
    txt(sub, cx, y + h / 2 + 14, fS, s.sub, D_C);
  } else {
    txt(label, cx, y + h / 2 + 5, fT, s.fg, D_C);
  }
  addHit(id, x, y, w, h);
}

// ---------------------------------------------------------------------
//  Состояние экрана
// ---------------------------------------------------------------------
static volatile bool dirty = true;
static bool askOpen = false;        // окно «датчики во льду? Начать»
static bool zeroOpen = false;       // окно замера / результата
static char toastMsg[96] = "";
static bool toastBad = false;
static uint32_t toastUntil = 0;
static uint32_t bootHeldMs = 0;
static uint8_t appliedBright = 0;

void uiMarkDirty() { dirty = true; }
void uiToast(const char *msg, bool bad) {
  snprintf(toastMsg, sizeof(toastMsg), "%s", msg);
  toastBad = bad;
  toastUntil = millis() + 3000;
  dirty = true;
}

static const char *CH_LABEL[NCH] = {"Т1", "Т2", "Т3"};
static const char *CH_NAME[NCH]  = {"куб", "царга", "УО"};

static const char *shortState(const Probe &p) {
  if (p.state == PROBE_RANGE) return "тип / Rref?";
  if (p.state == PROBE_FAULT) return "обрыв / КЗ";
  return probeStateText(p);
}

static void statusBar() {
  rgb_t dot = C_MUTED;
  String net;
  switch (netState()) {
    case NET_ONLINE: dot = C_OK; net = netAddress(); break;
    case NET_AP:     dot = C_WARN; net = String(AP_SSID) + " · " + netAddress(); break;
    default:         net = "Wi-Fi…"; break;
  }
  spr.fillCircle(10, 9, 3, dot);
  txt(fitText(net, fS, 98), 17, 13, fS, C_MUTED);
  txt("ТЕСТ ДАТЧИКОВ PT1000", 172, 13, fSB, C_WHITE, D_C);
  String clock = timeValid() ? fmtClock(time(nullptr)) : String("--:--");
  txt(clock, 314, 13, fS, C_MUTED, D_R);
}

static void probeTile(uint8_t i, const Probe &p, const Probe &p1, int y) {
  const int h = 52;
  spr.fillRoundRect(4, y, 312, h, 6, C_TILE);
  spr.drawRoundRect(4, y, 312, h, 6, C_TILE_BR);
  txt(CH_LABEL[i], 12, y + 24, fH, C_WHITE);
  txt(CH_NAME[i], 12, y + 41, fS, C_MUTED);
  bool ok = p.state == PROBE_OK && !isnan(p.t);
  String t = ok ? fmtNum(p.t, 2) : String("——");
  txt(t, 236, y + 43, fXL, ok ? C_WHITE : C_MUTED, D_R);
  if (ok) {
    txt("°C", 242, y + 18, fT, C_MUTED);
    float r = probeOhm(i, p);
    txt(fmtNum(r, 1) + " Ом", 242, y + 32, fS, C_MUTED);
    if (i > 0 && p1.state == PROBE_OK && !isnan(p1.t)) {
      float d = p.t - p1.t;
      rgb_t c = fabsf(d) < 0.1f ? C_OK : fabsf(d) < 0.3f ? C_WARN : C_BAD;
      txt("Δ " + fmtSigned(d, 2), 242, y + 46, fSB, c);
    }
  } else {
    txt(shortState(p), 242, y + 30, fSB, p.state == PROBE_WAIT ? C_MUTED : C_BAD);
  }
}

static void bottomBar() {
  TlogInfo L = tlogInfo();
  if (L.on) {
    spr.fillCircle(11, 203, 4, (millis() / 500) % 2 ? C_REC : 0x5a1a1a);
    int x = txt("Запись ", 20, 207, fT, C_WHITE);
    txt(fmtHMS(L.elapsed), 20 + x, 207, fT, C_WHITE);
    txt(String(L.sec) + " с · " + String(L.rows) + " строк", 8, 221, fS, C_MUTED);
  } else {
    txt("Лог не пишется", 8, 207, fT, C_TXT2);
    txt(L.has ? "есть файл · старт в вебе" : "старт в вебе", 8, 221, fS, C_MUTED);
  }
  bool cal = calDate(0) || calDate(1) || calDate(2);
  String c = cal ? "калибровка " + dateText(max(calDate(0), max(calDate(1), calDate(2))), "%d.%m.%Y") : String("без калибровки нуля");
  if (cal && c == "калибровка ") c = "калибровка есть";
  txt(c, 8, 235, fS, C_MUTED);
  button(176, 194, 140, 42, "Калибровка нуля", "все 3 во льду", B_ZERO, S_COLD);
}

// затемнить кадр под окном
static void dimScreen() {
  if (spr.getColorDepth() != 16) return;
  uint16_t *p = (uint16_t *)spr.getBuffer();
  if (!p) return;
  for (int i = 0; i < 320 * 240; i++) {
    uint16_t v = __builtin_bswap16(p[i]);
    p[i] = __builtin_bswap16((v >> 2) & 0x39E7);
  }
}

static void panel(int y, int h) {
  spr.fillRoundRect(10, y, 300, h, 8, C_TILE);
  spr.drawRoundRect(10, y, 300, h, 8, C_COLD);
}

static void drawAsk() {
  nHits = 0;
  panel(30, 190);
  txt("Калибровка нуля", 160, 56, fH, C_WHITE, D_C);
  txt("Все три датчика опустите в стакан", 160, 82, fS, C_TXT2, D_C);
  txt("с ледяной кашей: мелкий лёд и немного", 160, 97, fS, C_TXT2, D_C);
  txt("воды, перемешать, подождать 2–3 мин.", 160, 112, fS, C_TXT2, D_C);
  txt("Замер " + String(CAL_SECONDS) + " с, датчики не трогать.", 160, 132, fS, C_MUTED, D_C);
  txt("Каждый датчик станет ровно 0,00 °C во льду.", 160, 147, fS, C_MUTED, D_C);
  button(24, 166, 130, 42, "Отмена", nullptr, B_CANCEL);
  button(166, 166, 130, 42, "Начать замер", nullptr, B_GO, S_GO);
}

static void drawZero(const Probe p[NCH]) {
  nHits = 0;
  ZeroState zs = zeroState();
  panel(10, 220);
  if (zs == Z_RUN) {
    txt("Калибровка нуля: замер", 160, 36, fH, C_WHITE, D_C);
    uint32_t left = zeroLeftMs();
    txt("осталось " + String((left + 999) / 1000) + " с, датчики не трогать", 160, 58, fS, C_MUTED, D_C);
    float k = 1.0f - (float)left / (CAL_SECONDS * 1000.0f);
    spr.fillRoundRect(30, 68, 260, 8, 4, C_BTN);
    spr.fillRoundRect(30, 68, (int)(260 * constrain(k, 0.0f, 1.0f)), 8, 4, C_COLD);
    for (uint8_t i = 0; i < NCH; i++) {
      int y = 104 + i * 24;
      txt(String(CH_LABEL[i]) + " " + CH_NAME[i], 34, y, fT, C_TXT2);
      bool ok = p[i].state == PROBE_OK && !isnan(p[i].t);
      txt(ok ? fmtNum(p[i].t, 2) + " °C" : String(shortState(p[i])), 286, y, fT, ok ? C_WHITE : C_BAD, D_R);
    }
    button(95, 176, 130, 42, "Отмена", nullptr, B_CANCEL);
    return;
  }
  // результат
  txt("Калибровка нуля: результат", 160, 36, fH, C_WHITE, D_C);
  txt("во льду", 150, 54, fS, C_MUTED, D_R);
  txt("Rref, Ом: было → станет", 300, 54, fS, C_MUTED, D_R);
  uint8_t good = 0;
  for (uint8_t i = 0; i < NCH; i++) {
    ZeroRow r = zeroRow(i);
    int y = 80 + i * 28;
    txt(String(CH_LABEL[i]) + " " + CH_NAME[i], 20, y, fT, C_TXT2);
    if (!isnan(r.tIce)) txt(fmtNum(r.tIce, 2) + " °C", 150, y, fT, r.err == ZE_OK ? C_WHITE : C_BAD, D_R);
    if (r.err == ZE_OK) {
      good++;
      txt(fmtNum(r.oldRref, 2) + " → " + fmtNum(r.newRref, 2), 300, y, fSB, C_OK, D_R);
    } else {
      txt(zeroErrShort(r.err), 300, y, fSB, C_BAD, D_R);
    }
  }
  if (good) {
    txt(good == NCH ? "Сохранить: Rref запишется, поправки 0" : "Сохранятся только датчики с зелёным Rref", 160, 160, fS, C_MUTED, D_C);
    button(24, 176, 130, 42, "Отмена", nullptr, B_CANCEL);
    char b[32]; snprintf(b, sizeof(b), "Сохранить (%u)", good);
    button(166, 176, 130, 42, b, nullptr, B_SAVE, S_GO);
  } else {
    txt("Ни один датчик не прошёл: смотрите причины", 160, 160, fS, C_BAD, D_C);
    button(95, 176, 130, 42, "Закрыть", nullptr, B_CANCEL);
  }
}

static void drawToast() {
  int w = min(310, textW(toastMsg, fT) + 24);
  int x = 160 - w / 2;
  spr.fillRoundRect(x, 150, w, 32, 6, toastBad ? (rgb_t)0x3a1010 : (rgb_t)0x13301f);
  spr.drawRoundRect(x, 150, w, 32, 6, toastBad ? C_BAD : C_OK);
  txt(toastMsg, 160, 171, fT, C_WHITE, D_C);
}

static void drawBootOverlay() {
  spr.fillRoundRect(20, 70, 280, 100, 8, C_TILE);
  spr.drawRoundRect(20, 70, 280, 100, 8, bootHeldMs >= 10000 ? C_BAD : C_COLD);
  if (bootHeldMs >= 10000) {
    txt("Отпустите BOOT:", 160, 105, fH, C_BAD, D_C);
    txt("сброс настроек теста", 160, 128, fT, C_WHITE, D_C);
    txt("(калибровка теста тоже сбросится)", 160, 146, fS, C_MUTED, D_C);
  } else {
    txt("Отпустите BOOT:", 160, 105, fH, C_COLD, D_C);
    txt("калибровка тача", 160, 128, fT, C_WHITE, D_C);
    txt("держите ещё " + String((10000 - bootHeldMs) / 1000 + 1) + " с — сброс настроек теста", 160, 146, fS, C_MUTED, D_C);
  }
}

static void render() {
  Probe p[NCH];
  sensorsGet(p);
  nHits = 0;
  spr.fillScreen(C_BG);
  statusBar();
  for (uint8_t i = 0; i < NCH; i++) probeTile(i, p[i], p[0], 22 + i * 56);
  bottomBar();
  if (zeroOpen && zeroState() == Z_IDLE) zeroOpen = false;     // отменили из веба / сброс
  if (askOpen || zeroOpen) {
    dimScreen();
    if (zeroOpen) drawZero(p); else drawAsk();
  }
  if (millis() < toastUntil) drawToast();
  if (bootHeldMs >= 3000) drawBootOverlay();
  spr.pushSprite(0, 0);
}

static void action(uint8_t id) {
  switch (id) {
    case B_ZERO:
      askOpen = true;
      break;
    case B_GO:
      askOpen = false;
      if (zeroStart()) zeroOpen = true;
      else uiToast("Ни один модуль датчика не отвечает", true);
      break;
    case B_CANCEL:
      if (zeroOpen) zeroCancel();
      askOpen = zeroOpen = false;
      break;
    case B_SAVE: {
      uint8_t n = zeroSave();
      zeroOpen = false;
      char b[64];
      if (n) snprintf(b, sizeof(b), "Сохранено: %u датч. Файл — в вебе", n);
      else snprintf(b, sizeof(b), "Нечего сохранять");
      uiToast(b, n == 0);
      break;
    }
  }
  dirty = true;
}

static void touchLoop() {
  static bool down = false;
  static uint8_t hitId = 0;
  static uint32_t lastSeen = 0;
  static int lx = 0, ly = 0;
  int32_t x, y;
  bool touched = lcd.getTouch(&x, &y);
  uint32_t t = millis();
#if TOUCH_DEBUG
  if (touched) Serial.printf("[touch] экран x=%ld y=%ld\n", (long)x, (long)y);
#endif
  if (touched) {
    lastSeen = t; lx = x; ly = y;
    if (!down) {
      down = true;
      hitId = hitAt(x, y);
      pressId = hitId;
      if (hitId) buzzerClick();
      dirty = true;
    }
  } else if (down && t - lastSeen > 60) {
    down = false;
    uint8_t id = hitId;
    pressId = 0;
    dirty = true;
    if (id && hitAt(lx, ly) == id) action(id);
  }
}

static void touchCalibrate() {
  lcd.fillScreen(C_BG);
  lcd.setFont(&fT.vlw);
  lcd.setTextColor(C_WHITE, C_BG);
  lcd.setTextDatum(Datum::middle_center);
  lcd.drawString("Калибровка тача", 160, 100);
  lcd.setFont(&fS.vlw);
  lcd.setTextColor(C_MUTED, C_BG);
  lcd.drawString("нажимайте по очереди на стрелки в углах", 160, 124);
  delay(1500);
  uint16_t cal[8];
  lcd.calibrateTouch(cal, C_WHITE, C_BG, 14);
  lcd.setTouchCalibrate(cal);
  touchCalSave(cal);
  dirty = true;
}

static void bootButton() {
  static uint32_t downAt = 0;
  static bool wasDown = false;
  bool down = digitalRead(PIN_BOOT) == LOW;
  uint32_t t = millis();
  if (down && !wasDown) downAt = t;
  if (down) {
    uint32_t held = t - downAt;
    if (held / 1000 != bootHeldMs / 1000) dirty = true;
    bootHeldMs = held;
  } else if (wasDown) {
    uint32_t held = bootHeldMs;
    bootHeldMs = 0;
    dirty = true;
    if (held >= 10000) {
      Serial.println(F("[ui] BOOT 10 с: сброс настроек теста"));
      tlogStop("сброс настроек");
      settingsFactoryReset();
      delay(500);
      ESP.restart();
    } else if (held >= 3000) {
      touchCalibrate();
    }
  }
  wasDown = down;
}

void uiBegin() {
  pinMode(PIN_BOOT, INPUT_PULLUP);
  lcd.init();
  if (lcd.width() < lcd.height()) lcd.setRotation(lcd.getRotation() ^ 1);
  lcd.setBrightness(255);
  appliedBright = 255;
  fontLoad(fXL, font_xl, sizeof(font_xl));
  fontLoad(fL, font_l, sizeof(font_l));
  fontLoad(fH, font_h, sizeof(font_h));
  fontLoad(fT, font_t, sizeof(font_t));
  fontLoad(fSB, font_sb, sizeof(font_sb));
  fontLoad(fS, font_s, sizeof(font_s));
  spr.setPsram(true);
  spr.setColorDepth(16);
  sprOk = spr.createSprite(320, 240);
  if (!sprOk) { spr.setPsram(false); spr.setColorDepth(8); sprOk = spr.createSprite(320, 240); }
  if (!sprOk) Serial.println(F("[ui] ОШИБКА: не хватает памяти для кадра"));
  uint16_t cal[8];
  if (touchCalLoad(cal)) lcd.setTouchCalibrate(cal);
  if (sprOk) {
    spr.fillScreen(C_BG);
    txt("Тест датчиков PT1000", 160, 110, fH, C_WHITE, D_C);
    txt("запуск…", 160, 132, fS, C_MUTED, D_C);
    spr.pushSprite(0, 0);
  }
}

void uiLoop() {
  static uint32_t lastDraw = 0, lastTouch = 0;
  uint32_t t = millis();
  if (t - lastTouch >= 15) { lastTouch = t; touchLoop(); }
  bootButton();
  uint8_t b = (uint8_t)(cfg.bright * 255 / 100);
  if (b != appliedBright) { lcd.setBrightness(b); appliedBright = b; }
  if (!sprOk) return;
  if ((dirty && t - lastDraw >= 40) || t - lastDraw >= 250) {
    dirty = false;
    lastDraw = t;
    render();
  }
}

// для симулятора: открыть окно «датчики во льду?» как нажатием
bool uiZeroOpen() { return zeroOpen || askOpen; }
