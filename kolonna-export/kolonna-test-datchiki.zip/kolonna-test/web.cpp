// web.cpp — веб теста датчиков: http://kolonna.local (или IP со строки состояния экрана)
//
//  /            — страница: температуры, лог, калибровка (без пароля)
//  /api/state   — всё для страницы раз в секунду (?t=<unix> — время из браузера)
//  /api/log     — POST a=start&sec=10 | a=stop | a=clear (без пароля)
//  /api/csv     — скачать лог CSV
//  /api/calib   — GET: скачать файл калибровки (формат колонны, без пароля);
//                 POST j=<файл>&a=check|write — загрузить (проверка «было -> станет», потом запись)
//  /api/zero    — POST a=reset — сбросить калибровку к номиналу;
//                 a=cancel — закрыть замер
//  Пароля в тесте нет: это стендовая прошивка в домашней сети, а браузер
//  на телефоне не всегда спрашивает пароль у кнопок страницы.
#include "app.h"
#include <WebServer.h>
#include <WiFi.h>
#include <LittleFS.h>
#include "web_page.h"

static WebServer server(80);


static void jnum(String &s, float v, uint8_t dec = 2) {
  if (isnan(v)) s += "null"; else s += String(v, (unsigned int)dec);
}

static void jstr(String &s, const char *v) {
  s += '"';
  for (const char *c = v; *c; c++) {
    if (*c == '"' || *c == '\\') s += '\\';
    if ((uint8_t)*c >= 0x20) s += *c;
  }
  s += '"';
}

String dateText(uint32_t unixTime, const char *fmt) {
  if (unixTime < 1700000000) return String("");
  time_t t = unixTime; struct tm tm; localtime_r(&t, &tm);
  char b[32]; strftime(b, sizeof(b), fmt, &tm);
  return String(b);
}

static const char *CH_NAMES[NCH] = {"куб", "царга", "узел отбора"};

// ---------------------------------------------------------------------
//  /api/state
// ---------------------------------------------------------------------
static void handleState() {
  if (server.hasArg("t")) timeFromBrowser(strtoul(server.arg("t").c_str(), nullptr, 10));
  Probe p[NCH];
  sensorsGet(p);
  String s;
  s.reserve(1500);
  s += "{\"ver\":\"" TEST_VERSION "\"";
  s += ",\"clock\":"; jstr(s, timeValid() ? dateText((uint32_t)time(nullptr), "%d.%m.%Y %H:%M:%S").c_str() : "");
  s += ",\"net\":"; jstr(s, (netSsid() + " · " + netAddress()).c_str());
  s += ",\"p\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    bool ok = p[i].state == PROBE_OK && !isnan(p[i].t);
    if (i) s += ',';
    s += "{\"t\":"; jnum(s, ok ? p[i].t : NAN);
    s += ",\"ohm\":"; jnum(s, probeOhm(i, p[i]), 2);
    s += ",\"ok\":"; s += ok ? "true" : "false";
    s += ",\"txt\":"; jstr(s, probeStateText(p[i]));
    s += ",\"rref\":"; jnum(s, cfg.ch[i].rref, 2);
    s += ",\"off\":"; jnum(s, cfg.ch[i].offset, 2);
    s += ",\"type\":\""; s += cfg.ch[i].pt1000 ? "PT1000" : "PT100"; s += '"';
    s += ",\"cal\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str());
    s += ",\"calx\":"; s += calDate(i) ? "true" : "false";
    s += ",\"nom\":"; s += fabsf(cfg.ch[i].rref - rrefNominal(i)) < 0.005f ? "true" : "false";
    s += '}';
  }
  s += "]";
  TlogInfo L = tlogInfo();
  s += ",\"log\":{\"on\":"; s += L.on ? "true" : "false";
  s += ",\"has\":"; s += L.has ? "true" : "false";
  s += ",\"sec\":"; s += L.sec;
  s += ",\"rows\":"; s += L.rows;
  s += ",\"el\":"; s += L.elapsed;
  s += ",\"bytes\":"; s += L.bytes;
  s += ",\"free\":"; s += L.freeBytes;
  s += ",\"start\":"; jstr(s, L.start);
  s += ",\"why\":"; jstr(s, L.stopWhy);
  s += "}";
  ZeroState zs = zeroState();
  s += ",\"zero\":{\"st\":"; s += zs;
  s += ",\"left\":"; s += zeroLeftMs();
  s += ",\"ch\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    ZeroRow r = zeroRow(i);
    if (i) s += ',';
    s += "{\"err\":"; jstr(s, zs == Z_DONE ? zeroErrText(r.err) : "");
    s += ",\"t\":"; jnum(s, r.tIce, 2);
    s += ",\"nrref\":"; jnum(s, r.newRref, 2);
    s += '}';
  }
  s += "]}}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

// ---------------------------------------------------------------------
//  Лог
// ---------------------------------------------------------------------
static void handleLog() {
  String a = server.arg("a");
  if (a == "start") {
    uint16_t sec = server.arg("sec").toInt();
    bool okSec = false;
    for (uint16_t v : TLOG_CHOICES) okSec = okSec || sec == v;
    if (!okSec) { server.send(400, "application/json", "{\"ok\":false,\"err\":\"интервал: 2, 5, 10, 30 или 60 с\"}"); return; }
    if (tlogInfo().on) { server.send(409, "application/json", "{\"ok\":false,\"err\":\"запись уже идёт\"}"); return; }
    if (cfg.logSec != sec) { cfg.logSec = sec; settingsSaveNow(); }
    if (!tlogStart(sec)) { server.send(500, "application/json", "{\"ok\":false,\"err\":\"файл не создался (LittleFS)\"}"); return; }
  } else if (a == "stop") {
    tlogStop("");
  } else if (a == "clear") {
    if (tlogInfo().on) { server.send(409, "application/json", "{\"ok\":false,\"err\":\"сначала остановите запись\"}"); return; }
    tlogClear();
  } else {
    server.send(400, "application/json", "{\"ok\":false,\"err\":\"неизвестное действие\"}");
    return;
  }
  server.send(200, "application/json", "{\"ok\":true}");
}

static void handleCsv() {
  String path, name;
  if (!tlogFile(path, name)) { server.send(404, "text/plain; charset=utf-8", "Лога нет: начните запись"); return; }
  File f = LittleFS.open(path, "r");
  if (!f) { server.send(500, "text/plain; charset=utf-8", "файл не открылся"); return; }
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
  server.streamFile(f, "text/csv; charset=utf-8");
  f.close();
}

// ---------------------------------------------------------------------
//  Файл калибровки — тот же формат «kolonna-kalibrovka», версия 1, что у
//  колонны (web.cpp колонны): колонна его загружает без переделок.
// ---------------------------------------------------------------------
static const char *CALIB_FORMAT = "kolonna-kalibrovka";
static const size_t CALIB_MAX = 4096;

static void handleCalibGet() {
  String s;
  s.reserve(800);
  bool clock = timeValid();
  uint32_t now = clock ? (uint32_t)time(nullptr) : 0;
  s += "{\"формат\":\""; s += CALIB_FORMAT; s += "\",\"версия\":1";
  s += ",\"скачано\":"; jstr(s, dateText(now, "%d.%m.%Y %H:%M").c_str());
  s += ",\"источник\":\"тест датчиков " TEST_VERSION "\"";
  s += ",\"датчики\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    const ChannelCfg &c = cfg.ch[i];
    if (i) s += ',';
    s += "\n{\"номер\":"; s += i + 1;
    s += ",\"имя\":"; jstr(s, CH_NAMES[i]);
    s += ",\"включён\":"; s += c.enabled ? "true" : "false";
    s += ",\"тип\":\""; s += c.pt1000 ? "pt1000" : "pt100"; s += '"';
    s += ",\"rref\":"; jnum(s, c.rref, 2);
    s += ",\"поправка\":"; jnum(s, c.offset, 2);
    s += ",\"провода\":"; s += c.wires;
    s += ",\"калибровка\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str());
    s += '}';
  }
  s += "]}\n";
  String name = "kolonna-kalibrovka";
  if (clock) name += "_" + dateText(now, "%Y-%m-%d");
  name += ".json";
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("Content-Disposition", "attachment; filename=\"" + name + "\"");
  server.send(200, "application/json; charset=utf-8", s);
}

static bool jget(const String &text, int from, int to, const char *key, String &out) {
  String k = "\""; k += key; k += '"';
  int p = text.indexOf(k, from);
  if (p < 0 || p >= to) return false;
  p += k.length();
  while (p < to && text[p] == ' ') p++;
  if (p >= to || text[p] != ':') return false;
  p++;
  while (p < to && text[p] == ' ') p++;
  if (p >= to) return false;
  if (text[p] == '"') {
    int e = text.indexOf('"', p + 1);
    if (e < 0 || e > to) return false;
    out = text.substring(p + 1, e);
    return true;
  }
  int e = p;
  while (e < to && text[e] != ',' && text[e] != '}' && text[e] != ']') e++;
  if (e + 1 < to && text[e] == ',' && isdigit((unsigned char)text[e + 1])) return false;
  out = text.substring(p, e);
  out.trim();
  return out.length() > 0;
}

static uint32_t dateParse(const String &d) {
  int dd, mm, yy;
  if (d.length() != 10 || sscanf(d.c_str(), "%2d.%2d.%4d", &dd, &mm, &yy) != 3) return 0;
  if (dd < 1 || dd > 31 || mm < 1 || mm > 12 || yy < 2024 || yy > 2099) return 0;
  struct tm tm = {};
  tm.tm_mday = dd; tm.tm_mon = mm - 1; tm.tm_year = yy - 1900; tm.tm_hour = 12; tm.tm_isdst = -1;
  time_t t = mktime(&tm);
  return t < 1700000000 ? 0 : (uint32_t)t;
}

struct CalibRow { bool ok, same; float rref, off; uint32_t date; String why; };

static bool calibParse(const String &j, CalibRow rows[NCH], String &err) {
  String v;
  if (j.length() == 0 || j.length() > CALIB_MAX) { err = "это не файл калибровки колонны"; return false; }
  if (!jget(j, 0, j.length(), "формат", v) || v != CALIB_FORMAT) { err = "это не файл калибровки колонны"; return false; }
  if (!jget(j, 0, j.length(), "версия", v) || v != "1") { err = "файл калибровки другой версии"; return false; }
  int list = j.indexOf("\"датчики\"");
  if (list < 0) { err = "в файле нет датчиков"; return false; }
  for (uint8_t i = 0; i < NCH; i++) { rows[i].ok = rows[i].same = false; rows[i].rref = rows[i].off = NAN; rows[i].date = 0; rows[i].why = "в файле нет этого датчика"; }
  int p = list;
  uint8_t found = 0;
  for (uint8_t k = 0; k < NCH; k++) {
    int a = j.indexOf('{', p), b = a < 0 ? -1 : j.indexOf('}', a);
    if (a < 0 || b < 0) break;
    p = b + 1;
    if (!jget(j, a, b, "номер", v)) continue;
    int n = v.toInt();
    if (n < 1 || n > NCH) continue;
    found++;
    CalibRow &r = rows[n - 1];
    const ChannelCfg &c = cfg.ch[n - 1];
    String type, rref, off, wires, date;
    if (!jget(j, a, b, "тип", type) || !jget(j, a, b, "rref", rref) || !jget(j, a, b, "поправка", off) || !jget(j, a, b, "провода", wires)) { r.why = "в файле не хватает полей (или число с запятой вместо точки)"; continue; }
    jget(j, a, b, "калибровка", date);
    bool pt1000 = type == "pt1000";
    if (!pt1000 && type != "pt100") { r.why = "тип датчика в файле не разобрать: " + type; continue; }
    if (pt1000 != c.pt1000) { r.why = String("в файле ") + (pt1000 ? "PT1000" : "PT100") + ", а стоит " + (c.pt1000 ? "PT1000" : "PT100") + ": калибровка не подходит"; continue; }
    if (wires.toInt() != c.wires) { r.why = "в файле " + String(wires.toInt()) + " пров., а стоит " + String(c.wires) + ": калибровка не подходит"; continue; }
    r.rref = rref.toFloat(); r.off = off.toFloat();
    float r0 = c.pt1000 ? 1000.0f : 100.0f, nom = rrefNominal(n - 1);
    float lo = nom * r0 / rtdOhm(CAL_MAX_DEV_C, r0), hi = nom * r0 / rtdOhm(-CAL_MAX_DEV_C, r0);
    if (!(r.rref >= lo && r.rref <= hi)) { r.why = "Rref " + fmtNum(r.rref, 2) + " Ом вне допуска калибровки (" + fmtNum(lo, 1) + "…" + fmtNum(hi, 1) + ")"; continue; }
    if (!(fabsf(r.off) <= 10)) { r.why = "поправка " + fmtSigned(r.off, 2) + " °C больше ±10"; continue; }
    r.rref = roundf(r.rref * 100.0f) / 100.0f;
    r.off  = roundf(r.off * 100.0f) / 100.0f;
    r.date = dateParse(date);
    r.ok = true;
    r.why = "";
    r.same = fabsf(r.rref - c.rref) < 0.005f && fabsf(r.off - c.offset) < 0.005f && r.date == calDate(n - 1);
  }
  if (!found) { err = "в файле нет датчиков"; return false; }
  return true;
}

static void handleCalibPost() {
  String j = server.arg("j"), a = server.arg("a");
  CalibRow rows[NCH];
  String err, s;
  if (!calibParse(j, rows, err)) {
    s = "{\"ok\":false,\"err\":"; jstr(s, err.c_str()); s += '}';
    server.send(400, "application/json", s);
    return;
  }
  bool write = a == "write";
  uint8_t loadable = 0, written = 0;
  for (uint8_t i = 0; i < NCH; i++) if (rows[i].ok) loadable++;
  if (write && !loadable) { server.send(409, "application/json", "{\"ok\":false,\"err\":\"ни один датчик из файла не подходит\"}"); return; }
  s.reserve(900);
  s += "{\"ok\":true,\"ch\":[";
  for (uint8_t i = 0; i < NCH; i++) {
    ChannelCfg &c = cfg.ch[i];
    CalibRow &r = rows[i];
    if (i) s += ',';
    s += "{\"n\":"; s += i + 1;
    s += ",\"ok\":"; s += r.ok ? "true" : "false";
    s += ",\"same\":"; s += r.same ? "true" : "false";
    s += ",\"was\":{\"rref\":"; jnum(s, c.rref, 2);
    s += ",\"off\":"; jnum(s, c.offset, 2);
    s += ",\"cal\":"; jstr(s, dateText(calDate(i), "%d.%m.%Y").c_str()); s += '}';
    s += ",\"new\":{\"rref\":"; jnum(s, r.rref, 2);
    s += ",\"off\":"; jnum(s, r.off, 2);
    s += ",\"cal\":"; jstr(s, dateText(r.date, "%d.%m.%Y").c_str()); s += '}';
    s += ",\"why\":"; jstr(s, r.why.c_str());
    s += '}';
    if (write && r.ok && !r.same) {
      c.rref = r.rref;
      c.offset = r.off;
      calDateSet(i, r.date);
      written++;
    }
  }
  s += "],\"written\":"; s += written;
  s += '}';
  if (write) { zeroCancel(); settingsSaveNow(); uiMarkDirty(); }
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

static void handleZero() {
  String a = server.arg("a");
  if (a == "reset") {
    zeroReset();
  } else if (a == "cancel") {
    zeroCancel();
  } else {
    server.send(400, "application/json", "{\"ok\":false,\"err\":\"неизвестное действие\"}");
    return;
  }
  uiMarkDirty();
  server.send(200, "application/json", "{\"ok\":true}");
}

void webBegin() {
  server.on("/", HTTP_GET, [] { server.send_P(200, "text/html; charset=utf-8", PAGE_TEST); });
  server.on("/api/state", HTTP_GET, handleState);
  server.on("/api/log", HTTP_POST, handleLog);
  server.on("/api/csv", HTTP_GET, handleCsv);
  server.on("/api/calib", HTTP_GET, handleCalibGet);
  server.on("/api/calib", HTTP_POST, handleCalibPost);
  server.on("/api/zero", HTTP_POST, handleZero);
  server.onNotFound([] { server.send(404, "text/plain; charset=utf-8", "нет такой страницы"); });
  server.begin();
}

void webLoop() { server.handleClient(); }
