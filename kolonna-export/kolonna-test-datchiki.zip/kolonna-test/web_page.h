// web_page.h — страница теста датчиков (HTML + CSS + JS в одном файле).
// Светлая и тёмная тема по настройке телефона/компьютера, как у колонны.
#pragma once
#include <Arduino.h>

static const char PAGE_TEST[] PROGMEM = R"HTML(<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Тест датчиков</title>
<style>
:root{--bg:#f3f4f1;--surface:#fff;--fg:#1b1f1d;--muted:#5d6762;--line:#d9ddd8;--accent:#2f6b55;
--ok:#1e8a4c;--warn:#a77a00;--bad:#c83232;--cold:#1a7fbf;--ok-t:#e3f3ea;--bad-t:#fbe1e1;--cold-t:#e0f0fa;
--c1:#c9600c;--c2:#1a7fbf;--c3:#7a45c2}
@media(prefers-color-scheme:dark){:root{--bg:#121614;--surface:#1a1f1c;--fg:#e8ece9;--muted:#9aa49f;--line:#2c332f;--accent:#6fbf9c;
--ok:#4fd18a;--warn:#f2c94c;--bad:#ff6b6b;--cold:#5ec2ff;--ok-t:#173226;--bad-t:#3e1d1d;--cold-t:#15303f;
--c1:#ff9a4a;--c2:#5ec2ff;--c3:#b993ff;color-scheme:dark}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.wrap{max-width:980px;margin:0 auto;padding:16px;display:grid;gap:14px}
header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px 16px}
h1{font-size:19px;margin:0}h2{font-size:16px;margin:0 0 8px}
.meta{font-size:13px;color:var(--muted)}
a{color:var(--accent)}
button,.lnk,select{font:600 14px system-ui,sans-serif;border:1px solid var(--line);border-radius:8px;padding:9px 14px;background:var(--surface);color:var(--fg);cursor:pointer;text-decoration:none;display:inline-block}
button:disabled{opacity:.45;cursor:default}
.go{background:var(--ok);color:#fff;border:0}.stop{background:var(--bad);color:#fff;border:0}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}
.card{background:var(--surface);border:1px solid var(--line);border-left:6px solid var(--line);border-radius:10px;padding:10px 14px;display:grid;gap:2px;min-width:0}
.card .k{font-size:13px;color:var(--muted)}
.card .v{font:700 36px/1.1 ui-monospace,"SFMono-Regular",Consolas,monospace;font-variant-numeric:tabular-nums}
.card .s{font-size:13px;color:var(--muted);font-variant-numeric:tabular-nums}
.box{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.st{font-size:14px;margin:8px 0 0;font-variant-numeric:tabular-nums}
.rec{display:inline-block;width:10px;height:10px;border-radius:50%;background:var(--bad);margin-right:6px;animation:b 1s steps(2) infinite}
@keyframes b{50%{opacity:.2}}
.note{font-size:13px;color:var(--muted);margin:8px 0 0}
table{border-collapse:collapse;width:100%;font-size:14px;font-variant-numeric:tabular-nums}
th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-weight:600;color:var(--muted);font-size:13px}
.tw{overflow-x:auto}
.bad{color:var(--bad)}.ok{color:var(--ok)}.warn{color:var(--warn)}
.msg{padding:8px 12px;border-radius:8px;margin-top:8px;font-size:14px}
.msg.good{background:var(--ok-t);color:var(--ok)}.msg.err{background:var(--bad-t);color:var(--bad)}
canvas{width:100%;height:220px;display:block}
.leg{font-size:13px;color:var(--muted);display:flex;gap:14px;flex-wrap:wrap}
.leg i{display:inline-block;width:14px;height:3px;vertical-align:middle;margin-right:5px}
</style></head><body><div class="wrap">
<header><h1>Тест датчиков PT1000</h1><div class="meta"><span id="clk">--</span> · <span id="net"></span></div></header>

<div class="cards" id="cards"></div>

<div class="box">
<h2>Лог температур</h2>
<div class="row">
<label>Интервал <select id="sec"><option value="2">2 с</option><option value="5">5 с</option><option value="10">10 с</option><option value="30">30 с</option><option value="60">60 с</option></select></label>
<button class="go" id="bstart">Старт записи</button><button class="stop" id="bstop">Стоп</button>
<a class="lnk" id="bcsv" href="/api/csv" download>Скачать CSV</a><button id="bclr">Удалить файл</button>
</div>
<div class="st" id="lst">—</div>
<div id="lmsg"></div>
<p class="note">Для теста остывания: все три датчика вместе в кружку с кипятком (на одну глубину, не касаясь стенок), «Старт записи»,
через 1–2 часа «Стоп» и «Скачать CSV». 10 с хватает: датчики и так усредняются за 5 с. Запись идёт во flash контроллера,
перезагрузка её не обрывает. Новый старт удаляет прошлый файл — сначала скачайте его.
CSV: время; секунды; Т1 куб; Т2 царга; Т3 УО; R1–R3 (Ом); Т2−Т1; Т3−Т1; событие.</p>
</div>

<div class="box">
<h2>Температуры с открытия страницы</h2>
<div class="leg"><span><i style="background:var(--c1)"></i>Т1 куб</span><span><i style="background:var(--c2)"></i>Т2 царга</span><span><i style="background:var(--c3)"></i>Т3 УО</span></div>
<canvas id="ch"></canvas>
</div>

<div class="box">
<h2>Калибровка нуля</h2>
<div id="zst"></div>
<div class="tw"><table><thead><tr><th>Датчик</th><th>Тип</th><th>Rref, Ом</th><th>Поправка</th><th>Калибровка</th></tr></thead><tbody id="ctab"></tbody></table></div>
<p class="note">Калибруется кнопкой <b>«Калибровка нуля»</b> на экране: все три датчика в стакане с ледяной кашей, 10 с замер,
потом «Сохранить». После этого скачайте файл и загрузите его в прошивку колонны:
веб колонны → Настройки → Датчики → «Загрузить калибровку». Номера датчиков те же: 1 куб, 2 царга, 3 узел отбора.</p>
<div class="row" style="margin-top:8px">
<a class="lnk" href="/api/calib" download>Скачать калибровку</a>
<button id="cload">Загрузить калибровку</button><input type="file" id="cfile" accept=".json,application/json" hidden>
<button id="creset">Сбросить к номиналу 4300</button>
</div>
<div id="cimp" hidden><div class="tw"><table><thead><tr><th>Датчик</th><th>Сейчас</th><th>Из файла</th></tr></thead><tbody id="cimpb"></tbody></table></div>
<div class="row" style="margin-top:8px"><button class="go" id="cwrite">Записать</button><button id="ccancel">Отмена</button></div></div>
<div id="cmsg"></div>
</div>
<p class="meta" id="ver"></p>
</div>
<script>
const $=id=>document.getElementById(id);
const NAMES=['Т1 · куб','Т2 · царга','Т3 · узел отбора'],COL=['--c1','--c2','--c3'];
const n=(v,d)=>v==null||isNaN(v)?'——':v.toFixed(d).replace('.',',');
const sg=(v,d)=>v==null?'——':(v>=0?'+':'−')+Math.abs(v).toFixed(d).replace('.',',');
const hms=s=>Math.floor(s/3600)+':'+String(Math.floor(s/60)%60).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
const kb=b=>b>=1048576?(b/1048576).toFixed(1).replace('.',',')+' МБ':Math.round(b/1024)+' КБ';
function msg(id,t,bad){$(id).innerHTML=t?'<div class="msg '+(bad?'err':'good')+'">'+t+'</div>':'';}
$('cards').innerHTML=NAMES.map((k,i)=>'<div class="card" style="border-left-color:var('+COL[i]+')"><div class="k">'+k+'</div><div class="v" id="t'+i+'">——</div><div class="s" id="s'+i+'"></div></div>').join('');
let S=null,hist=[],secSet=false,timeSent=false;
async function post(url,data){const r=await fetch(url,{method:'POST',body:new URLSearchParams(data)});let j={};try{j=await r.json();}catch(e){}return j;}
async function poll(){
  try{
    let u='/api/state';if(!timeSent){u+='?t='+Math.floor(Date.now()/1000);timeSent=true;}
    const r=await fetch(u);S=await r.json();
  }catch(e){setTimeout(poll,2000);return;}
  $('clk').textContent=S.clock||'время не задано';$('net').textContent=S.net;$('ver').textContent='Тестовая прошивка датчиков, версия '+S.ver;
  const p=S.p;
  p.forEach((c,i)=>{$('t'+i).textContent=c.ok?n(c.t,2)+' °C':'——';
    let s=c.ok?n(c.ohm,2)+' Ом':'<span class="bad">'+c.txt+'</span>';
    if(i&&c.ok&&p[0].ok){const d=c.t-p[0].t;s+=' · Δ к Т1 <b class="'+(Math.abs(d)<0.1?'ok':Math.abs(d)<0.3?'warn':'bad')+'">'+sg(d,2)+'</b>';}
    $('s'+i).innerHTML=s;});
  hist.push([Date.now(),p.map(c=>c.ok?c.t:null)]);if(hist.length>7200)hist.shift();draw();
  const L=S.log;
  if(!secSet){$('sec').value=L.sec;secSet=true;}
  $('bstart').disabled=L.on;$('bstop').disabled=!L.on;$('sec').disabled=L.on;$('bclr').disabled=L.on||!L.has;
  $('bcsv').style.pointerEvents=L.has?'':'none';$('bcsv').style.opacity=L.has?'':'.45';
  let t;
  if(L.on)t='<span class="rec"></span>Идёт запись: '+hms(L.el)+', '+L.rows+' строк, каждые '+L.sec+' с'+(L.start?' (старт '+L.start+')':'');
  else t=L.has?'Запись остановлена'+(L.why?': <b class="bad">'+L.why+'</b>':'')+'. В файле '+L.rows+' строк'+(L.start?', старт '+L.start:''):'Записи нет';
  if(L.has)t+=' · файл '+kb(L.bytes);t+=' · свободно '+kb(L.free);
  $('lst').innerHTML=t;
  $('ctab').innerHTML=p.map((c,i)=>'<tr><td>'+(i+1)+' · '+NAMES[i].split(' · ')[1]+'</td><td>'+c.type+'</td><td>'+n(c.rref,2)+(c.nom?' <span class="meta">номинал</span>':'')+'</td><td>'+sg(c.off,2)+' °C</td><td>'+(c.cal||(c.nom?'не калибровался':'без даты'))+'</td></tr>').join('');
  const Z=S.zero;
  if(Z.st==1)$('zst').innerHTML='<div class="msg good">На экране идёт замер во льду: осталось '+Math.ceil(Z.left/1000)+' с</div>';
  else if(Z.st==2)$('zst').innerHTML='<div class="msg good">Замер готов: '+Z.ch.map((z,i)=>'Т'+(i+1)+' '+(z.err?'<span class="bad">'+z.err+'</span>':n(z.t,2)+' °C → Rref '+n(z.nrref,2))).join('; ')+'. Нажмите «Сохранить» на экране.</div>';
  else $('zst').innerHTML='';
  setTimeout(poll,1000);
}
function draw(){
  const c=$('ch'),dpr=window.devicePixelRatio||1,W=c.clientWidth,H=c.clientHeight;c.width=W*dpr;c.height=H*dpr;
  const g=c.getContext('2d');g.scale(dpr,dpr);g.clearRect(0,0,W,H);
  const cs=getComputedStyle(document.documentElement);
  let lo=1e9,hi=-1e9;hist.forEach(h=>h[1].forEach(v=>{if(v!=null){lo=Math.min(lo,v);hi=Math.max(hi,v);}}));
  if(lo>hi)return;if(hi-lo<1){const m=(hi+lo)/2;lo=m-0.5;hi=m+0.5;}
  const L=44,R=W-8,T=8,B=H-22,t0=hist[0][0],t1=Math.max(hist[hist.length-1][0],t0+1000);
  g.font='11px system-ui';g.fillStyle=cs.getPropertyValue('--muted');g.strokeStyle=cs.getPropertyValue('--line');g.lineWidth=1;
  for(let k=0;k<=4;k++){const v=lo+(hi-lo)*k/4,y=B-(B-T)*k/4;g.beginPath();g.moveTo(L,y);g.lineTo(R,y);g.stroke();g.fillText(v.toFixed(1).replace('.',','),4,y+4);}
  g.fillText(Math.round((t1-t0)/60000)+' мин',R-40,H-6);
  for(let i=0;i<3;i++){g.strokeStyle=cs.getPropertyValue(COL[i]);g.lineWidth=2;g.beginPath();let on=false;
    hist.forEach(h=>{const v=h[1][i];if(v==null){on=false;return;}const x=L+(R-L)*(h[0]-t0)/(t1-t0),y=B-(B-T)*(v-lo)/(hi-lo);on?g.lineTo(x,y):g.moveTo(x,y);on=true;});g.stroke();}
}
window.addEventListener('resize',draw);
$('bstart').onclick=async()=>{
  if(S&&S.log.has&&!confirm('Новый старт удалит прошлый файл лога ('+S.log.rows+' строк). Вы его скачали?'))return;
  const j=await post('/api/log',{a:'start',sec:$('sec').value});msg('lmsg',j.ok?'':'Не стартовала: '+j.err,1);};
$('bstop').onclick=async()=>{const j=await post('/api/log',{a:'stop'});msg('lmsg',j.ok?'':j.err,1);};
$('bclr').onclick=async()=>{if(!confirm('Удалить файл лога?'))return;const j=await post('/api/log',{a:'clear'});msg('lmsg',j.ok?'':j.err,1);};
// ---- файл калибровки
let calibText='';
function calibShow(j){
  $('cimp').hidden=false;
  $('cimpb').innerHTML=j.ch.map(c=>'<tr><td>Датчик '+c.n+'</td><td>'+n(c.was.rref,2)+' Ом · '+sg(c.was.off,2)+' °C'+(c.was.cal?'<br>'+c.was.cal:'')+'</td><td>'+
    (c.ok?(c.same?'<span class="meta">то же самое</span>':'<b>'+n(c.new.rref,2)+' Ом · '+sg(c.new.off,2)+' °C</b>'+(c.new.cal?'<br>'+c.new.cal:'')):'<span class="bad">'+c.why+'</span>')+'</td></tr>').join('');
}
$('cload').onclick=()=>$('cfile').click();
$('cfile').onchange=async()=>{const f=$('cfile').files[0];if(!f)return;calibText=await f.text();$('cfile').value='';
  const j=await post('/api/calib',{a:'check',j:calibText});if(!j.ok){$('cimp').hidden=true;msg('cmsg','Файл не подходит: '+j.err,1);return;}
  msg('cmsg','Файл '+f.name+': проверьте таблицу и нажмите «Записать»');calibShow(j);};
$('ccancel').onclick=()=>{$('cimp').hidden=true;msg('cmsg','');};
$('cwrite').onclick=async()=>{const j=await post('/api/calib',{a:'write',j:calibText});$('cimp').hidden=true;
  msg('cmsg',j.ok?'Записано датчиков: '+j.written:'Не записано: '+j.err,!j.ok);};
$('creset').onclick=async()=>{if(!confirm('Сбросить калибровку всех трёх датчиков: Rref 4300 Ом, поправка 0?'))return;
  const j=await post('/api/zero',{a:'reset'});msg('cmsg',j.ok?'Калибровка сброшена к номиналу':'Ошибка',!j.ok);};
poll();
</script></body></html>)HTML";
