// zerocal.cpp — калибровка нуля по льду, все три датчика сразу.
//
//  Датчики в одном стакане с ледяной кашей (мелкий лёд + немного воды,
//  перемешать, подождать 2–3 минуты). Кнопка «Калибровка нуля» на экране:
//  CAL_SECONDS секунд копится сопротивление каждого датчика, потом для
//  каждого считается новый Rref, при котором во льду ровно 0,00 °C:
//      новый Rref = Rref × R0 / R_льда   (R0 = 1000 Ом для PT1000)
//  Поправка при этом обнуляется. Это тот же расчёт и те же допуски, что у
//  кнопки «Калибровать по льду» в прошивке колонны (web.cpp колонны), поэтому
//  файл калибровки теста подходит колонне один в один.
//
//  Датчик отказывается (остальные сохраняются), если:
//    — показывает дальше CAL_MAX_DEV_C (3 °C) от нуля — не во льду;
//    — показания за замер разошлись больше CAL_MAX_SPREAD_C (0,5 °C);
//    — модуль не отвечал или показывал обрыв, или вне −50…250 °C.
#include "app.h"

static bool started[NCH];

bool zeroStart() {
  uint8_t n = 0;
  for (uint8_t i = 0; i < NCH; i++) {
    sensorsCalClear(i);
    started[i] = sensorsCalStart(i);
    n += started[i];
  }
  Serial.printf("[zero] калибровка нуля: датчиков в замере %u\n", n);
  return n > 0;
}

ZeroState zeroState() {
  bool any = false, run = false;
  for (uint8_t i = 0; i < NCH; i++) {
    if (!started[i]) continue;
    CalInfo k = sensorsCalInfo(i);
    if (k.state == CAL_RUN) run = true;
    if (k.state != CAL_IDLE) any = true;
  }
  return run ? Z_RUN : any ? Z_DONE : Z_IDLE;
}

uint32_t zeroLeftMs() {
  uint32_t left = 0;
  for (uint8_t i = 0; i < NCH; i++)
    if (started[i]) { CalInfo k = sensorsCalInfo(i); if (k.state == CAL_RUN && k.leftMs > left) left = k.leftMs; }
  return left;
}

ZeroRow zeroRow(uint8_t i) {
  ZeroRow r = {ZE_SKIP, NAN, cfg.ch[i].rref, NAN};
  if (i >= NCH || !started[i]) return r;
  CalInfo k = sensorsCalInfo(i);
  if (k.state != CAL_DONE) return r;
  float r0 = cfg.ch[i].pt1000 ? 1000.0f : 100.0f;
  if (k.n < 5 && k.wild > k.bad) { r.err = ZE_RANGE; return r; }
  if (k.n < 5 || isnan(k.ohm) || k.bad * 4 > k.n) { r.err = ZE_FAULT; return r; }
  r.tIce = rtdToC(k.ohm, r0);
  if (fabsf(r.tIce) > CAL_MAX_DEV_C) { r.err = ZE_FAR; return r; }
  if (rtdToC(k.ohmMax, r0) - rtdToC(k.ohmMin, r0) > CAL_MAX_SPREAD_C) { r.err = ZE_DRIFT; return r; }
  r.newRref = roundf(cfg.ch[i].rref * r0 / k.ohm * 100.0f) / 100.0f;   // до 0,01 Ом
  r.err = ZE_OK;
  return r;
}

uint8_t zeroSave() {
  if (zeroState() != Z_DONE) return 0;
  uint8_t n = 0;
  uint32_t now = timeValid() ? (uint32_t)time(nullptr) : 0;
  for (uint8_t i = 0; i < NCH; i++) {
    ZeroRow r = zeroRow(i);
    if (r.err != ZE_OK) continue;
    Serial.printf("[zero] датчик %u: Rref %.2f -> %.2f Ом (во льду было %.2f °C)\n", i + 1, cfg.ch[i].rref, r.newRref, r.tIce);
    cfg.ch[i].rref = r.newRref;
    cfg.ch[i].offset = 0;
    calDateSet(i, now);
    n++;
  }
  if (n) settingsSaveNow();
  zeroCancel();
  return n;
}

void zeroCancel() {
  for (uint8_t i = 0; i < NCH; i++) { sensorsCalClear(i); started[i] = false; }
}

void zeroReset() {
  zeroCancel();
  for (uint8_t i = 0; i < NCH; i++) {
    cfg.ch[i].rref = rrefNominal(i);
    cfg.ch[i].offset = 0;
    calDateSet(i, 0);
  }
  settingsSaveNow();
  Serial.println(F("[zero] калибровка сброшена: Rref к номиналу, поправки 0"));
}

const char *zeroErrText(ZeroErr e) {
  switch (e) {
    case ZE_OK:    return "";
    case ZE_SKIP:  return "не участвовал: датчик выключен или модуль не отвечает";
    case ZE_RANGE: return "показывает вне −50…250 °C: проверьте тип датчика и Rref (резистор «432» на модуле)";
    case ZE_FAULT: return "не отвечал или показывал обрыв: проверьте провода и повторите";
    case ZE_FAR:   return "далеко от 0 °C: датчик не во льду, или на модуле не тот резистор";
    default:       return "показания плыли: датчик ещё не остыл во льду или его трогали, подождите минуту";
  }
}

const char *zeroErrShort(ZeroErr e) {
  switch (e) {
    case ZE_OK:    return "";
    case ZE_SKIP:  return "нет модуля";
    case ZE_RANGE: return "тип / Rref?";
    case ZE_FAULT: return "обрыв / КЗ";
    case ZE_FAR:   return "не во льду";
    default:       return "плывёт";
  }
}
